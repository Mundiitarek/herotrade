<?php
define('APP_ACCESS', true);
require_once '../config.php';
require_once '../functions.php';

require_admin_login();

$admin_id = $_SESSION['admin_id'];
$admin = get_admin_data($pdo, $admin_id);

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Update Platform Settings
    if (isset($_POST['update_platform_settings'])) {
        $platform_name = sanitize($_POST['platform_name']);
        $platform_email = sanitize($_POST['platform_email']);
        $min_deposit = floatval($_POST['min_deposit']);
        $max_deposit = floatval($_POST['max_deposit']);
        $min_withdrawal = floatval($_POST['min_withdrawal']);
        $max_withdrawal = floatval($_POST['max_withdrawal']);
        
        try {
            update_setting($pdo, 'platform_name', $platform_name);
            update_setting($pdo, 'platform_email', $platform_email);
            update_setting($pdo, 'min_deposit', $min_deposit);
            update_setting($pdo, 'max_deposit', $max_deposit);
            update_setting($pdo, 'min_withdrawal', $min_withdrawal);
            update_setting($pdo, 'max_withdrawal', $max_withdrawal);
            
            $success_message = 'تم تحديث إعدادات المنصة بنجاح';
            log_admin_activity($pdo, $admin_id, 'settings_update', 'تحديث إعدادات المنصة');
        } catch (Exception $e) {
            $error_message = 'حدث خطأ أثناء التحديث';
        }
    }
    
    // Update Trading Settings
    if (isset($_POST['update_trading_settings'])) {
        $min_trade = floatval($_POST['min_trade']);
        $max_trade = floatval($_POST['max_trade']);
        $spot_fee = floatval($_POST['spot_fee']);
        $binary_payout = floatval($_POST['binary_payout']);
        $min_binary_duration = intval($_POST['min_binary_duration']);
        $max_binary_duration = intval($_POST['max_binary_duration']);
        
        try {
            update_setting($pdo, 'min_trade_amount', $min_trade);
            update_setting($pdo, 'max_trade_amount', $max_trade);
            update_setting($pdo, 'spot_trading_fee', $spot_fee);
            update_setting($pdo, 'binary_payout_percentage', $binary_payout);
            update_setting($pdo, 'binary_min_duration', $min_binary_duration);
            update_setting($pdo, 'binary_max_duration', $max_binary_duration);
            
            $success_message = 'تم تحديث إعدادات التداول بنجاح';
            log_admin_activity($pdo, $admin_id, 'settings_update', 'تحديث إعدادات التداول');
        } catch (Exception $e) {
            $error_message = 'حدث خطأ أثناء التحديث';
        }
    }
    
    // Add Trading Pair
    if (isset($_POST['add_trading_pair'])) {
        $symbol = strtoupper(sanitize($_POST['symbol']));
        $base = strtoupper(sanitize($_POST['base_currency']));
        $quote = strtoupper(sanitize($_POST['quote_currency']));
        $name_ar = sanitize($_POST['name_ar']);
        $name_en = sanitize($_POST['name_en']);
        $icon = sanitize($_POST['icon']);
        $initial_price = floatval($_POST['initial_price']);
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO trading_pairs (
                    symbol, base_currency, quote_currency, name_ar, name_en, 
                    icon, current_price, spot_enabled, binary_enabled, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 1)
            ");
            $stmt->execute([$symbol, $base, $quote, $name_ar, $name_en, $icon, $initial_price]);
            
            $success_message = 'تم إضافة زوج التداول بنجاح';
            log_admin_activity($pdo, $admin_id, 'trading_pair_add', "إضافة زوج تداول: $symbol");
        } catch (PDOException $e) {
            $error_message = 'حدث خطأ أثناء الإضافة (ربما الرمز موجود بالفعل)';
        }
    }
    
    // Toggle Trading Pair
    if (isset($_POST['toggle_pair'])) {
        $pair_id = intval($_POST['pair_id']);
        
        try {
            $stmt = $pdo->prepare("UPDATE trading_pairs SET is_active = NOT is_active WHERE id = ?");
            $stmt->execute([$pair_id]);
            
            $success_message = 'تم تغيير حالة الزوج بنجاح';
        } catch (PDOException $e) {
            $error_message = 'حدث خطأ';
        }
    }
}

// Get current settings
$platform_name = get_setting($pdo, 'platform_name', 'Trading Platform');
$platform_email = get_setting($pdo, 'platform_email', 'admin@platform.com');
$min_deposit = get_setting($pdo, 'min_deposit', 10);
$max_deposit = get_setting($pdo, 'max_deposit', 100000);
$min_withdrawal = get_setting($pdo, 'min_withdrawal', 10);
$max_withdrawal = get_setting($pdo, 'max_withdrawal', 50000);
$min_trade = get_setting($pdo, 'min_trade_amount', 10);
$max_trade = get_setting($pdo, 'max_trade_amount', 10000);
$spot_fee = get_setting($pdo, 'spot_trading_fee', 0.1);
$binary_payout = get_setting($pdo, 'binary_payout_percentage', 85);
$min_binary_duration = get_setting($pdo, 'binary_min_duration', 60);
$max_binary_duration = get_setting($pdo, 'binary_max_duration', 3600);

// Get trading pairs
try {
    $stmt = $pdo->query("
        SELECT 
            tp.*,
            COUNT(DISTINCT st.id) as spot_trades,
            COUNT(DISTINCT bt.id) as binary_trades
        FROM trading_pairs tp
        LEFT JOIN spot_trades st ON tp.id = st.pair_id
        LEFT JOIN binary_trades bt ON tp.id = bt.pair_id
        GROUP BY tp.id
        ORDER BY tp.is_active DESC, tp.symbol ASC
    ");
    $trading_pairs = $stmt->fetchAll();
} catch (PDOException $e) {
    $trading_pairs = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإعدادات - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar - Same as other admin pages */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-badge {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            font-size: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .admin-card {
            padding: 20px;
            margin: 20px;
            background: rgba(220, 38, 38, 0.05);
            border: 1px solid rgba(220, 38, 38, 0.1);
            border-radius: 16px;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(220, 38, 38, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
        }

        /* Alert */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            border-bottom: 2px solid var(--border);
        }

        .tab-btn {
            padding: 12px 24px;
            background: none;
            border: none;
            color: var(--text-muted);
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            font-family: 'Tajawal', sans-serif;
        }

        .tab-btn:hover,
        .tab-btn.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Settings Cards */
        .settings-grid {
            display: grid;
            gap: 24px;
        }

        .settings-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
        }

        .settings-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .settings-title i {
            color: var(--accent);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-label {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .form-input {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            box-shadow: 0 8px 24px rgba(220, 38, 38, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(220, 38, 38, 0.4);
        }

        .btn-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .btn-success:hover {
            background: var(--success);
            color: white;
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn-danger:hover {
            background: var(--danger);
            color: white;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        /* Trading Pairs Table */
        .pairs-table {
            width: 100%;
            margin-top: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(220, 38, 38, 0.05);
        }

        th {
            padding: 16px;
            text-align: right;
            font-weight: 700;
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        td {
            padding: 16px;
            border-top: 1px solid var(--border);
        }

        tbody tr:hover {
            background: rgba(220, 38, 38, 0.02);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-badge.active {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-badge.inactive {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <div class="logo-text">Admin Panel</div>
                    <div class="admin-badge">Administrator</div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div>
                    <div style="font-weight: 700;"><?= htmlspecialchars($admin['username']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted);">Super Admin</div>
                </div>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">الإدارة</div>
            <a href="index.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-credit-card"></i>
                <span>المدفوعات</span>
            </a>
            <a href="trades.php" class="nav-item">
                <i class="fas fa-exchange-alt"></i>
                <span>الصفقات</span>
            </a>
            <a href="settings.php" class="nav-item active">
                <i class="fas fa-cog"></i>
                <span>الإعدادات</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-arrow-right"></i>
                <span>العودة للمنصة</span>
            </a>
            <a href="../logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">إعدادات المنصة</h1>
            <div class="breadcrumb">
                <a href="index.php">لوحة التحكم</a>
                <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                <span>الإعدادات</span>
            </div>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success_message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php endif; ?>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab-btn active" onclick="switchTab('platform')">
                <i class="fas fa-globe"></i> إعدادات المنصة
            </button>
            <button class="tab-btn" onclick="switchTab('trading')">
                <i class="fas fa-chart-line"></i> إعدادات التداول
            </button>
            <button class="tab-btn" onclick="switchTab('pairs')">
                <i class="fas fa-coins"></i> أزواج التداول
            </button>
        </div>

        <div class="settings-grid">
            <!-- Platform Settings Tab -->
            <div id="tab-platform" class="tab-content active">
                <div class="settings-card">
                    <h3 class="settings-title">
                        <i class="fas fa-cog"></i>
                        الإعدادات العامة
                    </h3>
                    
                    <form method="POST">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">اسم المنصة</label>
                                <input type="text" name="platform_name" class="form-input" value="<?= htmlspecialchars($platform_name) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" name="platform_email" class="form-input" value="<?= htmlspecialchars($platform_email) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأدنى للإيداع ($)</label>
                                <input type="number" name="min_deposit" class="form-input" value="<?= $min_deposit ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأقصى للإيداع ($)</label>
                                <input type="number" name="max_deposit" class="form-input" value="<?= $max_deposit ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأدنى للسحب ($)</label>
                                <input type="number" name="min_withdrawal" class="form-input" value="<?= $min_withdrawal ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأقصى للسحب ($)</label>
                                <input type="number" name="max_withdrawal" class="form-input" value="<?= $max_withdrawal ?>" step="0.01" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="update_platform_settings" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            حفظ التغييرات
                        </button>
                    </form>
                </div>
            </div>

            <!-- Trading Settings Tab -->
            <div id="tab-trading" class="tab-content">
                <div class="settings-card">
                    <h3 class="settings-title">
                        <i class="fas fa-chart-line"></i>
                        إعدادات التداول
                    </h3>
                    
                    <form method="POST">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">الحد الأدنى للتداول ($)</label>
                                <input type="number" name="min_trade" class="form-input" value="<?= $min_trade ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأقصى للتداول ($)</label>
                                <input type="number" name="max_trade" class="form-input" value="<?= $max_trade ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">رسوم Spot Trading (%)</label>
                                <input type="number" name="spot_fee" class="form-input" value="<?= $spot_fee ?>" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">نسبة الربح Binary (%)</label>
                                <input type="number" name="binary_payout" class="form-input" value="<?= $binary_payout ?>" step="1" min="50" max="95" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأدنى لمدة Binary (ثانية)</label>
                                <input type="number" name="min_binary_duration" class="form-input" value="<?= $min_binary_duration ?>" step="1" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الحد الأقصى لمدة Binary (ثانية)</label>
                                <input type="number" name="max_binary_duration" class="form-input" value="<?= $max_binary_duration ?>" step="1" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="update_trading_settings" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            حفظ التغييرات
                        </button>
                    </form>
                </div>
            </div>

            <!-- Trading Pairs Tab -->
            <div id="tab-pairs" class="tab-content">
                <div class="settings-card">
                    <h3 class="settings-title">
                        <i class="fas fa-plus-circle"></i>
                        إضافة زوج تداول جديد
                    </h3>
                    
                    <form method="POST">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">الرمز (Symbol)</label>
                                <input type="text" name="symbol" class="form-input" placeholder="BTCUSDT" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">العملة الأساسية</label>
                                <input type="text" name="base_currency" class="form-input" placeholder="BTC" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">عملة التسعير</label>
                                <input type="text" name="quote_currency" class="form-input" placeholder="USDT" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الاسم بالعربي</label>
                                <input type="text" name="name_ar" class="form-input" placeholder="بيتكوين" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الاسم بالإنجليزي</label>
                                <input type="text" name="name_en" class="form-input" placeholder="Bitcoin" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الأيقونة (Emoji)</label>
                                <input type="text" name="icon" class="form-input" placeholder="₿" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">السعر الابتدائي ($)</label>
                                <input type="number" name="initial_price" class="form-input" placeholder="67000" step="0.01" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="add_trading_pair" class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            إضافة الزوج
                        </button>
                    </form>
                </div>

                <!-- Trading Pairs List -->
                <div class="settings-card">
                    <h3 class="settings-title">
                        <i class="fas fa-list"></i>
                        أزواج التداول المتاحة (<?= count($trading_pairs) ?>)
                    </h3>
                    
                    <div class="pairs-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>الرمز</th>
                                    <th>الاسم</th>
                                    <th>السعر الحالي</th>
                                    <th>الصفقات</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($trading_pairs as $pair): ?>
                                    <tr>
                                        <td>
                                            <span style="font-weight: 700; font-family: monospace;">
                                                <?= htmlspecialchars($pair['symbol']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span style="font-size: 20px; margin-left: 8px;"><?= $pair['icon'] ?></span>
                                            <?= htmlspecialchars($pair['name_ar']) ?>
                                        </td>
                                        <td style="font-weight: 700;">
                                            $<?= number_format($pair['current_price'], 2) ?>
                                        </td>
                                        <td>
                                            <div style="font-size: 13px;">
                                                Spot: <?= $pair['spot_trades'] ?? 0 ?><br>
                                                Binary: <?= $pair['binary_trades'] ?? 0 ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge <?= $pair['is_active'] ? 'active' : 'inactive' ?>">
                                                <?= $pair['is_active'] ? 'مفعل' : 'معطل' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="pair_id" value="<?= $pair['id'] ?>">
                                                <button type="submit" name="toggle_pair" class="btn <?= $pair['is_active'] ? 'btn-danger' : 'btn-success' ?> btn-sm">
                                                    <i class="fas fa-<?= $pair['is_active'] ? 'ban' : 'check' ?>"></i>
                                                    <?= $pair['is_active'] ? 'تعطيل' : 'تفعيل' ?>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        function switchTab(tabName) {
            // Remove active class from all tabs
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Add active class to selected tab
            event.target.classList.add('active');
            document.getElementById('tab-' + tabName).classList.add('active');
        }

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>
