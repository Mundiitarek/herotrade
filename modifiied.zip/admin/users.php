<?php
define('APP_ACCESS', true);
require_once '../config.php';
require_once '../functions.php';

require_admin_login();

$admin_id = $_SESSION['admin_id'];
$admin = get_admin_data($pdo, $admin_id);

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$success_message = '';
$error_message = '';

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'toggle_status') {
        $user_id = intval($_POST['user_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("UPDATE users SET is_active = NOT is_active WHERE id = ?");
            $stmt->execute([$user_id]);
            
            log_admin_activity($pdo, $admin_id, 'user_status_toggle', "تغيير حالة المستخدم #$user_id");
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'update_balance') {
        $user_id = intval($_POST['user_id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $type = sanitize($_POST['type'] ?? 'add');
        
        if ($amount <= 0) {
            json_response(['success' => false, 'message' => 'المبلغ يجب أن يكون أكبر من صفر'], 400);
        }
        
        try {
            $pdo->beginTransaction();
            
            if ($type === 'add') {
                $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $description = "إضافة رصيد من الأدمن: +$$amount";
            } else {
                $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $description = "خصم رصيد من الأدمن: -$$amount";
            }
            
            $stmt->execute([$amount, $user_id]);
            
            // Log transaction
            $transaction_id = 'TXN' . time() . rand(1000, 9999);
            $stmt = $pdo->prepare("
                INSERT INTO transactions (transaction_id, user_id, type, amount, status, description)
                VALUES (?, ?, 'adjustment', ?, 'completed', ?)
            ");
            $stmt->execute([$transaction_id, $user_id, $amount, $description]);
            
            log_admin_activity($pdo, $admin_id, 'balance_adjustment', "تعديل رصيد المستخدم #$user_id: $type $$amount");
            
            $pdo->commit();
            json_response(['success' => true]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'delete_user') {
        $user_id = intval($_POST['user_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            log_admin_activity($pdo, $admin_id, 'user_delete', "حذف المستخدم #$user_id");
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_user'])) {
        $user_id = intval($_POST['user_id']);
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $full_name = sanitize($_POST['full_name']);
        $phone = sanitize($_POST['phone']);
        
        try {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET username = ?, email = ?, full_name = ?, phone = ?
                WHERE id = ?
            ");
            $stmt->execute([$username, $email, $full_name, $phone, $user_id]);
            
            $success_message = 'تم تحديث بيانات المستخدم بنجاح';
            log_admin_activity($pdo, $admin_id, 'user_update', "تحديث بيانات المستخدم #$user_id");
        } catch (PDOException $e) {
            $error_message = 'حدث خطأ أثناء التحديث';
        }
    }
}

// Filters
$search = sanitize($_GET['search'] ?? '');
$status_filter = sanitize($_GET['status'] ?? 'all');
$sort = sanitize($_GET['sort'] ?? 'newest');
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query
$where = ["1=1"];
$params = [];

if (!empty($search)) {
    $where[] = "(username LIKE ? OR email LIKE ? OR full_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter === 'active') {
    $where[] = "is_active = 1";
} elseif ($status_filter === 'inactive') {
    $where[] = "is_active = 0";
}

$where_clause = implode(' AND ', $where);

// Sorting
$order_by = match($sort) {
    'oldest' => 'created_at ASC',
    'balance_high' => 'balance DESC',
    'balance_low' => 'balance ASC',
    'name' => 'username ASC',
    default => 'created_at DESC'
};

// Get total count
try {
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE $where_clause");
    $count_stmt->execute($params);
    $total_users = $count_stmt->fetchColumn();
    $total_pages = ceil($total_users / $per_page);
} catch (PDOException $e) {
    $total_users = 0;
    $total_pages = 1;
}

// Get users
try {
    $stmt = $pdo->prepare("
        SELECT 
            u.*,
            COUNT(DISTINCT st.id) as spot_trades_count,
            COUNT(DISTINCT bt.id) as binary_trades_count,
            SUM(CASE WHEN st.status = 'closed' AND st.profit_loss > 0 THEN st.profit_loss ELSE 0 END) as total_profit
        FROM users u
        LEFT JOIN spot_trades st ON u.id = st.user_id
        LEFT JOIN binary_trades bt ON u.id = bt.user_id
        WHERE $where_clause
        GROUP BY u.id
        ORDER BY $order_by
        LIMIT ? OFFSET ?
    ");
    
    $params[] = $per_page;
    $params[] = $offset;
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Get users error: " . $e->getMessage());
    $users = [];
}

// Get statistics
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN is_active = 1 THEN 1 END) as active,
            COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as new_today,
            SUM(balance) as total_balance
        FROM users
    ");
    $stats = $stmt->fetch();
} catch (PDOException $e) {
    $stats = ['total' => 0, 'active' => 0, 'new_today' => 0, 'total_balance' => 0];
}

// Get pending transactions count
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM transactions WHERE status = 'pending'");
    $pending_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $pending_count = 0;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar - Same as index.php */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-badge {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            font-size: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .admin-card {
            padding: 20px;
            margin: 20px;
            background: rgba(220, 38, 38, 0.05);
            border: 1px solid rgba(220, 38, 38, 0.1);
            border-radius: 16px;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(220, 38, 38, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        .nav-badge {
            margin-right: auto;
            background: var(--danger);
            color: white;
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 700;
        }

        /* Main */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
        }

        /* Alert */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--success);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: var(--danger);
        }

        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 900;
        }

        /* Filters */
        .filters-section {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .filter-input,
        .filter-select {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
            transition: all 0.3s;
        }

        .filter-input:focus,
        .filter-select:focus {
            outline: none;
            border-color: var(--accent);
        }

        /* Users Table */
        .users-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
        }

        .users-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(220, 38, 38, 0.05);
        }

        th {
            padding: 16px 24px;
            text-align: right;
            font-weight: 700;
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        td {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
        }

        tbody tr {
            transition: background 0.2s;
        }

        tbody tr:hover {
            background: rgba(220, 38, 38, 0.02);
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
        }

        .user-info {
            flex: 1;
        }

        .user-name {
            font-weight: 600;
        }

        .user-email {
            font-size: 12px;
            color: var(--text-muted);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-badge.active {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-badge.inactive {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(220, 38, 38, 0.3);
        }

        .btn-secondary {
            background: var(--primary);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #2D3748;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn-danger:hover {
            background: var(--danger);
            color: white;
        }

        .btn-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .btn-success:hover {
            background: var(--success);
            color: white;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            margin-bottom: 24px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 900;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 24px;
            border-top: 1px solid var(--border);
        }

        .pagination-btn {
            padding: 8px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .pagination-btn:hover:not(.disabled) {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .pagination-btn.active {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .pagination-btn.disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .filters-grid {
                grid-template-columns: 1fr;
            }

            table {
                min-width: 900px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <div class="logo-text">Admin Panel</div>
                    <div class="admin-badge">Administrator</div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div>
                    <div style="font-weight: 700;"><?= htmlspecialchars($admin['username']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted);">Super Admin</div>
                </div>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">الإدارة</div>
            <a href="index.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="users.php" class="nav-item active">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
                <span class="nav-badge"><?= $stats['total'] ?></span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-credit-card"></i>
                <span>المدفوعات</span>
                <?php if ($pending_count > 0): ?>
                    <span class="nav-badge"><?= $pending_count ?></span>
                <?php endif; ?>
            </a>
            <a href="trades.php" class="nav-item">
                <i class="fas fa-exchange-alt"></i>
                <span>الصفقات</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>الإعدادات</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-arrow-right"></i>
                <span>العودة للمنصة</span>
            </a>
            <a href="../logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">إدارة المستخدمين</h1>
            <div class="breadcrumb">
                <a href="index.php">لوحة التحكم</a>
                <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                <span>المستخدمين</span>
            </div>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success_message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">إجمالي المستخدمين</div>
                <div class="stat-value" style="color: var(--info);"><?= number_format($stats['total']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">مستخدمين نشطين</div>
                <div class="stat-value" style="color: var(--success);"><?= number_format($stats['active']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">جدد اليوم</div>
                <div class="stat-value" style="color: var(--accent);"><?= number_format($stats['new_today']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">إجمالي الأرصدة</div>
                <div class="stat-value" style="color: var(--success);">$<?= number_format($stats['total_balance'], 2) ?></div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <form method="GET" action="users.php">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">بحث</label>
                        <input type="text" name="search" class="filter-input" placeholder="اسم المستخدم، البريد، الاسم..." value="<?= htmlspecialchars($search) ?>">
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">الحالة</label>
                        <select name="status" class="filter-select" onchange="this.form.submit()">
                            <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>الكل</option>
                            <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>نشط</option>
                            <option value="inactive" <?= $status_filter === 'inactive' ? 'selected' : '' ?>>معطل</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">الترتيب</label>
                        <select name="sort" class="filter-select" onchange="this.form.submit()">
                            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>الأحدث</option>
                            <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>الأقدم</option>
                            <option value="balance_high" <?= $sort === 'balance_high' ? 'selected' : '' ?>>الرصيد (الأعلى)</option>
                            <option value="balance_low" <?= $sort === 'balance_low' ? 'selected' : '' ?>>الرصيد (الأقل)</option>
                            <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>الاسم</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label" style="opacity: 0;">بحث</label>
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-search"></i>
                            بحث
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Users Table -->
        <div class="users-card">
            <div class="users-header">
                <h3>المستخدمين (<?= $total_users ?>)</h3>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>المستخدم</th>
                            <th>الرصيد</th>
                            <th>الصفقات</th>
                            <th>الحالة</th>
                            <th>تاريخ التسجيل</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar">
                                            <?= strtoupper(substr($user['username'], 0, 2)) ?>
                                        </div>
                                        <div class="user-info">
                                            <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                                            <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span style="font-weight: 700; color: var(--success);">
                                        $<?= number_format($user['balance'], 2) ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-size: 13px;">
                                        Spot: <?= $user['spot_trades_count'] ?? 0 ?><br>
                                        Binary: <?= $user['binary_trades_count'] ?? 0 ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge <?= $user['is_active'] ? 'active' : 'inactive' ?>">
                                        <i class="fas fa-<?= $user['is_active'] ? 'check-circle' : 'times-circle' ?>"></i>
                                        <?= $user['is_active'] ? 'نشط' : 'معطل' ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-size: 13px; color: var(--text-muted);">
                                        <?= date('Y/m/d', strtotime($user['created_at'])) ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <button class="btn btn-secondary btn-sm" onclick="openBalanceModal(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')">
                                            <i class="fas fa-wallet"></i>
                                        </button>
                                        <button class="btn <?= $user['is_active'] ? 'btn-danger' : 'btn-success' ?> btn-sm" onclick="toggleStatus(<?= $user['id'] ?>)">
                                            <i class="fas fa-<?= $user['is_active'] ? 'ban' : 'check' ?>"></i>
                                        </button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&status=<?= $status_filter ?>&sort=<?= $sort ?>" class="pagination-btn">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php else: ?>
                        <span class="pagination-btn disabled">
                            <i class="fas fa-chevron-right"></i>
                        </span>
                    <?php endif; ?>

                    <span style="padding: 8px 16px; color: var(--text-muted);">
                        صفحة <?= $page ?> من <?= $total_pages ?>
                    </span>

                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&status=<?= $status_filter ?>&sort=<?= $sort ?>" class="pagination-btn">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    <?php else: ?>
                        <span class="pagination-btn disabled">
                            <i class="fas fa-chevron-left"></i>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Balance Modal -->
    <div id="balanceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">تعديل رصيد المستخدم</h2>
            </div>
            <form id="balanceForm">
                <input type="hidden" id="balance_user_id">
                
                <div class="form-group">
                    <label class="form-label">المستخدم</label>
                    <input type="text" id="balance_username" class="form-input" readonly>
                </div>

                <div class="form-group">
                    <label class="form-label">المبلغ</label>
                    <input type="number" id="balance_amount" class="form-input" step="0.01" min="0" required>
                </div>

                <div class="form-group">
                    <label class="form-label">النوع</label>
                    <select id="balance_type" class="form-input">
                        <option value="add">إضافة رصيد</option>
                        <option value="subtract">خصم رصيد</option>
                    </select>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeBalanceModal()">إلغاء</button>
                    <button type="submit" class="btn btn-primary">تنفيذ</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openBalanceModal(userId, username) {
            document.getElementById('balance_user_id').value = userId;
            document.getElementById('balance_username').value = username;
            document.getElementById('balance_amount').value = '';
            document.getElementById('balanceModal').classList.add('active');
        }

        function closeBalanceModal() {
            document.getElementById('balanceModal').classList.remove('active');
        }

        document.getElementById('balanceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const userId = document.getElementById('balance_user_id').value;
            const amount = document.getElementById('balance_amount').value;
            const type = document.getElementById('balance_type').value;
            
            fetch('users.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=update_balance&user_id=${userId}&amount=${amount}&type=${type}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'حدث خطأ');
                }
            });
        });

        function toggleStatus(userId) {
            if (!confirm('هل تريد تغيير حالة المستخدم؟')) return;
            
            fetch('users.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=toggle_status&user_id=${userId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function deleteUser(userId, username) {
            if (!confirm(`هل تريد حذف المستخدم "${username}"؟ لا يمكن التراجع عن هذا الإجراء.`)) return;
            
            fetch('users.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=delete_user&user_id=${userId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        // Close modal on outside click
        document.getElementById('balanceModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeBalanceModal();
            }
        });
    </script>
</body>
</html>
