<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

// Require login
require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle deposit request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'submit_deposit') {
        $gateway_id = intval($_POST['gateway_id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $payment_proof = sanitize($_POST['payment_proof'] ?? '');
        $payment_notes = sanitize($_POST['payment_notes'] ?? '');
        
        // Get gateway
        $stmt = $pdo->prepare("SELECT * FROM payment_gateways WHERE id = ? AND is_active = 1");
        $stmt->execute([$gateway_id]);
        $gateway = $stmt->fetch();
        
        if (!$gateway) {
            json_response(['success' => false, 'message' => 'بوابة الدفع غير صحيحة'], 400);
        }
        
        // Validation
        if ($amount < $gateway['min_deposit']) {
            json_response(['success' => false, 'message' => 'الحد الأدنى للإيداع هو $' . number_format($gateway['min_deposit'], 2)], 400);
        }
        
        if ($amount > $gateway['max_deposit']) {
            json_response(['success' => false, 'message' => 'الحد الأقصى للإيداع هو $' . number_format($gateway['max_deposit'], 2)], 400);
        }
        
        // Calculate fee
        $fee = ($amount * $gateway['fee_percentage'] / 100) + $gateway['fee_fixed'];
        $total_amount = $amount - $fee;
        
        try {
            // Create transaction
            $reference_id = 'DEP_' . time() . '_' . $user_id . '_' . rand(1000, 9999);
            
            $payment_details = json_encode([
                'proof' => $payment_proof,
                'notes' => $payment_notes,
                'fee' => $fee,
                'gateway' => $gateway['name']
            ]);
            
            $stmt = $pdo->prepare("
                INSERT INTO transactions (
                    user_id, type, method, amount, status, reference_id,
                    payment_gateway, payment_details, ip_address
                ) VALUES (?, 'deposit', 'p2p', ?, 'pending', ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $user_id,
                $total_amount,
                $reference_id,
                $gateway['name'],
                $payment_details,
                get_client_ip()
            ]);
            
            $transaction_id = $pdo->lastInsertId();
            
            log_activity($pdo, 'deposit_request', "Deposit request: $amount via {$gateway['name']}", $user_id);
            
            // Create notification
            create_notification(
                $pdo,
                $user_id,
                'transaction',
                'Deposit Request',
                'طلب إيداع',
                "Your deposit request of $$amount has been submitted.",
                "تم إرسال طلب إيداع بقيمة $$amount.",
                'transactions.php'
            );
            
            json_response([
                'success' => true,
                'message' => 'تم إرسال طلب الإيداع بنجاح. سيتم مراجعته خلال 24 ساعة',
                'transaction_id' => $transaction_id,
                'reference_id' => $reference_id
            ]);
            
        } catch (Exception $e) {
            error_log("Deposit request error: " . $e->getMessage());
            json_response(['success' => false, 'message' => 'حدث خطأ أثناء المعالجة'], 500);
        }
    }
    
    exit;
}

// Get payment gateways
$stmt = $pdo->query("
    SELECT * FROM payment_gateways 
    WHERE is_active = 1 
    ORDER BY sort_order ASC, id ASC
");
$payment_gateways = $stmt->fetchAll();

// Get user's deposit history
$stmt = $pdo->prepare("
    SELECT * FROM transactions 
    WHERE user_id = ? AND type = 'deposit'
    ORDER BY created_at DESC
    LIMIT 20
");
$stmt->execute([$user_id]);
$deposit_history = $stmt->fetchAll();

$current_language = $_SESSION['language'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_language; ?>" dir="<?php echo $current_language === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة رصيد - Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.95);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-red: #e74c3c;
            --accent-blue: #3498db;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(244, 162, 97, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(46, 204, 113, 0.03) 0%, transparent 50%);
            z-index: 0;
            pointer-events: none;
        }

        /* Top Bar */
        .top-bar {
            background: var(--secondary-bg);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
        }

        .back-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--accent-gold);
        }

        .user-balance {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .balance-value {
            font-size: 18px;
            font-weight: 900;
            color: var(--accent-green);
        }

        /* Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
            position: relative;
            z-index: 1;
        }

        .page-header {
            text-align: center;
            margin-bottom: 48px;
        }

        .page-title {
            font-size: 48px;
            font-weight: 900;
            margin-bottom: 12px;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .page-subtitle {
            font-size: 18px;
            color: var(--text-secondary);
        }

        /* Grid Layout */
        .deposit-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 32px;
            margin-bottom: 48px;
        }

        /* Card */
        .card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 32px;
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green));
        }

        .card-title {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Payment Gateways */
        .payment-gateways {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 32px;
        }

        .gateway-item {
            background: var(--glass-bg);
            border: 2px solid var(--border-color);
            border-radius: 16px;
            padding: 24px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .gateway-item:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--accent-gold);
            transform: translateX(-5px);
        }

        .gateway-item.active {
            border-color: var(--accent-gold);
            background: rgba(244, 162, 97, 0.1);
            box-shadow: 0 0 30px rgba(244, 162, 97, 0.2);
        }

        .gateway-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            flex-shrink: 0;
        }

        .gateway-info {
            flex: 1;
        }

        .gateway-name {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .gateway-limits {
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }

        .gateway-fee {
            font-size: 12px;
            color: var(--accent-gold);
            font-weight: 600;
        }

        .gateway-check {
            width: 28px;
            height: 28px;
            border: 2px solid var(--border-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            transition: all 0.3s;
        }

        .gateway-item.active .gateway-check {
            background: var(--accent-gold);
            border-color: var(--accent-gold);
            color: white;
        }

        /* Deposit Form */
        .deposit-form {
            display: none;
        }

        .deposit-form.active {
            display: block;
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 700;
            color: var(--text-secondary);
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-input,
        .form-textarea {
            width: 100%;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 16px;
            font-weight: 600;
            font-family: inherit;
            transition: all 0.3s;
        }

        .form-input:focus,
        .form-textarea:focus {
            outline: none;
            border-color: var(--accent-gold);
            background: rgba(255, 255, 255, 0.05);
        }

        .form-textarea {
            resize: vertical;
            min-height: 120px;
        }

        .amount-suggestions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-top: 12px;
        }

        .amount-btn {
            padding: 14px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-primary);
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }

        .amount-btn:hover {
            background: rgba(244, 162, 97, 0.1);
            border-color: var(--accent-gold);
            color: var(--accent-gold);
        }

        .info-box {
            background: rgba(52, 152, 219, 0.1);
            border: 1px solid rgba(52, 152, 219, 0.3);
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 24px;
            font-size: 14px;
            color: var(--accent-blue);
            line-height: 1.6;
        }

        .info-box strong {
            display: block;
            margin-bottom: 8px;
            font-size: 15px;
        }

        .summary-box {
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 15px;
        }

        .summary-row:last-child {
            margin-bottom: 0;
            padding-top: 12px;
            border-top: 1px solid var(--border-color);
            font-size: 18px;
            font-weight: 900;
        }

        .summary-label {
            color: var(--text-secondary);
        }

        .summary-value {
            font-weight: 700;
        }

        .summary-value.green {
            color: var(--accent-green);
        }

        .btn-submit {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 18px;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 10px 40px rgba(244, 162, 97, 0.3);
        }

        .btn-submit:hover:not(:disabled) {
            transform: translateY(-3px);
            box-shadow: 0 15px 50px rgba(244, 162, 97, 0.5);
        }

        .btn-submit:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* History Table */
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }

        .history-table thead th {
            text-align: right;
            padding: 14px;
            font-size: 12px;
            font-weight: 700;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border-color);
        }

        .history-table tbody td {
            padding: 18px 14px;
            border-bottom: 1px solid var(--border-color);
            font-size: 14px;
        }

        .history-table tbody tr {
            transition: background 0.3s;
        }

        .history-table tbody tr:hover {
            background: var(--glass-bg);
        }

        .status-badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .status-badge.pending {
            background: rgba(244, 162, 97, 0.15);
            color: var(--accent-gold);
        }

        .status-badge.completed {
            background: rgba(46, 204, 113, 0.15);
            color: var(--accent-green);
        }

        .status-badge.failed,
        .status-badge.cancelled {
            background: rgba(231, 76, 60, 0.15);
            color: var(--accent-red);
        }

        .reference-id {
            font-family: monospace;
            font-size: 13px;
            color: var(--text-secondary);
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 15px;
            animation: slideDown 0.3s;
            display: none;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border: 1px solid rgba(46, 204, 113, 0.3);
            color: var(--accent-green);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: var(--accent-red);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }

        .empty-icon {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.3;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .deposit-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .page-title {
                font-size: 32px;
            }

            .card {
                padding: 24px;
            }

            .amount-suggestions {
                grid-template-columns: repeat(2, 1fr);
            }

            .history-table {
                font-size: 12px;
            }

            .history-table thead th,
            .history-table tbody td {
                padding: 10px 8px;
            }
        }
    </style>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <a href="dashboard.php" class="back-btn">
            ← العودة للوحة التحكم
        </a>
        <div class="user-balance">
            <span class="balance-label">الرصيد الحالي:</span>
            <span class="balance-value">$<?php echo number_format($user['balance'], 2); ?></span>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">💰 إضافة رصيد</h1>
            <p class="page-subtitle">اختر طريقة الدفع المناسبة لك وأضف رصيد لحسابك</p>
        </div>

        <!-- Deposit Grid -->
        <div class="deposit-grid">
            <!-- Left - Payment Methods -->
            <div class="card">
                <h2 class="card-title">
                    <span>🏦</span>
                    <span>اختر طريقة الدفع</span>
                </h2>

                <div class="payment-gateways">
                    <?php foreach ($payment_gateways as $index => $gateway): ?>
                        <div class="gateway-item <?php echo $index === 0 ? 'active' : ''; ?>" 
                             data-gateway-id="<?php echo $gateway['id']; ?>"
                             data-gateway-name="<?php echo $gateway['display_name_ar']; ?>"
                             data-min="<?php echo $gateway['min_deposit']; ?>"
                             data-max="<?php echo $gateway['max_deposit']; ?>"
                             data-fee-percent="<?php echo $gateway['fee_percentage']; ?>"
                             data-fee-fixed="<?php echo $gateway['fee_fixed']; ?>"
                             data-instructions="<?php echo htmlspecialchars($gateway['instructions_ar'] ?? ''); ?>"
                             onclick="selectGateway(this)">
                            <div class="gateway-icon">
                                <?php 
                                $icons = [
                                    'bank_transfer' => '🏦',
                                    'crypto' => '₿',
                                    'e_wallet' => '💳',
                                    'card' => '💳'
                                ];
                                echo $icons[$gateway['type']] ?? '💰';
                                ?>
                            </div>
                            <div class="gateway-info">
                                <div class="gateway-name"><?php echo $gateway['display_name_ar']; ?></div>
                                <div class="gateway-limits">
                                    الحد الأدنى: $<?php echo number_format($gateway['min_deposit'], 2); ?> 
                                    - الأقصى: $<?php echo number_format($gateway['max_deposit'], 2); ?>
                                </div>
                                <?php if ($gateway['fee_percentage'] > 0 || $gateway['fee_fixed'] > 0): ?>
                                    <div class="gateway-fee">
                                        رسوم: 
                                        <?php if ($gateway['fee_percentage'] > 0): ?>
                                            <?php echo $gateway['fee_percentage']; ?>%
                                        <?php endif; ?>
                                        <?php if ($gateway['fee_fixed'] > 0): ?>
                                            + $<?php echo number_format($gateway['fee_fixed'], 2); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="gateway-fee">بدون رسوم ✓</div>
                                <?php endif; ?>
                            </div>
                            <div class="gateway-check">✓</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Right - Deposit Form -->
            <div class="card">
                <h2 class="card-title">
                    <span>📝</span>
                    <span>تفاصيل الإيداع</span>
                </h2>

                <div id="depositAlert"></div>

                <div id="gatewayInstructions" class="info-box" style="display: none;">
                    <strong>⚠️ تعليمات الدفع:</strong>
                    <div id="instructionsText"></div>
                </div>

                <form id="depositForm">
                    <input type="hidden" name="action" value="submit_deposit">
                    <input type="hidden" name="gateway_id" id="gatewayId" value="<?php echo $payment_gateways[0]['id'] ?? ''; ?>">

                    <div class="form-group">
                        <label class="form-label">المبلغ المطلوب (USD)</label>
                        <input type="number" name="amount" id="depositAmount" class="form-input" 
                               placeholder="0.00" min="10" step="0.01" required>
                        
                        <div class="amount-suggestions">
                            <button type="button" class="amount-btn" onclick="setDepositAmount(50)">$50</button>
                            <button type="button" class="amount-btn" onclick="setDepositAmount(100)">$100</button>
                            <button type="button" class="amount-btn" onclick="setDepositAmount(500)">$500</button>
                            <button type="button" class="amount-btn" onclick="setDepositAmount(1000)">$1000</button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">إثبات الدفع (رقم المعاملة / لقطة الشاشة)</label>
                        <input type="text" name="payment_proof" class="form-input" 
                               placeholder="أدخل رقم المعاملة أو رابط الصورة" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">ملاحظات إضافية (اختياري)</label>
                        <textarea name="payment_notes" class="form-textarea" 
                                  placeholder="أي ملاحظات أو تفاصيل إضافية..."></textarea>
                    </div>

                    <div class="summary-box">
                        <div class="summary-row">
                            <span class="summary-label">المبلغ المطلوب:</span>
                            <span class="summary-value" id="summaryAmount">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">الرسوم:</span>
                            <span class="summary-value" id="summaryFee">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">المبلغ الذي ستحصل عليه:</span>
                            <span class="summary-value green" id="summaryTotal">$0.00</span>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit" id="submitBtn">
                        <span id="btnText">إرسال طلب الإيداع 🚀</span>
                        <span id="btnLoading" style="display: none;">جاري المعالجة...</span>
                    </button>
                </form>
            </div>
        </div>

        <!-- Deposit History -->
        <div class="card">
            <h2 class="card-title">
                <span>📜</span>
                <span>سجل الإيداعات</span>
            </h2>

            <?php if (empty($deposit_history)): ?>
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <div>لا توجد إيداعات سابقة</div>
                </div>
            <?php else: ?>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>الرقم المرجعي</th>
                            <th>الطريقة</th>
                            <th>المبلغ</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($deposit_history as $deposit): ?>
                            <tr>
                                <td>
                                    <span class="reference-id"><?php echo $deposit['reference_id']; ?></span>
                                </td>
                                <td>
                                    <?php 
                                    $gateway_names = [
                                        'bank_transfer' => 'تحويل بنكي',
                                        'usdt_trc20' => 'USDT',
                                        'bitcoin' => 'Bitcoin',
                                        'vodafone_cash' => 'فودافون كاش'
                                    ];
                                    echo $gateway_names[$deposit['payment_gateway']] ?? $deposit['payment_gateway'];
                                    ?>
                                </td>
                                <td style="font-weight: 700; color: var(--accent-green);">
                                    $<?php echo number_format($deposit['amount'], 2); ?>
                                </td>
                                <td>
                                    <?php 
                                    $status_names = [
                                        'pending' => 'قيد المراجعة',
                                        'completed' => 'مكتمل',
                                        'failed' => 'فشل',
                                        'cancelled' => 'ملغي'
                                    ];
                                    ?>
                                    <span class="status-badge <?php echo $deposit['status']; ?>">
                                        <?php echo $status_names[$deposit['status']] ?? $deposit['status']; ?>
                                    </span>
                                </td>
                                <td style="color: var(--text-secondary);">
                                    <?php echo date('Y-m-d H:i', strtotime($deposit['created_at'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script>
        let selectedGateway = {
            id: <?php echo $payment_gateways[0]['id'] ?? 1; ?>,
            min: <?php echo $payment_gateways[0]['min_deposit'] ?? 10; ?>,
            max: <?php echo $payment_gateways[0]['max_deposit'] ?? 100000; ?>,
            feePercent: <?php echo $payment_gateways[0]['fee_percentage'] ?? 0; ?>,
            feeFixed: <?php echo $payment_gateways[0]['fee_fixed'] ?? 0; ?>
        };

        // Select Gateway
        function selectGateway(element) {
            document.querySelectorAll('.gateway-item').forEach(item => item.classList.remove('active'));
            element.classList.add('active');

            selectedGateway = {
                id: parseInt(element.dataset.gatewayId),
                min: parseFloat(element.dataset.min),
                max: parseFloat(element.dataset.max),
                feePercent: parseFloat(element.dataset.feePercent),
                feeFixed: parseFloat(element.dataset.feeFixed)
            };

            document.getElementById('gatewayId').value = selectedGateway.id;

            // Show instructions
            const instructions = element.dataset.instructions;
            if (instructions && instructions.trim() !== '') {
                document.getElementById('gatewayInstructions').style.display = 'block';
                document.getElementById('instructionsText').innerHTML = instructions;
            } else {
                document.getElementById('gatewayInstructions').style.display = 'none';
            }

            updateSummary();
        }

        // Set Amount
        function setDepositAmount(amount) {
            document.getElementById('depositAmount').value = amount;
            updateSummary();
        }

        // Update Summary
        document.getElementById('depositAmount').addEventListener('input', updateSummary);

        function updateSummary() {
            const amount = parseFloat(document.getElementById('depositAmount').value) || 0;
            
            if (amount < selectedGateway.min || amount > selectedGateway.max) {
                document.getElementById('summaryAmount').textContent = '$0.00';
                document.getElementById('summaryFee').textContent = '$0.00';
                document.getElementById('summaryTotal').textContent = '$0.00';
                return;
            }

            const fee = (amount * selectedGateway.feePercent / 100) + selectedGateway.feeFixed;
            const total = amount - fee;

            document.getElementById('summaryAmount').textContent = '$' + amount.toFixed(2);
            document.getElementById('summaryFee').textContent = '$' + fee.toFixed(2);
            document.getElementById('summaryTotal').textContent = '$' + total.toFixed(2);
        }

        // Form Submission
        const depositForm = document.getElementById('depositForm');
        const submitBtn = document.getElementById('submitBtn');
        const btnText = document.getElementById('btnText');
        const btnLoading = document.getElementById('btnLoading');
        const depositAlert = document.getElementById('depositAlert');

        depositForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const amount = parseFloat(document.getElementById('depositAmount').value);

            if (!amount || amount < selectedGateway.min) {
                showAlert('الحد الأدنى للإيداع هو $' + selectedGateway.min.toFixed(2), 'error');
                return;
            }

            if (amount > selectedGateway.max) {
                showAlert('الحد الأقصى للإيداع هو $' + selectedGateway.max.toFixed(2), 'error');
                return;
            }

            submitBtn.disabled = true;
            btnText.style.display = 'none';
            btnLoading.style.display = 'inline';
            depositAlert.innerHTML = '';

            const formData = new FormData(depositForm);

            try {
                const response = await fetch('p2p-deposit.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    showAlert(result.message, 'success');
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    showAlert(result.message, 'error');
                    submitBtn.disabled = false;
                    btnText.style.display = 'inline';
                    btnLoading.style.display = 'none';
                }
            } catch (error) {
                showAlert('حدث خطأ في الاتصال. حاول مرة أخرى.', 'error');
                submitBtn.disabled = false;
                btnText.style.display = 'inline';
                btnLoading.style.display = 'none';
            }
        });

        // Show Alert
        function showAlert(message, type) {
            depositAlert.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
            depositAlert.querySelector('.alert').style.display = 'block';
            
            setTimeout(() => {
                depositAlert.innerHTML = '';
            }, 5000);
        }

        // Initialize
        updateSummary();
    </script>
</body>
</html>
