<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

// Require login
require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'open_binary') {
        $pair_id = intval($_POST['pair_id'] ?? 0);
        $symbol = sanitize($_POST['symbol'] ?? '');
        $direction = sanitize($_POST['direction'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $duration = intval($_POST['duration'] ?? 60);
        
        // Validation
        if (empty($pair_id) || empty($symbol) || !in_array($direction, ['up', 'down'])) {
            json_response(['success' => false, 'message' => 'بيانات غير صحيحة'], 400);
        }
        
        if ($amount < MIN_TRADE_AMOUNT) {
            json_response(['success' => false, 'message' => 'الحد الأدنى للتداول هو $' . MIN_TRADE_AMOUNT], 400);
        }
        
        if ($amount > $user['balance']) {
            json_response(['success' => false, 'message' => 'الرصيد غير كافٍ'], 400);
        }
        
        $min_duration = get_setting($pdo, 'binary_min_duration', 60);
        $max_duration = get_setting($pdo, 'binary_max_duration', 3600);
        
        if ($duration < $min_duration || $duration > $max_duration) {
            json_response(['success' => false, 'message' => 'المدة غير صحيحة'], 400);
        }
        
        // Open binary trade
        $result = open_binary_trade($pdo, $user_id, $pair_id, $symbol, $direction, $amount, $duration);
        json_response($result);
        
    } elseif ($_POST['action'] === 'get_price') {
        $symbol = sanitize($_POST['symbol'] ?? '');
        
        if (empty($symbol)) {
            json_response(['success' => false, 'message' => 'رمز العملة مطلوب'], 400);
        }
        
        $price = get_realtime_price($pdo, $symbol);
        
        if ($price === false) {
            json_response(['success' => false, 'message' => 'فشل الحصول على السعر'], 500);
        }
        
        json_response(['success' => true, 'price' => $price]);
    }
    
    exit;
}

// Get selected pair (default BTC)
$selected_symbol = sanitize($_GET['symbol'] ?? 'BTCUSDT');

// Get trading pairs
$stmt = $pdo->prepare("SELECT * FROM trading_pairs WHERE symbol = ? AND is_active = 1 AND binary_enabled = 1");
$stmt->execute([$selected_symbol]);
$selected_pair = $stmt->fetch();

if (!$selected_pair) {
    $stmt = $pdo->prepare("SELECT * FROM trading_pairs WHERE symbol = 'BTCUSDT' AND is_active = 1");
    $stmt->execute();
    $selected_pair = $stmt->fetch();
    $selected_symbol = 'BTCUSDT';
}

// Get all pairs
$stmt = $pdo->query("SELECT * FROM trading_pairs WHERE is_active = 1 AND binary_enabled = 1 ORDER BY volume_24h DESC");
$all_pairs = $stmt->fetchAll();

// Get user's pending trades
$stmt = $pdo->prepare("
    SELECT bt.*, tp.name_ar, tp.name_en 
    FROM binary_trades bt
    JOIN trading_pairs tp ON bt.pair_id = tp.id
    WHERE bt.user_id = ? AND bt.status = 'pending'
    ORDER BY bt.expiry_time ASC
");
$stmt->execute([$user_id]);
$pending_trades = $stmt->fetchAll();

// Get user's completed trades
$stmt = $pdo->prepare("
    SELECT bt.*, tp.name_ar, tp.name_en 
    FROM binary_trades bt
    JOIN trading_pairs tp ON bt.pair_id = tp.id
    WHERE bt.user_id = ? AND bt.status IN ('won', 'lost')
    ORDER BY bt.closed_at DESC
    LIMIT 20
");
$stmt->execute([$user_id]);
$completed_trades = $stmt->fetchAll();

// Get statistics
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_trades,
        SUM(CASE WHEN status = 'won' THEN 1 ELSE 0 END) as won_trades,
        SUM(CASE WHEN status = 'lost' THEN 1 ELSE 0 END) as lost_trades,
        SUM(CASE WHEN profit_loss > 0 THEN profit_loss ELSE 0 END) as total_profit,
        SUM(CASE WHEN profit_loss < 0 THEN profit_loss ELSE 0 END) as total_loss
    FROM binary_trades
    WHERE user_id = ? AND status IN ('won', 'lost')
");
$stmt->execute([$user_id]);
$binary_stats = $stmt->fetch();

$win_rate = $binary_stats['total_trades'] > 0 
    ? ($binary_stats['won_trades'] / $binary_stats['total_trades']) * 100 
    : 0;

$payout_percentage = get_setting($pdo, 'binary_payout_percentage', 85);
$current_language = $_SESSION['language'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_language; ?>" dir="<?php echo $current_language === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الخيارات الثنائية - Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.95);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-red: #e74c3c;
            --accent-blue: #3498db;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(244, 162, 97, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(46, 204, 113, 0.03) 0%, transparent 50%);
            z-index: 0;
            pointer-events: none;
        }

        /* Top Bar */
        .top-bar {
            background: var(--secondary-bg);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
        }

        .top-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .back-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--accent-gold);
        }

        .user-balance {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .balance-value {
            font-size: 18px;
            font-weight: 900;
            color: var(--accent-green);
        }

        /* Stats Bar */
        .stats-bar {
            background: var(--secondary-bg);
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-color);
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .stat-value.green {
            color: var(--accent-green);
        }

        .stat-value.red {
            color: var(--accent-red);
        }

        .stat-label {
            font-size: 12px;
            color: var(--text-secondary);
        }

        /* Main Container */
        .trading-container {
            display: grid;
            grid-template-columns: 1fr 450px;
            height: calc(100vh - 180px);
            position: relative;
            z-index: 1;
        }

        /* Left - Trading Area */
        .trading-area {
            display: flex;
            flex-direction: column;
            padding: 30px;
            overflow-y: auto;
        }

        .trading-area::-webkit-scrollbar {
            width: 6px;
        }

        .trading-area::-webkit-scrollbar-thumb {
            background: var(--accent-gold);
            border-radius: 3px;
        }

        /* Price Display */
        .price-display {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }

        .price-display::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green));
        }

        .pair-name-big {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }

        .price-big {
            font-size: 72px;
            font-weight: 900;
            margin-bottom: 16px;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-family: 'Poppins', monospace;
        }

        .price-change-big {
            font-size: 20px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 20px;
            border-radius: 50px;
        }

        .price-change-big.positive {
            background: rgba(46, 204, 113, 0.15);
            color: var(--accent-green);
        }

        .price-change-big.negative {
            background: rgba(231, 76, 60, 0.15);
            color: var(--accent-red);
        }

        /* Trading Form */
        .trading-form {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 32px;
            margin-bottom: 30px;
        }

        .form-title {
            font-size: 22px;
            font-weight: 900;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .pair-selector {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 30px;
        }

        .pair-btn {
            padding: 16px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }

        .pair-btn:hover,
        .pair-btn.active {
            background: rgba(244, 162, 97, 0.1);
            border-color: var(--accent-gold);
        }

        .pair-btn-icon {
            font-size: 24px;
            margin-bottom: 8px;
        }

        .pair-btn-name {
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .pair-btn-symbol {
            font-size: 11px;
            color: var(--text-secondary);
        }

        .form-section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--text-secondary);
            margin-bottom: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .amount-input-group {
            display: flex;
            gap: 12px;
            margin-bottom: 16px;
        }

        .amount-input {
            flex: 1;
            padding: 18px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 20px;
            font-weight: 900;
            font-family: inherit;
            text-align: center;
        }

        .amount-input:focus {
            outline: none;
            border-color: var(--accent-gold);
        }

        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
        }

        .quick-btn {
            padding: 12px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-secondary);
            font-weight: 700;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .quick-btn:hover {
            border-color: var(--accent-gold);
            color: var(--accent-gold);
        }

        .duration-selector {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        .duration-btn {
            padding: 16px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }

        .duration-btn:hover,
        .duration-btn.active {
            background: rgba(52, 152, 219, 0.1);
            border-color: var(--accent-blue);
        }

        .duration-time {
            font-size: 20px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .duration-label {
            font-size: 11px;
            color: var(--text-secondary);
        }

        .trade-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 30px;
        }

        .trade-btn {
            padding: 24px;
            border: none;
            border-radius: 16px;
            color: white;
            font-size: 20px;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            text-transform: uppercase;
        }

        .trade-btn.up {
            background: linear-gradient(135deg, var(--accent-green), #27ae60);
            box-shadow: 0 10px 40px rgba(46, 204, 113, 0.3);
        }

        .trade-btn.up:hover:not(:disabled) {
            transform: translateY(-4px);
            box-shadow: 0 15px 50px rgba(46, 204, 113, 0.5);
        }

        .trade-btn.down {
            background: linear-gradient(135deg, var(--accent-red), #c0392b);
            box-shadow: 0 10px 40px rgba(231, 76, 60, 0.3);
        }

        .trade-btn.down:hover:not(:disabled) {
            transform: translateY(-4px);
            box-shadow: 0 15px 50px rgba(231, 76, 60, 0.5);
        }

        .trade-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .trade-btn-icon {
            font-size: 32px;
        }

        .trade-btn-text {
            font-size: 16px;
        }

        .trade-btn-payout {
            font-size: 13px;
            opacity: 0.9;
            font-weight: 600;
        }

        /* Right Sidebar - Active Trades */
        .trades-sidebar {
            background: var(--secondary-bg);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .trades-sidebar::-webkit-scrollbar {
            width: 6px;
        }

        .trades-sidebar::-webkit-scrollbar-thumb {
            background: var(--accent-gold);
            border-radius: 3px;
        }

        .sidebar-section {
            padding: 24px;
            border-bottom: 1px solid var(--border-color);
        }

        .sidebar-title {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .trades-count {
            background: var(--accent-gold);
            color: white;
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 10px;
            font-weight: 900;
        }

        /* Trade Card */
        .trade-card {
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            position: relative;
            overflow: hidden;
        }

        .trade-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
        }

        .trade-card.up::before {
            background: var(--accent-green);
        }

        .trade-card.down::before {
            background: var(--accent-red);
        }

        .trade-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        .trade-card-symbol {
            font-weight: 700;
            font-size: 16px;
        }

        .trade-card-direction {
            padding: 6px 14px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 900;
            text-transform: uppercase;
        }

        .trade-card-direction.up {
            background: rgba(46, 204, 113, 0.2);
            color: var(--accent-green);
        }

        .trade-card-direction.down {
            background: rgba(231, 76, 60, 0.2);
            color: var(--accent-red);
        }

        .trade-card-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 16px;
            font-size: 13px;
        }

        .info-label {
            color: var(--text-secondary);
            margin-bottom: 4px;
        }

        .info-value {
            font-weight: 700;
        }

        .countdown-timer {
            background: var(--glass-bg);
            border-radius: 10px;
            padding: 16px;
            text-align: center;
        }

        .countdown-label {
            font-size: 11px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .countdown-time {
            font-size: 32px;
            font-weight: 900;
            font-family: 'Poppins', monospace;
            color: var(--accent-gold);
        }

        .countdown-progress {
            width: 100%;
            height: 6px;
            background: var(--glass-bg);
            border-radius: 3px;
            margin-top: 12px;
            overflow: hidden;
        }

        .countdown-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green));
            transition: width 1s linear;
        }

        /* Completed Trade */
        .completed-card {
            opacity: 0.8;
        }

        .result-badge {
            padding: 10px 16px;
            border-radius: 10px;
            text-align: center;
            font-weight: 900;
            font-size: 14px;
            margin-top: 12px;
        }

        .result-badge.won {
            background: rgba(46, 204, 113, 0.2);
            color: var(--accent-green);
        }

        .result-badge.lost {
            background: rgba(231, 76, 60, 0.2);
            color: var(--accent-red);
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border: 1px solid rgba(46, 204, 113, 0.3);
            color: var(--accent-green);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: var(--accent-red);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }

        .empty-icon {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.3;
        }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }

        .tab {
            padding: 12px 20px;
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            position: relative;
            transition: all 0.3s;
        }

        .tab.active {
            color: var(--accent-gold);
        }

        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--accent-gold);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .stats-bar {
                grid-template-columns: repeat(2, 1fr);
            }

            .trading-container {
                grid-template-columns: 1fr;
                height: auto;
            }

            .trades-sidebar {
                position: relative;
                border-right: none;
                border-top: 1px solid var(--border-color);
            }

            .pair-selector {
                grid-template-columns: repeat(2, 1fr);
            }

            .duration-selector {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .stats-bar {
                grid-template-columns: 1fr;
            }

            .price-big {
                font-size: 48px;
            }

            .trade-buttons {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="top-left">
            <a href="dashboard.php" class="back-btn">
                ← العودة للوحة التحكم
            </a>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح:</span>
                <span class="balance-value" id="userBalance">$<?php echo number_format($user['balance'], 2); ?></span>
            </div>
        </div>
    </div>

    <!-- Stats Bar -->
    <div class="stats-bar">
        <div class="stat-item">
            <div class="stat-value"><?php echo $binary_stats['total_trades'] ?? 0; ?></div>
            <div class="stat-label">إجمالي الصفقات</div>
        </div>
        <div class="stat-item">
            <div class="stat-value green"><?php echo $binary_stats['won_trades'] ?? 0; ?></div>
            <div class="stat-label">صفقات رابحة</div>
        </div>
        <div class="stat-item">
            <div class="stat-value red"><?php echo $binary_stats['lost_trades'] ?? 0; ?></div>
            <div class="stat-label">صفقات خاسرة</div>
        </div>
        <div class="stat-item">
            <div class="stat-value" style="color: var(--accent-gold);"><?php echo number_format($win_rate, 1); ?>%</div>
            <div class="stat-label">نسبة الفوز</div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="trading-container">
        <!-- Left - Trading Area -->
        <div class="trading-area">
            <!-- Price Display -->
            <div class="price-display">
                <div class="pair-name-big"><?php echo $selected_pair['name_ar']; ?></div>
                <div class="price-big" id="currentPrice">$<?php echo number_format($selected_pair['current_price'], 2); ?></div>
                <div class="price-change-big <?php echo $selected_pair['price_change_24h'] >= 0 ? 'positive' : 'negative'; ?>" id="priceChange">
                    <span><?php echo $selected_pair['price_change_24h'] >= 0 ? '↑' : '↓'; ?></span>
                    <span><?php echo abs($selected_pair['price_change_24h']); ?>%</span>
                </div>
            </div>

            <!-- Trading Form -->
            <div class="trading-form">
                <div class="form-title">🎯 فتح صفقة ثنائية جديدة</div>

                <div id="tradeAlert"></div>

                <form id="binaryForm">
                    <input type="hidden" name="action" value="open_binary">
                    <input type="hidden" name="pair_id" id="pairId" value="<?php echo $selected_pair['id']; ?>">
                    <input type="hidden" name="symbol" id="symbol" value="<?php echo $selected_pair['symbol']; ?>">
                    <input type="hidden" name="direction" id="direction" value="">
                    <input type="hidden" name="duration" id="duration" value="60">

                    <!-- Pair Selector -->
                    <div class="form-section">
                        <div class="section-title">اختر العملة</div>
                        <div class="pair-selector">
                            <?php 
                            $top_pairs = array_slice($all_pairs, 0, 8);
                            foreach ($top_pairs as $pair): 
                            ?>
                                <div class="pair-btn <?php echo $pair['symbol'] === $selected_symbol ? 'active' : ''; ?>" 
                                     data-pair-id="<?php echo $pair['id']; ?>"
                                     data-symbol="<?php echo $pair['symbol']; ?>"
                                     onclick="selectPair(this)">
                                    <div class="pair-btn-icon">₿</div>
                                    <div class="pair-btn-name"><?php echo $pair['name_ar']; ?></div>
                                    <div class="pair-btn-symbol"><?php echo $pair['symbol']; ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Amount -->
                    <div class="form-section">
                        <div class="section-title">المبلغ</div>
                        <div class="amount-input-group">
                            <input type="number" name="amount" id="tradeAmount" class="amount-input" 
                                   placeholder="0.00" min="<?php echo MIN_TRADE_AMOUNT; ?>" 
                                   max="<?php echo $user['balance']; ?>" step="0.01" value="10" required>
                        </div>
                        <div class="quick-amounts">
                            <button type="button" class="quick-btn" onclick="setAmount(10)">$10</button>
                            <button type="button" class="quick-btn" onclick="setAmount(25)">$25</button>
                            <button type="button" class="quick-btn" onclick="setAmount(50)">$50</button>
                            <button type="button" class="quick-btn" onclick="setAmount(100)">$100</button>
                            <button type="button" class="quick-btn" onclick="setAmount(<?php echo floor($user['balance']); ?>)">الكل</button>
                        </div>
                    </div>

                    <!-- Duration -->
                    <div class="form-section">
                        <div class="section-title">المدة الزمنية</div>
                        <div class="duration-selector">
                            <div class="duration-btn active" onclick="selectDuration(this, 60)">
                                <div class="duration-time">60</div>
                                <div class="duration-label">ثانية</div>
                            </div>
                            <div class="duration-btn" onclick="selectDuration(this, 300)">
                                <div class="duration-time">5</div>
                                <div class="duration-label">دقائق</div>
                            </div>
                            <div class="duration-btn" onclick="selectDuration(this, 900)">
                                <div class="duration-time">15</div>
                                <div class="duration-label">دقيقة</div>
                            </div>
                            <div class="duration-btn" onclick="selectDuration(this, 3600)">
                                <div class="duration-time">1</div>
                                <div class="duration-label">ساعة</div>
                            </div>
                        </div>
                    </div>

                    <!-- Trade Buttons -->
                    <div class="trade-buttons">
                        <button type="button" class="trade-btn up" id="upBtn" onclick="submitTrade('up')">
                            <span class="trade-btn-icon">📈</span>
                            <span class="trade-btn-text">صعود (UP)</span>
                            <span class="trade-btn-payout">عائد: <?php echo $payout_percentage; ?>%</span>
                        </button>
                        <button type="button" class="trade-btn down" id="downBtn" onclick="submitTrade('down')">
                            <span class="trade-btn-icon">📉</span>
                            <span class="trade-btn-text">هبوط (DOWN)</span>
                            <span class="trade-btn-payout">عائد: <?php echo $payout_percentage; ?>%</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Right Sidebar - Trades -->
        <div class="trades-sidebar">
            <div class="sidebar-section">
                <div class="tabs">
                    <button class="tab active" data-tab="pending">
                        نشطة (<?php echo count($pending_trades); ?>)
                    </button>
                    <button class="tab" data-tab="completed">
                        مكتملة
                    </button>
                </div>

                <div class="tab-content active" id="pendingContent">
                    <?php if (empty($pending_trades)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">🎯</div>
                            <div>لا توجد صفقات نشطة</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pending_trades as $trade): ?>
                            <div class="trade-card <?php echo $trade['direction']; ?>" data-trade-id="<?php echo $trade['id']; ?>">
                                <div class="trade-card-header">
                                    <span class="trade-card-symbol"><?php echo $trade['symbol']; ?></span>
                                    <span class="trade-card-direction <?php echo $trade['direction']; ?>">
                                        <?php echo $trade['direction'] === 'up' ? 'صعود' : 'هبوط'; ?>
                                    </span>
                                </div>
                                <div class="trade-card-info">
                                    <div>
                                        <div class="info-label">المبلغ</div>
                                        <div class="info-value">$<?php echo number_format($trade['amount'], 2); ?></div>
                                    </div>
                                    <div>
                                        <div class="info-label">سعر الدخول</div>
                                        <div class="info-value">$<?php echo number_format($trade['entry_price'], 2); ?></div>
                                    </div>
                                    <div>
                                        <div class="info-label">العائد المحتمل</div>
                                        <div class="info-value" style="color: var(--accent-green);">
                                            $<?php echo number_format($trade['amount'] * ($trade['payout_percentage'] / 100), 2); ?>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="info-label">نسبة العائد</div>
                                        <div class="info-value"><?php echo $trade['payout_percentage']; ?>%</div>
                                    </div>
                                </div>
                                <div class="countdown-timer">
                                    <div class="countdown-label">الوقت المتبقي</div>
                                    <div class="countdown-time" data-expiry="<?php echo strtotime($trade['expiry_time']); ?>">
                                        --:--
                                    </div>
                                    <div class="countdown-progress">
                                        <div class="countdown-progress-bar" style="width: 100%;"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="tab-content" id="completedContent">
                    <?php if (empty($completed_trades)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📭</div>
                            <div>لا توجد صفقات مكتملة</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($completed_trades as $trade): ?>
                            <div class="trade-card completed-card <?php echo $trade['direction']; ?>">
                                <div class="trade-card-header">
                                    <span class="trade-card-symbol"><?php echo $trade['symbol']; ?></span>
                                    <span class="trade-card-direction <?php echo $trade['direction']; ?>">
                                        <?php echo $trade['direction'] === 'up' ? 'صعود' : 'هبوط'; ?>
                                    </span>
                                </div>
                                <div class="trade-card-info">
                                    <div>
                                        <div class="info-label">المبلغ</div>
                                        <div class="info-value">$<?php echo number_format($trade['amount'], 2); ?></div>
                                    </div>
                                    <div>
                                        <div class="info-label">الربح/الخسارة</div>
                                        <div class="info-value" style="color: <?php echo $trade['profit_loss'] >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'; ?>">
                                            <?php echo $trade['profit_loss'] >= 0 ? '+' : ''; ?>$<?php echo number_format($trade['profit_loss'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="result-badge <?php echo $trade['status']; ?>">
                                    <?php echo $trade['status'] === 'won' ? '✓ ربح' : '✗ خسارة'; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Select Pair
        function selectPair(element) {
            document.querySelectorAll('.pair-btn').forEach(btn => btn.classList.remove('active'));
            element.classList.add('active');
            
            document.getElementById('pairId').value = element.dataset.pairId;
            document.getElementById('symbol').value = element.dataset.symbol;
            
            // Redirect to update price
            window.location.href = '?symbol=' + element.dataset.symbol;
        }

        // Set Amount
        function setAmount(amount) {
            document.getElementById('tradeAmount').value = amount;
        }

        // Select Duration
        function selectDuration(element, seconds) {
            document.querySelectorAll('.duration-btn').forEach(btn => btn.classList.remove('active'));
            element.classList.add('active');
            document.getElementById('duration').value = seconds;
        }

        // Submit Trade
        async function submitTrade(direction) {
            const amount = parseFloat(document.getElementById('tradeAmount').value);
            const minAmount = <?php echo MIN_TRADE_AMOUNT; ?>;
            const maxBalance = <?php echo $user['balance']; ?>;
            
            if (!amount || amount < minAmount) {
                showAlert('الحد الأدنى للتداول هو $' + minAmount, 'error');
                return;
            }
            
            if (amount > maxBalance) {
                showAlert('الرصيد غير كافٍ', 'error');
                return;
            }
            
            document.getElementById('direction').value = direction;
            
            const upBtn = document.getElementById('upBtn');
            const downBtn = document.getElementById('downBtn');
            
            upBtn.disabled = true;
            downBtn.disabled = true;
            
            const formData = new FormData(document.getElementById('binaryForm'));
            
            try {
                const response = await fetch('binary-trading.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showAlert(result.message, 'success');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    showAlert(result.message, 'error');
                    upBtn.disabled = false;
                    downBtn.disabled = false;
                }
            } catch (error) {
                showAlert('حدث خطأ في الاتصال', 'error');
                upBtn.disabled = false;
                downBtn.disabled = false;
            }
        }

        // Show Alert
        function showAlert(message, type) {
            const alert = document.getElementById('tradeAlert');
            alert.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
            setTimeout(() => {
                alert.innerHTML = '';
            }, 5000);
        }

        // Countdown Timers
        function updateCountdowns() {
            document.querySelectorAll('.countdown-time').forEach(timer => {
                const expiry = parseInt(timer.dataset.expiry);
                const now = Math.floor(Date.now() / 1000);
                const remaining = expiry - now;
                
                if (remaining <= 0) {
                    timer.textContent = '00:00';
                    timer.parentElement.querySelector('.countdown-progress-bar').style.width = '0%';
                    
                    // Reload to update status
                    setTimeout(() => window.location.reload(), 2000);
                } else {
                    const minutes = Math.floor(remaining / 60);
                    const seconds = remaining % 60;
                    timer.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    
                    // Update progress bar
                    const tradeCard = timer.closest('.trade-card');
                    const duration = parseInt(document.getElementById('duration').value) || 60;
                    const progress = (remaining / duration) * 100;
                    timer.parentElement.querySelector('.countdown-progress-bar').style.width = progress + '%';
                }
            });
        }

        // Update every second
        setInterval(updateCountdowns, 1000);
        updateCountdowns();

        // Tabs
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;
                
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                tab.classList.add('active');
                document.getElementById(tabName + 'Content').classList.add('active');
            });
        });

        // Update price every 10 seconds
        setInterval(() => {
            fetch('binary-trading.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=get_price&symbol=<?php echo $selected_pair['symbol']; ?>'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('currentPrice').textContent = '$' + parseFloat(data.price).toFixed(2);
                }
            })
            .catch(err => console.error('Price update failed:', err));
        }, 10000);
    </script>
</body>
</html>
