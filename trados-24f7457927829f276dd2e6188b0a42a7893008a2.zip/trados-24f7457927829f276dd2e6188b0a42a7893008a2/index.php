<?php
define('APP_ACCESS', true);
require_once 'config.php';

// Redirect if logged in
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>منصة التداول الاحترافية - تداول العملات الرقمية</title>
    <meta name="description" content="منصة تداول احترافية للعملات الرقمية مع تداول فوري وخيارات ثنائية">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.8);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-blue: #3498db;
            --accent-red: #e74c3c;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
            --shadow-glow: rgba(244, 162, 97, 0.2);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .background-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            overflow: hidden;
        }

        .background-animation::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 15% 20%, rgba(244, 162, 97, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 85% 80%, rgba(46, 204, 113, 0.06) 0%, transparent 50%),
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.04) 0%, transparent 60%);
            animation: backgroundPulse 15s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.1); }
        }

        .grid-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.01) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.01) 1px, transparent 1px);
            background-size: 50px 50px;
            opacity: 0.3;
        }

        /* Navigation */
        nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 0;
            background: rgba(10, 14, 26, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            z-index: 1000;
            transition: all 0.3s;
        }

        nav.scrolled {
            padding: 15px 0;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-wrapper {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 900;
            box-shadow: 0 8px 20px rgba(244, 162, 97, 0.4);
            animation: logoFloat 3s ease-in-out infinite;
        }

        @keyframes logoFloat {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-5px) rotate(3deg); }
        }

        .logo-text {
            font-size: 24px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s;
            position: relative;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent-gold);
            transition: width 0.3s;
        }

        .nav-link:hover {
            color: var(--accent-gold);
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .nav-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 28px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-secondary {
            background: var(--glass-bg);
            color: var(--text-primary);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--accent-gold);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            color: white;
            box-shadow: 0 8px 25px rgba(244, 162, 97, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .btn-primary:hover::before {
            left: 100%;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(244, 162, 97, 0.5);
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 120px 40px 80px;
        }

        .hero-content {
            max-width: 1400px;
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 80px;
            align-items: center;
            position: relative;
            z-index: 2;
        }

        .hero-text {
            animation: slideInLeft 1s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .hero-badge {
            display: inline-block;
            padding: 8px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
            color: var(--accent-gold);
            margin-bottom: 24px;
            animation: fadeInDown 1s 0.2s both;
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-title {
            font-size: 64px;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 24px;
            background: linear-gradient(135deg, var(--text-primary) 0%, var(--accent-gold) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: fadeInUp 1s 0.4s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-subtitle {
            font-size: 20px;
            color: var(--text-secondary);
            margin-bottom: 40px;
            line-height: 1.8;
            animation: fadeInUp 1s 0.6s both;
        }

        .hero-buttons {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            animation: fadeInUp 1s 0.8s both;
        }

        .btn-large {
            padding: 18px 40px;
            font-size: 16px;
        }

        /* Hero Stats */
        .hero-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 60px;
            animation: fadeInUp 1s 1s both;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 36px;
            font-weight: 900;
            color: var(--accent-gold);
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
        }

        /* Hero Visual */
        .hero-visual {
            position: relative;
            animation: slideInRight 1s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .trading-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }

        .trading-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green), var(--accent-blue));
        }

        .market-ticker {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }

        .ticker-symbol {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .ticker-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .ticker-info h3 {
            font-size: 20px;
            margin-bottom: 4px;
        }

        .ticker-info span {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .ticker-price {
            text-align: left;
        }

        .price-value {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .price-change {
            font-size: 14px;
            font-weight: 600;
        }

        .price-change.positive {
            color: var(--accent-green);
        }

        .price-change.negative {
            color: var(--accent-red);
        }

        /* Chart Mockup */
        .chart-mockup {
            height: 300px;
            background: var(--glass-bg);
            border-radius: 16px;
            position: relative;
            overflow: hidden;
            margin-bottom: 30px;
        }

        .chart-line {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 80%;
        }

        .chart-line svg {
            width: 100%;
            height: 100%;
        }

        /* Trading Actions */
        .trading-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .action-btn {
            padding: 18px;
            border-radius: 12px;
            border: none;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: inherit;
        }

        .action-btn.buy {
            background: var(--accent-green);
            color: white;
        }

        .action-btn.sell {
            background: var(--accent-red);
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        /* Features Section */
        .features {
            padding: 120px 40px;
            position: relative;
            z-index: 2;
        }

        .features-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .section-header {
            text-align: center;
            margin-bottom: 80px;
        }

        .section-badge {
            display: inline-block;
            padding: 8px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 50px;
            font-size: 13px;
            color: var(--accent-gold);
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 48px;
            font-weight: 900;
            margin-bottom: 20px;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .section-subtitle {
            font-size: 18px;
            color: var(--text-secondary);
            max-width: 700px;
            margin: 0 auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
        }

        .feature-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 40px;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--accent-gold) 0%, transparent 100%);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .feature-card:hover::before {
            opacity: 0.03;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            border-color: var(--accent-gold);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
        }

        .feature-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin-bottom: 24px;
            box-shadow: 0 10px 30px rgba(244, 162, 97, 0.3);
            position: relative;
            z-index: 1;
        }

        .feature-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
            position: relative;
            z-index: 1;
        }

        .feature-description {
            color: var(--text-secondary);
            line-height: 1.7;
            font-size: 15px;
            position: relative;
            z-index: 1;
        }

        /* Markets Section */
        .markets {
            padding: 80px 40px;
            background: var(--secondary-bg);
            position: relative;
        }

        .markets-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .markets-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
        }

        .market-item {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 24px;
            transition: all 0.3s;
            cursor: pointer;
        }

        .market-item:hover {
            border-color: var(--accent-gold);
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }

        .market-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .market-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .market-name {
            font-size: 16px;
            font-weight: 600;
        }

        .market-symbol {
            font-size: 12px;
            color: var(--text-secondary);
        }

        .market-price {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 8px;
        }

        .market-change {
            font-size: 13px;
            font-weight: 600;
        }

        /* CTA Section */
        .cta {
            padding: 120px 40px;
            position: relative;
            z-index: 2;
        }

        .cta-container {
            max-width: 1000px;
            margin: 0 auto;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 32px;
            padding: 80px 60px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .cta-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--accent-gold) 0%, var(--accent-green) 100%);
            opacity: 0.05;
        }

        .cta-title {
            font-size: 48px;
            font-weight: 900;
            margin-bottom: 20px;
            position: relative;
        }

        .cta-subtitle {
            font-size: 20px;
            color: var(--text-secondary);
            margin-bottom: 40px;
            position: relative;
        }

        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            position: relative;
        }

        /* Footer */
        footer {
            background: var(--secondary-bg);
            border-top: 1px solid var(--border-color);
            padding: 60px 40px 30px;
            position: relative;
            z-index: 2;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .footer-content {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 60px;
            margin-bottom: 40px;
        }

        .footer-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }

        .footer-description {
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 24px;
        }

        .footer-title {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 12px;
        }

        .footer-links a {
            color: var(--text-secondary);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: var(--accent-gold);
        }

        .footer-bottom {
            padding-top: 30px;
            border-top: 1px solid var(--border-color);
            text-align: center;
            color: var(--text-secondary);
            font-size: 14px;
        }

        /* Mobile Menu */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--text-primary);
            font-size: 24px;
            cursor: pointer;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .hero-content {
                grid-template-columns: 1fr;
                gap: 60px;
            }

            .hero-visual {
                order: -1;
            }

            .features-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .markets-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .footer-content {
                grid-template-columns: repeat(2, 1fr);
                gap: 40px;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .hero-title {
                font-size: 42px;
            }

            .hero-subtitle {
                font-size: 16px;
            }

            .hero-stats {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .features-grid,
            .markets-grid {
                grid-template-columns: 1fr;
            }

            .section-title {
                font-size: 36px;
            }

            .cta-container {
                padding: 60px 40px;
            }

            .cta-title {
                font-size: 36px;
            }

            .footer-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }
        }
    </style>
</head>
<body>
    <div class="background-animation">
        <div class="grid-overlay"></div>
    </div>

    <!-- Navigation -->
    <nav id="navbar">
        <div class="nav-container">
            <div class="logo-wrapper">
                <div class="logo-icon">₿</div>
                <span class="logo-text">Trading Pro</span>
            </div>

            <div class="nav-links">
                <a href="#features" class="nav-link">المميزات</a>
                <a href="#markets" class="nav-link">الأسواق</a>
                <a href="#about" class="nav-link">عن المنصة</a>
                <a href="#contact" class="nav-link">اتصل بنا</a>
            </div>

            <div class="nav-buttons">
                <a href="login.php" class="btn btn-secondary">تسجيل دخول</a>
                <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
            </div>

            <button class="mobile-menu-btn">☰</button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <div class="hero-text">
                <span class="hero-badge">🚀 منصة التداول الأكثر تطوراً</span>
                <h1 class="hero-title">تداول العملات الرقمية باحترافية</h1>
                <p class="hero-subtitle">
                    منصة تداول متقدمة توفر لك تجربة تداول سلسة وآمنة مع أدوات احترافية وأسعار حقيقية ومباشرة من الأسواق العالمية
                </p>
                
                <div class="hero-buttons">
                    <a href="register.php" class="btn btn-primary btn-large">
                        ابدأ التداول الآن
                        <span>→</span>
                    </a>
                    <a href="#features" class="btn btn-secondary btn-large">
                        اكتشف المزيد
                    </a>
                </div>

                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-value">10K+</div>
                        <div class="stat-label">مستخدم نشط</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">$50M+</div>
                        <div class="stat-label">حجم التداول اليومي</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">99.9%</div>
                        <div class="stat-label">نسبة الاستقرار</div>
                    </div>
                </div>
            </div>

            <div class="hero-visual">
                <div class="trading-card">
                    <div class="market-ticker">
                        <div class="ticker-symbol">
                            <div class="ticker-icon">₿</div>
                            <div class="ticker-info">
                                <h3>Bitcoin</h3>
                                <span>BTC/USDT</span>
                            </div>
                        </div>
                        <div class="ticker-price">
                            <div class="price-value">$67,234.50</div>
                            <div class="price-change positive">+2.34% ↑</div>
                        </div>
                    </div>

                    <div class="chart-mockup">
                        <div class="chart-line">
                            <svg viewBox="0 0 400 240" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                                        <stop offset="0%" style="stop-color:#2ecc71;stop-opacity:0.3" />
                                        <stop offset="100%" style="stop-color:#2ecc71;stop-opacity:0" />
                                    </linearGradient>
                                </defs>
                                <path d="M 0 200 Q 50 180, 100 150 T 200 120 T 300 80 T 400 60" 
                                      stroke="#2ecc71" 
                                      stroke-width="3" 
                                      fill="none" 
                                      stroke-linecap="round"/>
                                <path d="M 0 200 Q 50 180, 100 150 T 200 120 T 300 80 T 400 60 L 400 240 L 0 240 Z" 
                                      fill="url(#gradient)"/>
                            </svg>
                        </div>
                    </div>

                    <div class="trading-actions">
                        <button class="action-btn buy">شراء 📈</button>
                        <button class="action-btn sell">بيع 📉</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="features-container">
            <div class="section-header">
                <span class="section-badge">✨ لماذا تختارنا</span>
                <h2 class="section-title">مميزات استثنائية</h2>
                <p class="section-subtitle">
                    نوفر لك كل ما تحتاجه لتجربة تداول احترافية وآمنة مع أفضل الأدوات والخدمات
                </p>
            </div>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3 class="feature-title">تنفيذ فوري</h3>
                    <p class="feature-description">
                        تنفيذ الصفقات بسرعة فائقة مع أسعار حقيقية من الأسواق العالمية دون أي تأخير
                    </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3 class="feature-title">أمان عالي</h3>
                    <p class="feature-description">
                        حماية متقدمة لحسابك وأموالك مع تشفير من الدرجة البنكية ونظام أمان متعدد الطبقات
                    </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">📊</div>
                    <h3 class="feature-title">رسوم بيانية احترافية</h3>
                    <p class="feature-description">
                        أدوات تحليل فني متقدمة مع رسوم بيانية تفاعلية من TradingView لاتخاذ قرارات أفضل
                    </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">💰</div>
                    <h3 class="feature-title">رسوم منخفضة</h3>
                    <p class="feature-description">
                        رسوم تداول تنافسية تبدأ من 0.1% فقط على جميع عمليات التداول
                    </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3 class="feature-title">خيارات ثنائية</h3>
                    <p class="feature-description">
                        تداول الخيارات الثنائية بعوائد تصل إلى 85% مع فترات تداول مرنة من 60 ثانية
                    </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">💳</div>
                    <h3 class="feature-title">إيداع وسحب سريع</h3>
                    <p class="feature-description">
                        طرق متعددة للإيداع والسحب مع معالجة فورية لطلباتك
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Markets Section -->
    <section class="markets" id="markets">
        <div class="markets-container">
            <div class="section-header">
                <span class="section-badge">📈 الأسواق</span>
                <h2 class="section-title">العملات المتاحة</h2>
                <p class="section-subtitle">
                    تداول أشهر العملات الرقمية بأسعار حقيقية ومباشرة
                </p>
            </div>

            <div class="markets-grid">
                <div class="market-item">
                    <div class="market-header">
                        <div class="market-icon">₿</div>
                        <div>
                            <div class="market-name">Bitcoin</div>
                            <div class="market-symbol">BTC/USDT</div>
                        </div>
                    </div>
                    <div class="market-price">$67,234.50</div>
                    <div class="market-change positive">+2.34% ↑</div>
                </div>

                <div class="market-item">
                    <div class="market-header">
                        <div class="market-icon">Ξ</div>
                        <div>
                            <div class="market-name">Ethereum</div>
                            <div class="market-symbol">ETH/USDT</div>
                        </div>
                    </div>
                    <div class="market-price">$3,456.78</div>
                    <div class="market-change positive">+1.89% ↑</div>
                </div>

                <div class="market-item">
                    <div class="market-header">
                        <div class="market-icon">◆</div>
                        <div>
                            <div class="market-name">Binance Coin</div>
                            <div class="market-symbol">BNB/USDT</div>
                        </div>
                    </div>
                    <div class="market-price">$312.45</div>
                    <div class="market-change negative">-0.56% ↓</div>
                </div>

                <div class="market-item">
                    <div class="market-header">
                        <div class="market-icon">◉</div>
                        <div>
                            <div class="market-name">Cardano</div>
                            <div class="market-symbol">ADA/USDT</div>
                        </div>
                    </div>
                    <div class="market-price">$0.4523</div>
                    <div class="market-change positive">+3.12% ↑</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="cta-container">
            <h2 class="cta-title">جاهز لبدء التداول؟</h2>
            <p class="cta-subtitle">
                انضم إلى آلاف المتداولين واستمتع بتجربة تداول احترافية
            </p>
            <div class="cta-buttons">
                <a href="register.php" class="btn btn-primary btn-large">
                    إنشاء حساب مجاني
                    <span>→</span>
                </a>
                <a href="login.php" class="btn btn-secondary btn-large">
                    لديك حساب؟ سجل دخول
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div>
                    <div class="footer-brand">
                        <div class="logo-icon">₿</div>
                        <span class="logo-text">Trading Pro</span>
                    </div>
                    <p class="footer-description">
                        منصة تداول عملات رقمية احترافية توفر لك أفضل تجربة تداول مع أمان عالي وأدوات متقدمة
                    </p>
                </div>

                <div>
                    <h4 class="footer-title">روابط سريعة</h4>
                    <ul class="footer-links">
                        <li><a href="#features">المميزات</a></li>
                        <li><a href="#markets">الأسواق</a></li>
                        <li><a href="#about">عن المنصة</a></li>
                        <li><a href="#contact">اتصل بنا</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="footer-title">الدعم</h4>
                    <ul class="footer-links">
                        <li><a href="#">مركز المساعدة</a></li>
                        <li><a href="#">الأسئلة الشائعة</a></li>
                        <li><a href="#">دليل الاستخدام</a></li>
                        <li><a href="#">تواصل معنا</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="footer-title">قانوني</h4>
                    <ul class="footer-links">
                        <li><a href="#">الشروط والأحكام</a></li>
                        <li><a href="#">سياسة الخصوصية</a></li>
                        <li><a href="#">سياسة الاسترداد</a></li>
                        <li><a href="#">إخلاء المسؤولية</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 Trading Pro. جميع الحقوق محفوظة.</p>
            </div>
        </div>
    </footer>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Animate chart
        const animateChart = () => {
            const path = document.querySelector('.chart-line path[stroke="#2ecc71"]');
            if (path) {
                const length = path.getTotalLength();
                path.style.strokeDasharray = length;
                path.style.strokeDashoffset = length;
                path.style.animation = 'drawLine 2s ease-in-out forwards';
            }
        };

        // Add keyframe animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes drawLine {
                to {
                    stroke-dashoffset: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Run animation on load
        window.addEventListener('load', animateChart);

        // Update market prices (simulation)
        setInterval(() => {
            document.querySelectorAll('.market-price, .price-value').forEach(el => {
                const current = parseFloat(el.textContent.replace(/[^0-9.]/g, ''));
                const change = (Math.random() - 0.5) * 100;
                const newPrice = (current + change).toFixed(2);
                el.textContent = el.classList.contains('market-price') ? 
                    `$${newPrice}` : 
                    `$${newPrice}`;
            });
        }, 5000);
    </script>
</body>
</html>
