<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Filters
$type_filter = sanitize($_GET['type'] ?? 'all');
$status_filter = sanitize($_GET['status'] ?? 'all');
$search = sanitize($_GET['search'] ?? '');
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query
$where = ["user_id = ?"];
$params = [$user_id];

if ($type_filter !== 'all') {
    $where[] = "type = ?";
    $params[] = $type_filter;
}

if ($status_filter !== 'all') {
    $where[] = "status = ?";
    $params[] = $status_filter;
}

if (!empty($search)) {
    $where[] = "(transaction_id LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = implode(' AND ', $where);

// Get total count
try {
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE $where_clause");
    $count_stmt->execute($params);
    $total_records = $count_stmt->fetchColumn();
    $total_pages = ceil($total_records / $per_page);
} catch (PDOException $e) {
    error_log("Count transactions error: " . $e->getMessage());
    $total_records = 0;
    $total_pages = 1;
}

// Get transactions
try {
    $stmt = $pdo->prepare("
        SELECT * FROM transactions 
        WHERE $where_clause
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
    ");
    
    $params[] = $per_page;
    $params[] = $offset;
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Get transactions error: " . $e->getMessage());
    $transactions = [];
}

// Get statistics
$stats = [
    'total_deposits' => 0,
    'total_withdrawals' => 0,
    'pending_count' => 0,
    'completed_count' => 0
];

try {
    $stmt = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
            SUM(CASE WHEN type = 'withdrawal' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
            COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count
        FROM transactions
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Get transaction stats error: " . $e->getMessage());
}

$notifications = get_user_notifications($pdo, $user_id, false, 5);
$unread_count = count(get_user_notifications($pdo, $user_id, true));
$current_language = $_SESSION['language'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المعاملات المالية - Trading Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --warning: #F59E0B;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar - Same as dashboard */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-card {
            padding: 20px;
            margin: 20px;
            background: rgba(249, 158, 11, 0.05);
            border: 1px solid rgba(249, 158, 11, 0.1);
            border-radius: 16px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .user-name {
            font-weight: 700;
            font-size: 16px;
        }

        .user-balance {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 12px;
            color: var(--text-muted);
        }

        .balance-value {
            font-size: 20px;
            font-weight: 900;
            color: var(--success);
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(249, 158, 11, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent);
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main Content */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
            transition: color 0.3s;
        }

        .breadcrumb a:hover {
            color: var(--accent);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            background: radial-gradient(circle, rgba(249, 158, 11, 0.1), transparent);
            border-radius: 50%;
            transform: translate(30%, -30%);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 12px;
        }

        .stat-icon.deposit { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .stat-icon.withdrawal { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .stat-icon.pending { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .stat-icon.completed { background: rgba(59, 130, 246, 0.1); color: var(--info); }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 4px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 900;
            color: var(--text);
        }

        /* Filters */
        .filters-section {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .filters-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .filters-title {
            font-size: 18px;
            font-weight: 700;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .filter-input,
        .filter-select {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
            transition: all 0.3s;
        }

        .filter-input:focus,
        .filter-select:focus {
            outline: none;
            border-color: var(--accent);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #DC2626);
            color: white;
            box-shadow: 0 8px 24px rgba(249, 158, 11, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(249, 158, 11, 0.4);
        }

        .btn-secondary {
            background: var(--secondary);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #2D3748;
        }

        /* Transactions Table */
        .transactions-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
        }

        .transactions-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
        }

        .transactions-title {
            font-size: 20px;
            font-weight: 700;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(249, 158, 11, 0.05);
        }

        th {
            padding: 16px 24px;
            text-align: right;
            font-weight: 700;
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
        }

        tbody tr {
            transition: background 0.2s;
        }

        tbody tr:hover {
            background: rgba(249, 158, 11, 0.02);
        }

        .transaction-id {
            font-family: monospace;
            color: var(--accent);
            font-weight: 600;
        }

        .transaction-type {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .transaction-type.deposit {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .transaction-type.withdrawal {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .transaction-type.trade {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .transaction-type.fee {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .amount {
            font-weight: 700;
            font-size: 16px;
        }

        .amount.positive { color: var(--success); }
        .amount.negative { color: var(--danger); }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-badge.completed {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .status-badge.rejected {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .status-badge.processing {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .status-badge i {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .transaction-date {
            font-size: 13px;
            color: var(--text-muted);
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 24px;
            border-top: 1px solid var(--border);
        }

        .pagination-btn {
            padding: 8px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .pagination-btn:hover:not(.disabled) {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }

        .pagination-btn.active {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }

        .pagination-btn.disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }

        .pagination-info {
            padding: 8px 16px;
            color: var(--text-muted);
            font-size: 14px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 64px 24px;
        }

        .empty-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 24px;
            background: rgba(249, 158, 11, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: var(--accent);
        }

        .empty-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .empty-text {
            color: var(--text-muted);
            margin-bottom: 24px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
                transition: transform 0.3s;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .filters-grid {
                grid-template-columns: 1fr;
            }

            .table-wrapper {
                overflow-x: scroll;
            }

            table {
                min-width: 800px;
            }

            .page-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">₿</div>
                <div class="logo-text">Trading Pro</div>
            </div>
        </div>

        <div class="user-card">
            <div class="user-info">
                <div class="user-avatar"><?= strtoupper(substr($user['username'], 0, 2)) ?></div>
                <div>
                    <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                    <div class="user-email" style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($user['email']) ?></div>
                </div>
            </div>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح</span>
                <span class="balance-value">$<?= number_format($user['balance'], 2) ?></span>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">القائمة الرئيسية</div>
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="spot-trading.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>تداول فوري</span>
            </a>
            <a href="binary-trading.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                <span>خيارات ثنائية</span>
            </a>
            <a href="p2p-deposit.php" class="nav-item">
                <i class="fas fa-wallet"></i>
                <span>إضافة رصيد P2P</span>
            </a>
            
            <div class="nav-section-title">الحساب</div>
            <a href="transactions.php" class="nav-item active">
                <i class="fas fa-receipt"></i>
                <span>المعاملات</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="fas fa-user"></i>
                <span>الملف الشخصي</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main">
        <div class="header">
            <div class="header-top">
                <div>
                    <h1 class="page-title">المعاملات المالية</h1>
                    <div class="breadcrumb">
                        <a href="dashboard.php">الرئيسية</a>
                        <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                        <span>المعاملات</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon deposit">
                    <i class="fas fa-arrow-down"></i>
                </div>
                <div class="stat-label">إجمالي الإيداعات</div>
                <div class="stat-value amount positive">$<?= number_format($stats['total_deposits'] ?? 0, 2) ?></div>
            </div>

            <div class="stat-card">
                <div class="stat-icon withdrawal">
                    <i class="fas fa-arrow-up"></i>
                </div>
                <div class="stat-label">إجمالي السحوبات</div>
                <div class="stat-value amount negative">$<?= number_format($stats['total_withdrawals'] ?? 0, 2) ?></div>
            </div>

            <div class="stat-card">
                <div class="stat-icon pending">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-label">معاملات قيد الانتظار</div>
                <div class="stat-value"><?= $stats['pending_count'] ?? 0 ?></div>
            </div>

            <div class="stat-card">
                <div class="stat-icon completed">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-label">معاملات مكتملة</div>
                <div class="stat-value"><?= $stats['completed_count'] ?? 0 ?></div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <div class="filters-header">
                <h3 class="filters-title">تصفية المعاملات</h3>
                <?php if ($type_filter !== 'all' || $status_filter !== 'all' || !empty($search)): ?>
                    <a href="transactions.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        إعادة تعيين
                    </a>
                <?php endif; ?>
            </div>
            
            <form method="GET" action="transactions.php">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">نوع المعاملة</label>
                        <select name="type" class="filter-select" onchange="this.form.submit()">
                            <option value="all" <?= $type_filter === 'all' ? 'selected' : '' ?>>الكل</option>
                            <option value="deposit" <?= $type_filter === 'deposit' ? 'selected' : '' ?>>إيداع</option>
                            <option value="withdrawal" <?= $type_filter === 'withdrawal' ? 'selected' : '' ?>>سحب</option>
                            <option value="trade" <?= $type_filter === 'trade' ? 'selected' : '' ?>>تداول</option>
                            <option value="fee" <?= $type_filter === 'fee' ? 'selected' : '' ?>>رسوم</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">الحالة</label>
                        <select name="status" class="filter-select" onchange="this.form.submit()">
                            <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>الكل</option>
                            <option value="completed" <?= $status_filter === 'completed' ? 'selected' : '' ?>>مكتمل</option>
                            <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                            <option value="processing" <?= $status_filter === 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                            <option value="rejected" <?= $status_filter === 'rejected' ? 'selected' : '' ?>>مرفوض</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">بحث</label>
                        <input type="text" name="search" class="filter-input" placeholder="رقم المعاملة أو الوصف..." value="<?= htmlspecialchars($search) ?>">
                    </div>

                    <div class="filter-group">
                        <label class="filter-label" style="opacity: 0;">بحث</label>
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-search"></i>
                            بحث
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Transactions Table -->
        <div class="transactions-card">
            <div class="transactions-header">
                <h3 class="transactions-title">سجل المعاملات (<?= $total_records ?> معاملة)</h3>
            </div>

            <?php if (empty($transactions)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                    <h3 class="empty-title">لا توجد معاملات</h3>
                    <p class="empty-text">لم تقم بأي معاملات حتى الآن</p>
                    <a href="p2p-deposit.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        إضافة رصيد الآن
                    </a>
                </div>
            <?php else: ?>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>رقم المعاملة</th>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>الحالة</th>
                                <th>الوصف</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td>
                                        <span class="transaction-id">#<?= htmlspecialchars($transaction['transaction_id']) ?></span>
                                    </td>
                                    <td>
                                        <span class="transaction-type <?= htmlspecialchars($transaction['type']) ?>">
                                            <?php 
                                            $icons = [
                                                'deposit' => 'arrow-down',
                                                'withdrawal' => 'arrow-up',
                                                'trade' => 'exchange-alt',
                                                'fee' => 'receipt'
                                            ];
                                            $names = [
                                                'deposit' => 'إيداع',
                                                'withdrawal' => 'سحب',
                                                'trade' => 'تداول',
                                                'fee' => 'رسوم'
                                            ];
                                            ?>
                                            <i class="fas fa-<?= $icons[$transaction['type']] ?? 'circle' ?>"></i>
                                            <?= $names[$transaction['type']] ?? $transaction['type'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="amount <?= in_array($transaction['type'], ['deposit']) ? 'positive' : (in_array($transaction['type'], ['withdrawal', 'fee']) ? 'negative' : '') ?>">
                                            <?= in_array($transaction['type'], ['deposit']) ? '+' : (in_array($transaction['type'], ['withdrawal', 'fee']) ? '-' : '') ?>
                                            $<?= number_format($transaction['amount'], 2) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge <?= htmlspecialchars($transaction['status']) ?>">
                                            <?php
                                            $status_icons = [
                                                'completed' => 'check-circle',
                                                'pending' => 'clock',
                                                'processing' => 'spinner',
                                                'rejected' => 'times-circle'
                                            ];
                                            $status_names = [
                                                'completed' => 'مكتمل',
                                                'pending' => 'قيد الانتظار',
                                                'processing' => 'قيد المعالجة',
                                                'rejected' => 'مرفوض'
                                            ];
                                            ?>
                                            <i class="fas fa-<?= $status_icons[$transaction['status']] ?? 'circle' ?>"></i>
                                            <?= $status_names[$transaction['status']] ?? $transaction['status'] ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['description'] ?? 'لا يوجد وصف') ?></td>
                                    <td>
                                        <div class="transaction-date">
                                            <?= date('Y/m/d', strtotime($transaction['created_at'])) ?>
                                            <br>
                                            <small style="color: var(--text-muted);"><?= date('h:i A', strtotime($transaction['created_at'])) ?></small>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>&type=<?= $type_filter ?>&status=<?= $status_filter ?>&search=<?= urlencode($search) ?>" class="pagination-btn">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php else: ?>
                            <span class="pagination-btn disabled">
                                <i class="fas fa-chevron-right"></i>
                            </span>
                        <?php endif; ?>

                        <span class="pagination-info">صفحة <?= $page ?> من <?= $total_pages ?></span>

                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?= $page + 1 ?>&type=<?= $type_filter ?>&status=<?= $status_filter ?>&search=<?= urlencode($search) ?>" class="pagination-btn">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        <?php else: ?>
                            <span class="pagination-btn disabled">
                                <i class="fas fa-chevron-left"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>

    <script>
        // Auto-refresh pending transactions every 30 seconds
        <?php if (!empty(array_filter($transactions, fn($t) => $t['status'] === 'pending'))): ?>
        setTimeout(() => {
            location.reload();
        }, 30000);
        <?php endif; ?>
    </script>
</body>
</html>
