<?php
define('APP_ACCESS', true);
require_once 'config.php';

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

// Handle registration request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $full_name = sanitize($_POST['full_name'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $country = sanitize($_POST['country'] ?? '');
        $language = $_POST['language'] ?? 'ar';
        
        // Validation
        if (empty($username) || empty($email) || empty($password) || empty($full_name)) {
            json_response(['success' => false, 'message' => 'يرجى ملء جميع الحقول المطلوبة'], 400);
        }
        
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            json_response(['success' => false, 'message' => 'كلمة المرور يجب أن تكون ' . PASSWORD_MIN_LENGTH . ' أحرف على الأقل'], 400);
        }
        
        if ($password !== $confirm_password) {
            json_response(['success' => false, 'message' => 'كلمات المرور غير متطابقة'], 400);
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_response(['success' => false, 'message' => 'البريد الإلكتروني غير صحيح'], 400);
        }
        
        // Check if username exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            json_response(['success' => false, 'message' => 'اسم المستخدم موجود بالفعل'], 409);
        }
        
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            json_response(['success' => false, 'message' => 'البريد الإلكتروني مسجل بالفعل'], 409);
        }
        
        // Create user
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password, full_name, phone, country, language, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $username,
            $email,
            $hashed_password,
            $full_name,
            $phone,
            $country,
            $language,
            get_client_ip()
        ]);
        
        $user_id = $pdo->lastInsertId();
        
        log_activity($pdo, 'registration', 'New user registered', $user_id);
        
        // Auto login
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['language'] = $language;
        
        json_response([
            'success' => true,
            'message' => 'تم التسجيل بنجاح',
            'redirect' => 'dashboard.php'
        ]);
        
    } catch (Exception $e) {
        error_log("Registration error: " . $e->getMessage());
        json_response(['success' => false, 'message' => 'حدث خطأ، يرجى المحاولة مرة أخرى'], 500);
    }
}

$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب جديد - Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.8);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-red: #e74c3c;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(244, 162, 97, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(46, 204, 113, 0.03) 0%, transparent 50%);
            animation: gradientShift 20s ease infinite;
            z-index: 0;
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .register-container {
            width: 100%;
            max-width: 580px;
            position: relative;
            z-index: 2;
            animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .register-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 24px;
            padding: 48px 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            position: relative;
        }

        .register-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green));
        }

        .logo-container {
            text-align: center;
            margin-bottom: 36px;
        }

        .logo {
            width: 60px;
            height: 60px;
            margin: 0 auto 16px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 900;
            color: white;
            box-shadow: 0 10px 30px rgba(244, 162, 97, 0.3);
        }

        h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 6px;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            color: var(--text-secondary);
            font-size: 14px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row .form-group {
            margin-bottom: 0;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-secondary);
        }

        label span {
            color: var(--accent-red);
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            color: var(--text-secondary);
            transition: color 0.3s;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 14px 16px 14px 48px;
            background: var(--glass-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            color: var(--text-primary);
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s;
            outline: none;
        }

        select {
            padding: 14px 16px;
        }

        input:focus,
        select:focus {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(244, 162, 97, 0.1);
        }

        input:focus + .input-icon {
            color: var(--accent-gold);
        }

        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 8px;
            background: rgba(255, 255, 255, 0.1);
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s;
            border-radius: 2px;
        }

        .strength-weak { width: 33%; background: var(--accent-red); }
        .strength-medium { width: 66%; background: #f39c12; }
        .strength-strong { width: 100%; background: var(--accent-green); }

        .terms-checkbox {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin: 24px 0;
        }

        .terms-checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--accent-gold);
            margin-top: 2px;
        }

        .terms-checkbox label {
            margin: 0;
            font-size: 13px;
            line-height: 1.5;
        }

        .terms-checkbox a {
            color: var(--accent-gold);
            text-decoration: none;
        }

        .btn-register {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 10px 30px rgba(244, 162, 97, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-register::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn-register:hover::before {
            left: 100%;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(244, 162, 97, 0.4);
        }

        .btn-register:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .divider {
            display: flex;
            align-items: center;
            gap: 16px;
            margin: 28px 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }

        .divider span {
            color: var(--text-secondary);
            font-size: 13px;
        }

        .login-link {
            text-align: center;
            font-size: 14px;
            color: var(--text-secondary);
        }

        .login-link a {
            color: var(--accent-gold);
            text-decoration: none;
            font-weight: 600;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 13px;
            display: none;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border: 1px solid rgba(46, 204, 113, 0.3);
            color: var(--accent-green);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: var(--accent-red);
        }

        .loading-spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .form-row .form-group {
                margin-bottom: 20px;
            }
            
            .form-row .form-group:last-child {
                margin-bottom: 0;
            }

            .register-card {
                padding: 32px 24px;
            }

            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-card">
            <div class="logo-container">
                <div class="logo">₿</div>
                <h1>إنشاء حساب جديد</h1>
                <p class="subtitle">انضم إلينا وابدأ التداول الآن</p>
            </div>

            <div id="alert" class="alert"></div>

            <form id="registerForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="language" value="ar">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">اسم المستخدم <span>*</span></label>
                        <div class="input-wrapper">
                            <input type="text" id="username" name="username" required autocomplete="username">
                            <span class="input-icon">👤</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="full_name">الاسم الكامل <span>*</span></label>
                        <div class="input-wrapper">
                            <input type="text" id="full_name" name="full_name" required autocomplete="name">
                            <span class="input-icon">📝</span>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">البريد الإلكتروني <span>*</span></label>
                    <div class="input-wrapper">
                        <input type="email" id="email" name="email" required autocomplete="email">
                        <span class="input-icon">✉️</span>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">رقم الهاتف</label>
                        <div class="input-wrapper">
                            <input type="text" id="phone" name="phone" autocomplete="tel">
                            <span class="input-icon">📱</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="country">الدولة</label>
                        <select id="country" name="country">
                            <option value="">اختر الدولة</option>
                            <option value="EG">مصر</option>
                            <option value="SA">السعودية</option>
                            <option value="AE">الإمارات</option>
                            <option value="KW">الكويت</option>
                            <option value="QA">قطر</option>
                            <option value="BH">البحرين</option>
                            <option value="OM">عمان</option>
                            <option value="JO">الأردن</option>
                            <option value="LB">لبنان</option>
                            <option value="IQ">العراق</option>
                            <option value="SY">سوريا</option>
                            <option value="YE">اليمن</option>
                            <option value="MA">المغرب</option>
                            <option value="DZ">الجزائر</option>
                            <option value="TN">تونس</option>
                            <option value="LY">ليبيا</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">كلمة المرور <span>*</span></label>
                    <div class="input-wrapper">
                        <input type="password" id="password" name="password" required autocomplete="new-password">
                        <span class="input-icon">🔒</span>
                    </div>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strengthBar"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">تأكيد كلمة المرور <span>*</span></label>
                    <div class="input-wrapper">
                        <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password">
                        <span class="input-icon">🔒</span>
                    </div>
                </div>

                <div class="terms-checkbox">
                    <input type="checkbox" id="terms" required>
                    <label for="terms">
                        أوافق على <a href="#" target="_blank">الشروط والأحكام</a> و <a href="#" target="_blank">سياسة الخصوصية</a>
                    </label>
                </div>

                <button type="submit" class="btn-register" id="registerBtn">
                    <span id="btnText">إنشاء حساب</span>
                    <div class="loading-spinner" id="spinner"></div>
                </button>
            </form>

            <div class="divider">
                <span>لديك حساب بالفعل؟</span>
            </div>

            <div class="login-link">
                <a href="login.php">تسجيل الدخول</a>
            </div>
        </div>
    </div>

    <script>
        const registerForm = document.getElementById('registerForm');
        const registerBtn = document.getElementById('registerBtn');
        const btnText = document.getElementById('btnText');
        const spinner = document.getElementById('spinner');
        const alert = document.getElementById('alert');
        const passwordInput = document.getElementById('password');
        const strengthBar = document.getElementById('strengthBar');

        // Password strength checker
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
            if (password.match(/[0-9]/)) strength++;
            if (password.match(/[^a-zA-Z0-9]/)) strength++;
            
            strengthBar.className = 'password-strength-bar';
            if (strength >= 3) {
                strengthBar.classList.add('strength-strong');
            } else if (strength >= 2) {
                strengthBar.classList.add('strength-medium');
            } else if (strength >= 1) {
                strengthBar.classList.add('strength-weak');
            } else {
                strengthBar.style.width = '0%';
            }
        });

        // Form submission
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                alert.textContent = 'كلمات المرور غير متطابقة';
                alert.className = 'alert alert-error';
                alert.style.display = 'block';
                return;
            }
            
            registerBtn.disabled = true;
            btnText.style.display = 'none';
            spinner.style.display = 'block';
            alert.style.display = 'none';

            const formData = new FormData(registerForm);

            try {
                const response = await fetch('register.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    alert.textContent = result.message;
                    alert.className = 'alert alert-success';
                    alert.style.display = 'block';
                    
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1500);
                } else {
                    alert.textContent = result.message;
                    alert.className = 'alert alert-error';
                    alert.style.display = 'block';
                    
                    registerBtn.disabled = false;
                    btnText.style.display = 'inline';
                    spinner.style.display = 'none';
                }
            } catch (error) {
                alert.textContent = 'حدث خطأ في الاتصال. حاول مرة أخرى.';
                alert.className = 'alert alert-error';
                alert.style.display = 'block';
                
                registerBtn.disabled = false;
                btnText.style.display = 'inline';
                spinner.style.display = 'none';
            }
        });
    </script>
</body>
</html>
