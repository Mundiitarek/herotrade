<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$stats = get_user_statistics($pdo, $user_id);
$open_spot_trades = get_user_open_spot_trades($pdo, $user_id);
$recent_transactions = get_user_transactions($pdo, $user_id, 10);
$markets = get_market_overview($pdo);
$notifications = get_user_notifications($pdo, $user_id, false, 5);
$unread_count = count(get_user_notifications($pdo, $user_id, true));

$current_language = $_SESSION['language'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - Trading Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-card {
            padding: 20px;
            margin: 20px;
            background: rgba(249, 158, 11, 0.05);
            border: 1px solid rgba(249, 158, 11, 0.1);
            border-radius: 16px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .user-name {
            font-weight: 700;
            font-size: 16px;
        }

        .user-balance {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 12px;
            color: var(--text-muted);
        }

        .balance-value {
            font-size: 20px;
            font-weight: 900;
            color: var(--success);
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(249, 158, 11, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent);
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        .nav-badge {
            margin-right: auto;
            background: var(--danger);
            color: white;
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 700;
        }

        /* Main Content */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .header-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #DC2626);
            color: white;
            box-shadow: 0 8px 24px rgba(249, 158, 11, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(249, 158, 11, 0.4);
        }

        .btn-secondary {
            background: var(--secondary);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #2D3748;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 32px rgba(0,0,0,0.4);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent), #DC2626);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(249, 158, 11, 0.1);
            color: var(--accent);
        }

        .stat-icon.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .stat-icon.danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .stat-icon.info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .stat-value {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 8px;
            font-family: 'Poppins', sans-serif;
        }

        .stat-change {
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .stat-change.positive {
            color: var(--success);
        }

        .stat-change.negative {
            color: var(--danger);
        }

        /* Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 32px;
        }

        .card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }

        .card-title {
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-title i {
            color: var(--accent);
        }

        .card-link {
            color: var(--accent);
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .card-link:hover {
            gap: 10px;
        }

        /* Table */
        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table thead th {
            text-align: right;
            padding: 12px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border);
        }

        .table tbody td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        .table tbody tr:hover {
            background: rgba(249, 158, 11, 0.03);
        }

        .trade-symbol {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .trade-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            color: white;
        }

        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .badge.buy {
            background: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .badge.sell {
            background: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .badge.open {
            background: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .profit { color: var(--success); font-weight: 700; }
        .loss { color: var(--danger); font-weight: 700; }

        /* Market List */
        .market-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .market-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px;
            background: rgba(249, 158, 11, 0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .market-item:hover {
            background: rgba(249, 158, 11, 0.08);
            border-color: var(--accent);
            transform: translateX(-3px);
        }

        .market-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
            flex-shrink: 0;
        }

        .market-info {
            flex: 1;
        }

        .market-name {
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 2px;
        }

        .market-symbol {
            font-size: 11px;
            color: var(--text-muted);
        }

        .market-price {
            text-align: left;
        }

        .price-value {
            font-weight: 900;
            font-size: 15px;
            margin-bottom: 2px;
            font-family: 'Poppins', sans-serif;
        }

        .price-change {
            font-size: 11px;
            font-weight: 700;
        }

        /* Transaction Item */
        .transaction-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px;
            background: rgba(249, 158, 11, 0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            margin-bottom: 12px;
            transition: all 0.3s;
        }

        .transaction-item:hover {
            background: rgba(249, 158, 11, 0.08);
            transform: translateX(-3px);
        }

        .transaction-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .transaction-icon.deposit {
            background: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .transaction-icon.withdrawal {
            background: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .transaction-icon.trade {
            background: rgba(249, 158, 11, 0.15);
            color: var(--accent);
        }

        .transaction-info {
            flex: 1;
        }

        .transaction-title {
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 3px;
        }

        .transaction-date {
            font-size: 11px;
            color: var(--text-muted);
        }

        .transaction-amount {
            font-size: 16px;
            font-weight: 900;
            font-family: 'Poppins', sans-serif;
        }

        .empty-state {
            text-align: center;
            padding: 48px 20px;
            color: var(--text-muted);
        }

        .empty-icon {
            font-size: 48px;
            margin-bottom: 12px;
            opacity: 0.3;
        }

        /* Mobile */
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(100%);
                transition: transform 0.3s;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main {
                margin-right: 0;
            }
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .page-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <span class="logo-text">Trading Pro</span>
            </div>
        </div>

        <div class="user-card">
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 2)); ?>
                </div>
                <div>
                    <div class="user-name"><?php echo htmlspecialchars($user['username']); ?></div>
                </div>
            </div>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح</span>
                <span class="balance-value">$<?php echo number_format($user['balance'], 2); ?></span>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">القائمة الرئيسية</div>
            <a href="dashboard.php" class="nav-item active">
                <i class="fas fa-home"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="spot-trading.php" class="nav-item">
                <i class="fas fa-chart-area"></i>
                <span>تداول فوري</span>
            </a>
            <a href="binary-trading.php" class="nav-item">
                <i class="fas fa-bullseye"></i>
                <span>خيارات ثنائية</span>
            </a>
            <a href="p2p-deposit.php" class="nav-item">
                <i class="fas fa-wallet"></i>
                <span>إضافة رصيد</span>
            </a>

            <div class="nav-section-title" style="margin-top: 20px;">الحساب</div>
            <a href="transactions.php" class="nav-item">
                <i class="fas fa-receipt"></i>
                <span>المعاملات</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="fas fa-user-circle"></i>
                <span>الملف الشخصي</span>
            </a>
            <a href="#" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>الإشعارات</span>
                <?php if ($unread_count > 0): ?>
                    <span class="nav-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل خروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main">
        <div class="header">
            <div class="header-top">
                <h1 class="page-title">مرحباً، <?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h1>
                <div class="header-actions">
                    <a href="p2p-deposit.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        <span>إضافة رصيد</span>
                    </a>
                    <a href="spot-trading.php" class="btn btn-secondary">
                        <i class="fas fa-chart-line"></i>
                        <span>ابدأ التداول</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-label">الرصيد المتاح</div>
                    <div class="stat-icon">
                        <i class="fas fa-wallet"></i>
                    </div>
                </div>
                <div class="stat-value">$<?php echo number_format($user['balance'], 2); ?></div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>+0.00% اليوم</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-label">إجمالي الأرباح</div>
                    <div class="stat-icon success">
                        <i class="fas fa-arrow-trend-up"></i>
                    </div>
                </div>
                <div class="stat-value" style="color: var(--success);">$<?php echo number_format($stats['overall']['total_profit'] ?? 0, 2); ?></div>
                <div class="stat-change positive">
                    <i class="fas fa-check"></i>
                    <span><?php echo ($stats['spot']['total'] ?? 0) + ($stats['binary']['total'] ?? 0); ?> صفقة</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-label">إجمالي الخسائر</div>
                    <div class="stat-icon danger">
                        <i class="fas fa-arrow-trend-down"></i>
                    </div>
                </div>
                <div class="stat-value" style="color: var(--danger);">$<?php echo number_format(abs($stats['overall']['total_loss'] ?? 0), 2); ?></div>
                <div class="stat-change negative">
                    <i class="fas fa-times"></i>
                    <span>مجموع الخسائر</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-label">صافي الربح</div>
                    <div class="stat-icon info">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
                <?php 
                $net_profit = $stats['overall']['net_profit'] ?? 0;
                $profit_color = $net_profit >= 0 ? 'var(--success)' : 'var(--danger)';
                ?>
                <div class="stat-value" style="color: <?php echo $profit_color; ?>;">
                    $<?php echo number_format($net_profit, 2); ?>
                </div>
                <div class="stat-change <?php echo $net_profit >= 0 ? 'positive' : 'negative'; ?>">
                    <i class="fas fa-<?php echo $net_profit >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                    <span>العائد الإجمالي</span>
                </div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Open Trades -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-chart-line"></i>
                        <span>الصفقات المفتوحة</span>
                    </h2>
                    <a href="spot-trading.php" class="card-link">
                        <span>عرض الكل</span>
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>

                <?php if (empty($open_spot_trades)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="fas fa-inbox"></i>
                        </div>
                        <div>لا توجد صفقات مفتوحة حالياً</div>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>الزوج</th>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>سعر الدخول</th>
                                <th>الربح/الخسارة</th>
                                <th>الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($open_spot_trades as $trade): ?>
                                <tr>
                                    <td>
                                        <div class="trade-symbol">
                                            <div class="trade-icon">
                                                <i class="fab fa-bitcoin"></i>
                                            </div>
                                            <div>
                                                <div style="font-weight: 700;"><?php echo $trade['symbol']; ?></div>
                                                <div style="font-size: 11px; color: var(--text-muted);">
                                                    <?php echo $trade['name_ar']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $trade['type']; ?>">
                                            <?php echo $trade['type'] === 'buy' ? 'شراء' : 'بيع'; ?>
                                        </span>
                                    </td>
                                    <td>$<?php echo number_format($trade['amount'], 2); ?></td>
                                    <td>$<?php echo number_format($trade['entry_price'], 2); ?></td>
                                    <td class="<?php echo $trade['profit_loss'] >= 0 ? 'profit' : 'loss'; ?>">
                                        $<?php echo number_format($trade['profit_loss'], 2); ?>
                                        (<?php echo number_format($trade['profit_loss_percentage'], 2); ?>%)
                                    </td>
                                    <td>
                                        <span class="badge open">مفتوحة</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Market & Transactions -->
            <div>
                <!-- Markets -->
                <div class="card" style="margin-bottom: 24px;">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-globe"></i>
                            <span>الأسواق</span>
                        </h2>
                        <a href="spot-trading.php" class="card-link">
                            <span>المزيد</span>
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>

                    <div class="market-list">
                        <?php 
                        $top_markets = array_slice($markets, 0, 4);
                        foreach ($top_markets as $market): 
                        ?>
                            <div class="market-item" onclick="window.location.href='spot-trading.php?symbol=<?php echo $market['symbol']; ?>'">
                                <div class="market-icon">
                                    <i class="fab fa-bitcoin"></i>
                                </div>
                                <div class="market-info">
                                    <div class="market-name"><?php echo $market['name_ar']; ?></div>
                                    <div class="market-symbol"><?php echo $market['symbol']; ?></div>
                                </div>
                                <div class="market-price">
                                    <div class="price-value">$<?php echo number_format($market['current_price'], 2); ?></div>
                                    <div class="price-change <?php echo $market['price_change_24h'] >= 0 ? 'positive' : 'negative'; ?>">
                                        <i class="fas fa-<?php echo $market['price_change_24h'] >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                                        <?php echo abs($market['price_change_24h']); ?>%
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Transactions -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-receipt"></i>
                            <span>آخر المعاملات</span>
                        </h2>
                        <a href="transactions.php" class="card-link">
                            <span>عرض الكل</span>
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>

                    <?php if (empty($recent_transactions)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <i class="fas fa-inbox"></i>
                            </div>
                            <div>لا توجد معاملات حالياً</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($recent_transactions as $transaction): ?>
                            <div class="transaction-item">
                                <div class="transaction-icon <?php 
                                    echo $transaction['type'] === 'deposit' ? 'deposit' : 
                                         ($transaction['type'] === 'withdrawal' ? 'withdrawal' : 'trade');
                                ?>">
                                    <i class="fas fa-<?php 
                                        echo $transaction['type'] === 'deposit' ? 'arrow-down' : 
                                             ($transaction['type'] === 'withdrawal' ? 'arrow-up' : 'exchange-alt');
                                    ?>"></i>
                                </div>
                                <div class="transaction-info">
                                    <div class="transaction-title">
                                        <?php 
                                        $types = [
                                            'deposit' => 'إيداع',
                                            'withdrawal' => 'سحب',
                                            'trade_profit' => 'ربح تداول',
                                            'trade_loss' => 'خسارة تداول',
                                            'bonus' => 'مكافأة',
                                            'fee' => 'رسوم'
                                        ];
                                        echo $types[$transaction['type']] ?? $transaction['type'];
                                        ?>
                                    </div>
                                    <div class="transaction-date">
                                        <?php echo time_ago($transaction['created_at'], $current_language); ?>
                                    </div>
                                </div>
                                <div class="transaction-amount" style="color: <?php 
                                    echo $transaction['amount'] >= 0 ? 'var(--success)' : 'var(--danger)';
                                ?>">
                                    <?php echo $transaction['amount'] >= 0 ? '+' : ''; ?>$<?php echo number_format(abs($transaction['amount']), 2); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</body>
</html>