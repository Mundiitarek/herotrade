<?php
define('APP_ACCESS', true);
require_once '../config.php';
require_once '../functions.php';
require_once 'functions.php';

require_admin_login();

$admin_id = $_SESSION['admin_id'];
$admin = get_admin_data($pdo, $admin_id);

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$success_message = '';
$error_message = '';

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'approve_payment') {
        $transaction_id = intval($_POST['transaction_id'] ?? 0);
        
        try {
            $pdo->beginTransaction();
            
            // Get transaction
            $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?");
            $stmt->execute([$transaction_id]);
            $transaction = $stmt->fetch();
            
            if (!$transaction) {
                json_response(['success' => false, 'message' => 'المعاملة غير موجودة'], 404);
            }
            
            // Update transaction
            $stmt = $pdo->prepare("
                UPDATE transactions 
                SET status = 'completed', processed_by = ?, processed_at = NOW(), admin_notes = ?
                WHERE id = ?
            ");
            $stmt->execute([$admin_id, 'تمت الموافقة من قبل الأدمن', $transaction_id]);
            
            // Add balance to user
            if ($transaction['type'] === 'deposit') {
                $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $stmt->execute([$transaction['amount'], $transaction['user_id']]);
            }
            
            // Create notification
            create_notification($pdo, $transaction['user_id'], 'success', 'تمت الموافقة على الإيداع', 
                "تمت الموافقة على طلب الإيداع بقيمة $" . number_format($transaction['amount'], 2));
            
            log_admin_activity($pdo, $admin_id, 'payment_approve', "الموافقة على المعاملة #$transaction_id");
            
            $pdo->commit();
            json_response(['success' => true]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'reject_payment') {
        $transaction_id = intval($_POST['transaction_id'] ?? 0);
        $reason = sanitize($_POST['reason'] ?? '');
        
        try {
            // Get transaction
            $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?");
            $stmt->execute([$transaction_id]);
            $transaction = $stmt->fetch();
            
            if (!$transaction) {
                json_response(['success' => false, 'message' => 'المعاملة غير موجودة'], 404);
            }
            
            // Update transaction
            $stmt = $pdo->prepare("
                UPDATE transactions 
                SET status = 'rejected', processed_by = ?, processed_at = NOW(), admin_notes = ?
                WHERE id = ?
            ");
            $stmt->execute([$admin_id, $reason, $transaction_id]);
            
            // Create notification
            create_notification($pdo, $transaction['user_id'], 'danger', 'تم رفض الإيداع', 
                "تم رفض طلب الإيداع. السبب: " . ($reason ?: 'لم يتم تحديد السبب'));
            
            log_admin_activity($pdo, $admin_id, 'payment_reject', "رفض المعاملة #$transaction_id");
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'toggle_gateway') {
        $gateway_id = intval($_POST['gateway_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("UPDATE payment_gateways SET is_active = NOT is_active WHERE id = ?");
            $stmt->execute([$gateway_id]);
            
            log_admin_activity($pdo, $admin_id, 'gateway_toggle', "تغيير حالة بوابة الدفع #$gateway_id");
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_gateway'])) {
        $name = sanitize($_POST['name']);
        $type = sanitize($_POST['type']);
        $account_info = sanitize($_POST['account_info']);
        $min_amount = floatval($_POST['min_amount']);
        $max_amount = floatval($_POST['max_amount']);
        $instructions = sanitize($_POST['instructions']);
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO payment_gateways (name, type, account_info, min_amount, max_amount, instructions, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([$name, $type, $account_info, $min_amount, $max_amount, $instructions]);
            
            $success_message = 'تم إضافة بوابة الدفع بنجاح';
            log_admin_activity($pdo, $admin_id, 'gateway_add', "إضافة بوابة دفع جديدة: $name");
        } catch (PDOException $e) {
            $error_message = 'حدث خطأ أثناء الإضافة';
        }
    }
}

// Get filters
$status_filter = sanitize($_GET['status'] ?? 'pending');
$type_filter = sanitize($_GET['type'] ?? 'all');
$gateway_filter = sanitize($_GET['gateway'] ?? 'all');
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query
$where = ["1=1"];
$params = [];

if ($status_filter !== 'all') {
    $where[] = "t.status = ?";
    $params[] = $status_filter;
}

if ($type_filter !== 'all') {
    $where[] = "t.type = ?";
    $params[] = $type_filter;
}

if ($gateway_filter !== 'all') {
    $where[] = "t.gateway_id = ?";
    $params[] = $gateway_filter;
}

$where_clause = implode(' AND ', $where);

// Get transactions
try {
    $stmt = $pdo->prepare("
        SELECT 
            t.*,
            u.username,
            u.email,
            pg.name as gateway_name,
            pg.type as gateway_type,
            a.username as processed_by_name
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        LEFT JOIN payment_gateways pg ON t.gateway_id = pg.id
        LEFT JOIN admin_users a ON t.processed_by = a.id
        WHERE $where_clause
        ORDER BY 
            CASE WHEN t.status = 'pending' THEN 0 ELSE 1 END,
            t.created_at DESC
        LIMIT ? OFFSET ?
    ");
    
    $params[] = $per_page;
    $params[] = $offset;
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Get transactions error: " . $e->getMessage());
    $transactions = [];
}

// Get payment gateways
try {
    $stmt = $pdo->query("
        SELECT 
            pg.*,
            COUNT(t.id) as transaction_count,
            SUM(CASE WHEN t.status = 'completed' THEN t.amount ELSE 0 END) as total_amount
        FROM payment_gateways pg
        LEFT JOIN transactions t ON pg.id = t.gateway_id
        GROUP BY pg.id
        ORDER BY pg.is_active DESC, pg.name ASC
    ");
    $gateways = $stmt->fetchAll();
} catch (PDOException $e) {
    $gateways = [];
}

// Get statistics
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_transactions,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
            COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
            COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected,
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
            SUM(CASE WHEN type = 'withdrawal' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals
        FROM transactions
    ");
    $stats = $stmt->fetch();
} catch (PDOException $e) {
    $stats = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المدفوعات - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --warning: #F59E0B;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar - Same structure */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-badge {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            font-size: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .admin-card {
            padding: 20px;
            margin: 20px;
            background: rgba(220, 38, 38, 0.05);
            border: 1px solid rgba(220, 38, 38, 0.1);
            border-radius: 16px;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(220, 38, 38, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        .nav-badge {
            margin-right: auto;
            background: var(--danger);
            color: white;
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 700;
        }

        /* Main */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
        }

        /* Alert */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 900;
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            border-bottom: 2px solid var(--border);
        }

        .tab-btn {
            padding: 12px 24px;
            background: none;
            border: none;
            color: var(--text-muted);
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            font-family: 'Tajawal', sans-serif;
            text-decoration: none;
        }

        .tab-btn:hover,
        .tab-btn.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }

        /* Filters */
        .filters-section {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .filter-select {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
        }

        /* Transactions Table */
        .transactions-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 24px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(220, 38, 38, 0.05);
        }

        th {
            padding: 16px 24px;
            text-align: right;
            font-weight: 700;
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        td {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
        }

        tbody tr {
            transition: background 0.2s;
        }

        tbody tr:hover {
            background: rgba(220, 38, 38, 0.02);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .status-badge.completed {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-badge.rejected {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .btn-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .btn-success:hover {
            background: var(--success);
            color: white;
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn-danger:hover {
            background: var(--danger);
            color: white;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 500px;
            width: 90%;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .form-input,
        .form-textarea {
            width: 100%;
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
        }

        .form-textarea {
            min-height: 100px;
            resize: vertical;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            table {
                min-width: 900px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <div class="logo-text">Admin Panel</div>
                    <div class="admin-badge">Administrator</div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div>
                    <div style="font-weight: 700;"><?= htmlspecialchars($admin['username']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted);">Super Admin</div>
                </div>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">الإدارة</div>
            <a href="index.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
            </a>
            <a href="payments.php" class="nav-item active">
                <i class="fas fa-credit-card"></i>
                <span>المدفوعات</span>
                <?php if (($stats['pending'] ?? 0) > 0): ?>
                    <span class="nav-badge"><?= $stats['pending'] ?></span>
                <?php endif; ?>
            </a>
            <a href="trades.php" class="nav-item">
                <i class="fas fa-exchange-alt"></i>
                <span>الصفقات</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>الإعدادات</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-arrow-right"></i>
                <span>العودة للمنصة</span>
            </a>
            <a href="../logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">إدارة المدفوعات</h1>
            <div class="breadcrumb">
                <a href="index.php">لوحة التحكم</a>
                <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                <span>المدفوعات</span>
            </div>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success_message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">معاملات معلقة</div>
                <div class="stat-value" style="color: var(--warning);"><?= number_format($stats['pending'] ?? 0) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">معاملات مكتملة</div>
                <div class="stat-value" style="color: var(--success);"><?= number_format($stats['completed'] ?? 0) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">إجمالي الإيداعات</div>
                <div class="stat-value" style="color: var(--success);">$<?= number_format($stats['total_deposits'] ?? 0, 2) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">إجمالي السحوبات</div>
                <div class="stat-value" style="color: var(--danger);">$<?= number_format($stats['total_withdrawals'] ?? 0, 2) ?></div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
            <a href="?status=pending" class="tab-btn <?= $status_filter === 'pending' ? 'active' : '' ?>">
                معلقة (<?= $stats['pending'] ?? 0 ?>)
            </a>
            <a href="?status=completed" class="tab-btn <?= $status_filter === 'completed' ? 'active' : '' ?>">
                مكتملة (<?= $stats['completed'] ?? 0 ?>)
            </a>
            <a href="?status=rejected" class="tab-btn <?= $status_filter === 'rejected' ? 'active' : '' ?>">
                مرفوضة (<?= $stats['rejected'] ?? 0 ?>)
            </a>
            <a href="?status=all" class="tab-btn <?= $status_filter === 'all' ? 'active' : '' ?>">
                الكل (<?= $stats['total_transactions'] ?? 0 ?>)
            </a>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <form method="GET">
                <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">النوع</label>
                        <select name="type" class="filter-select" onchange="this.form.submit()">
                            <option value="all" <?= $type_filter === 'all' ? 'selected' : '' ?>>الكل</option>
                            <option value="deposit" <?= $type_filter === 'deposit' ? 'selected' : '' ?>>إيداع</option>
                            <option value="withdrawal" <?= $type_filter === 'withdrawal' ? 'selected' : '' ?>>سحب</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">البوابة</label>
                        <select name="gateway" class="filter-select" onchange="this.form.submit()">
                            <option value="all">الكل</option>
                            <?php foreach ($gateways as $gateway): ?>
                                <option value="<?= $gateway['id'] ?>" <?= $gateway_filter == $gateway['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($gateway['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </form>
        </div>

        <!-- Transactions Table -->
        <div class="transactions-card">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المستخدم</th>
                            <th>النوع</th>
                            <th>البوابة</th>
                            <th>المبلغ</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transactions)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 48px; color: var(--text-muted);">
                                    لا توجد معاملات
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td>#<?= $transaction['id'] ?></td>
                                    <td>
                                        <div>
                                            <div style="font-weight: 600;"><?= htmlspecialchars($transaction['username']) ?></div>
                                            <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($transaction['email']) ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <span style="color: <?= $transaction['type'] === 'deposit' ? 'var(--success)' : 'var(--danger)' ?>">
                                            <?= $transaction['type'] === 'deposit' ? 'إيداع' : 'سحب' ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['gateway_name'] ?? 'N/A') ?></td>
                                    <td style="font-weight: 700;">$<?= number_format($transaction['amount'], 2) ?></td>
                                    <td>
                                        <span class="status-badge <?= $transaction['status'] ?>">
                                            <i class="fas fa-<?= 
                                                $transaction['status'] === 'pending' ? 'clock' : 
                                                ($transaction['status'] === 'completed' ? 'check-circle' : 'times-circle')
                                            ?>"></i>
                                            <?= 
                                                $transaction['status'] === 'pending' ? 'معلق' : 
                                                ($transaction['status'] === 'completed' ? 'مكتمل' : 'مرفوض')
                                            ?>
                                        </span>
                                    </td>
                                    <td style="font-size: 13px; color: var(--text-muted);">
                                        <?= date('Y/m/d h:i A', strtotime($transaction['created_at'])) ?>
                                    </td>
                                    <td>
                                        <?php if ($transaction['status'] === 'pending'): ?>
                                            <div style="display: flex; gap: 8px;">
                                                <button class="btn btn-success btn-sm" onclick="approvePayment(<?= $transaction['id'] ?>)">
                                                    <i class="fas fa-check"></i> موافقة
                                                </button>
                                                <button class="btn btn-danger btn-sm" onclick="openRejectModal(<?= $transaction['id'] ?>)">
                                                    <i class="fas fa-times"></i> رفض
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <span style="font-size: 12px; color: var(--text-muted);">
                                                <?= htmlspecialchars($transaction['processed_by_name'] ?? 'System') ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Payment Gateways Section -->
        <div class="transactions-card">
            <div style="padding: 24px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                <h3 style="font-size: 20px; font-weight: 700;">بوابات الدفع</h3>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>النوع</th>
                            <th>الحد الأدنى</th>
                            <th>الحد الأقصى</th>
                            <th>المعاملات</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gateways as $gateway): ?>
                            <tr>
                                <td style="font-weight: 600;"><?= htmlspecialchars($gateway['name']) ?></td>
                                <td><?= htmlspecialchars($gateway['type']) ?></td>
                                <td>$<?= number_format($gateway['min_amount'], 2) ?></td>
                                <td>$<?= number_format($gateway['max_amount'], 2) ?></td>
                                <td><?= $gateway['transaction_count'] ?> ($<?= number_format($gateway['total_amount'], 2) ?>)</td>
                                <td>
                                    <span class="status-badge <?= $gateway['is_active'] ? 'completed' : 'rejected' ?>">
                                        <?= $gateway['is_active'] ? 'مفعل' : 'معطل' ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn <?= $gateway['is_active'] ? 'btn-danger' : 'btn-success' ?> btn-sm" 
                                            onclick="toggleGateway(<?= $gateway['id'] ?>)">
                                        <i class="fas fa-<?= $gateway['is_active'] ? 'ban' : 'check' ?>"></i>
                                        <?= $gateway['is_active'] ? 'تعطيل' : 'تفعيل' ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <h2 class="modal-title">رفض الطلب</h2>
            <form id="rejectForm">
                <input type="hidden" id="reject_transaction_id">
                
                <div class="form-group">
                    <label class="form-label">سبب الرفض</label>
                    <textarea id="reject_reason" class="form-textarea" placeholder="أدخل سبب الرفض..." required></textarea>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-danger" onclick="closeRejectModal()">إلغاء</button>
                    <button type="submit" class="btn btn-primary">تأكيد الرفض</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function approvePayment(transactionId) {
            if (!confirm('هل تريد الموافقة على هذا الطلب؟')) return;
            
            fetch('payments.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=approve_payment&transaction_id=${transactionId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'حدث خطأ');
                }
            });
        }

        function openRejectModal(transactionId) {
            document.getElementById('reject_transaction_id').value = transactionId;
            document.getElementById('reject_reason').value = '';
            document.getElementById('rejectModal').classList.add('active');
        }

        function closeRejectModal() {
            document.getElementById('rejectModal').classList.remove('active');
        }

        document.getElementById('rejectForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const transactionId = document.getElementById('reject_transaction_id').value;
            const reason = document.getElementById('reject_reason').value;
            
            fetch('payments.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=reject_payment&transaction_id=${transactionId}&reason=${encodeURIComponent(reason)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'حدث خطأ');
                }
            });
        });

        function toggleGateway(gatewayId) {
            fetch('payments.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=toggle_gateway&gateway_id=${gatewayId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        // Close modal on outside click
        document.getElementById('rejectModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeRejectModal();
            }
        });
    </script>
</body>
</html>
