<?php
define('APP_ACCESS', true);
require_once '../config.php';
require_once '../functions.php';
require_once 'functions.php';

// Require admin login
require_admin_login();

$admin_id = $_SESSION['admin_id'];
$admin = get_admin_data($pdo, $admin_id);

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

// Get comprehensive statistics
try {
    // Users stats
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_users,
            COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_users,
            COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as new_users_today,
            COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as new_users_week,
            SUM(balance) as total_balance
        FROM users
    ");
    $users_stats = $stmt->fetch();
    
    // Transactions stats
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_transactions,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_transactions,
            COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as transactions_today,
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
            SUM(CASE WHEN type = 'withdrawal' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals
        FROM transactions
    ");
    $transactions_stats = $stmt->fetch();
    
    // Spot trades stats
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_spot_trades,
            COUNT(CASE WHEN status = 'open' THEN 1 END) as open_spot_trades,
            SUM(CASE WHEN status = 'closed' AND profit_loss > 0 THEN profit_loss ELSE 0 END) as total_spot_profit,
            SUM(CASE WHEN status = 'closed' AND profit_loss < 0 THEN profit_loss ELSE 0 END) as total_spot_loss,
            SUM(fee) as total_spot_fees
        FROM spot_trades
    ");
    $spot_stats = $stmt->fetch();
    
    // Binary trades stats
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_binary_trades,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_binary_trades,
            COUNT(CASE WHEN result = 'won' THEN 1 END) as won_binary_trades,
            COUNT(CASE WHEN result = 'lost' THEN 1 END) as lost_binary_trades,
            SUM(CASE WHEN result = 'won' THEN payout ELSE 0 END) as total_binary_payout,
            SUM(CASE WHEN result = 'lost' THEN amount ELSE 0 END) as total_binary_loss
        FROM binary_trades
    ");
    $binary_stats = $stmt->fetch();
    
    // Recent activity
    $stmt = $pdo->query("
        SELECT al.*, u.username 
        FROM activity_logs al
        LEFT JOIN users u ON al.user_id = u.id
        ORDER BY al.created_at DESC
        LIMIT 15
    ");
    $recent_activity = $stmt->fetchAll();
    
    // Pending deposits
    $stmt = $pdo->query("
        SELECT t.*, u.username, u.email, pg.name as gateway_name
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        LEFT JOIN payment_gateways pg ON t.gateway_id = pg.id
        WHERE t.type = 'deposit' AND t.status = 'pending'
        ORDER BY t.created_at DESC
        LIMIT 10
    ");
    $pending_deposits = $stmt->fetchAll();
    
    // Top traders
    $stmt = $pdo->query("
        SELECT u.id, u.username, u.email, u.balance,
            COUNT(st.id) as total_trades,
            SUM(CASE WHEN st.profit_loss > 0 THEN st.profit_loss ELSE 0 END) as total_profit
        FROM users u
        LEFT JOIN spot_trades st ON u.id = st.user_id AND st.status = 'closed'
        GROUP BY u.id
        ORDER BY total_profit DESC
        LIMIT 5
    ");
    $top_traders = $stmt->fetchAll();
    
    // Chart data - Last 7 days transactions
    $stmt = $pdo->query("
        SELECT 
            DATE(created_at) as date,
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as deposits,
            SUM(CASE WHEN type = 'withdrawal' AND status = 'completed' THEN amount ELSE 0 END) as withdrawals
        FROM transactions
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ");
    $chart_data = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Admin stats error: " . $e->getMessage());
    $users_stats = $transactions_stats = $spot_stats = $binary_stats = [];
    $recent_activity = $pending_deposits = $top_traders = $chart_data = [];
}

// Calculate platform revenue
$platform_revenue = ($spot_stats['total_spot_fees'] ?? 0) + 
                   (($binary_stats['total_binary_loss'] ?? 0) - ($binary_stats['total_binary_payout'] ?? 0));
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الأدمن - Trading Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --warning: #F59E0B;
            --purple: #8B5CF6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-badge {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            font-size: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .admin-card {
            padding: 20px;
            margin: 20px;
            background: rgba(220, 38, 38, 0.05);
            border: 1px solid rgba(220, 38, 38, 0.1);
            border-radius: 16px;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .admin-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .admin-name {
            font-weight: 700;
            font-size: 16px;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(220, 38, 38, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        .nav-badge {
            margin-right: auto;
            background: var(--danger);
            color: white;
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 700;
        }

        /* Main Content */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .page-subtitle {
            color: var(--text-muted);
            font-size: 14px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.3);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            transform: translate(30%, -30%);
            opacity: 0.1;
        }

        .stat-card.users::before { background: var(--info); }
        .stat-card.revenue::before { background: var(--success); }
        .stat-card.trades::before { background: var(--purple); }
        .stat-card.pending::before { background: var(--warning); }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stat-icon.users { background: rgba(59, 130, 246, 0.1); color: var(--info); }
        .stat-icon.revenue { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .stat-icon.trades { background: rgba(139, 92, 246, 0.1); color: var(--purple); }
        .stat-icon.pending { background: rgba(245, 158, 11, 0.1); color: var(--warning); }

        .stat-trend {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 20px;
        }

        .stat-trend.up {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .stat-trend.down {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .stat-value {
            font-size: 32px;
            font-weight: 900;
            color: var(--text);
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 12px;
        }

        .stat-details {
            display: flex;
            gap: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }

        .stat-detail {
            flex: 1;
        }

        .stat-detail-value {
            font-size: 16px;
            font-weight: 700;
            color: var(--text);
        }

        .stat-detail-label {
            font-size: 11px;
            color: var(--text-muted);
        }

        /* Charts Section */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 32px;
        }

        .chart-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .chart-title {
            font-size: 18px;
            font-weight: 700;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        /* Tables */
        .data-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-bottom: 32px;
        }

        .data-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
        }

        .data-card.full-width {
            grid-column: 1 / -1;
        }

        .data-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .data-title {
            font-size: 18px;
            font-weight: 700;
        }

        .data-body {
            max-height: 400px;
            overflow-y: auto;
        }

        .data-body::-webkit-scrollbar { width: 4px; }
        .data-body::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .data-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            transition: background 0.2s;
        }

        .data-item:hover {
            background: rgba(249, 158, 11, 0.02);
        }

        .data-item:last-child {
            border-bottom: none;
        }

        .item-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .item-content {
            flex: 1;
            min-width: 0;
        }

        .item-title {
            font-weight: 600;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .item-subtitle {
            font-size: 12px;
            color: var(--text-muted);
        }

        .item-value {
            font-weight: 700;
            white-space: nowrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(220, 38, 38, 0.3);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .data-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .page-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <div class="logo-text">Admin Panel</div>
                    <div class="admin-badge">Administrator</div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div>
                    <div class="admin-name"><?= htmlspecialchars($admin['username']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted);">Super Admin</div>
                </div>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">الإدارة</div>
            <a href="index.php" class="nav-item active">
                <i class="fas fa-chart-pie"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
                <span class="nav-badge"><?= $users_stats['total_users'] ?? 0 ?></span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-credit-card"></i>
                <span>المدفوعات</span>
                <?php if (($transactions_stats['pending_transactions'] ?? 0) > 0): ?>
                    <span class="nav-badge"><?= $transactions_stats['pending_transactions'] ?></span>
                <?php endif; ?>
            </a>
            <a href="trades.php" class="nav-item">
                <i class="fas fa-exchange-alt"></i>
                <span>الصفقات</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>الإعدادات</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-arrow-right"></i>
                <span>العودة للمنصة</span>
            </a>
            <a href="../logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">لوحة تحكم الأدمن</h1>
            <p class="page-subtitle">نظرة شاملة على المنصة والإحصائيات</p>
        </div>

        <!-- Main Stats -->
        <div class="stats-grid">
            <!-- Users -->
            <div class="stat-card users">
                <div class="stat-header">
                    <div class="stat-icon users">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-trend up">
                        <i class="fas fa-arrow-up"></i>
                        +<?= $users_stats['new_users_week'] ?? 0 ?>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($users_stats['total_users'] ?? 0) ?></div>
                <div class="stat-label">إجمالي المستخدمين</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <div class="stat-detail-value"><?= $users_stats['active_users'] ?? 0 ?></div>
                        <div class="stat-detail-label">نشط</div>
                    </div>
                    <div class="stat-detail">
                        <div class="stat-detail-value"><?= $users_stats['new_users_today'] ?? 0 ?></div>
                        <div class="stat-detail-label">اليوم</div>
                    </div>
                </div>
            </div>

            <!-- Revenue -->
            <div class="stat-card revenue">
                <div class="stat-header">
                    <div class="stat-icon revenue">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-trend up">
                        <i class="fas fa-arrow-up"></i>
                        12.5%
                    </div>
                </div>
                <div class="stat-value">$<?= number_format($platform_revenue, 2) ?></div>
                <div class="stat-label">إيرادات المنصة</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <div class="stat-detail-value">$<?= number_format($transactions_stats['total_deposits'] ?? 0, 2) ?></div>
                        <div class="stat-detail-label">إيداعات</div>
                    </div>
                    <div class="stat-detail">
                        <div class="stat-detail-value">$<?= number_format($transactions_stats['total_withdrawals'] ?? 0, 2) ?></div>
                        <div class="stat-detail-label">سحوبات</div>
                    </div>
                </div>
            </div>

            <!-- Trades -->
            <div class="stat-card trades">
                <div class="stat-header">
                    <div class="stat-icon trades">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-trend up">
                        <i class="fas fa-arrow-up"></i>
                        8.3%
                    </div>
                </div>
                <div class="stat-value"><?= number_format(($spot_stats['total_spot_trades'] ?? 0) + ($binary_stats['total_binary_trades'] ?? 0)) ?></div>
                <div class="stat-label">إجمالي الصفقات</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <div class="stat-detail-value"><?= $spot_stats['open_spot_trades'] ?? 0 ?></div>
                        <div class="stat-detail-label">Spot مفتوح</div>
                    </div>
                    <div class="stat-detail">
                        <div class="stat-detail-value"><?= $binary_stats['pending_binary_trades'] ?? 0 ?></div>
                        <div class="stat-detail-label">Binary منتظر</div>
                    </div>
                </div>
            </div>

            <!-- Pending -->
            <div class="stat-card pending">
                <div class="stat-header">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <?php if (($transactions_stats['pending_transactions'] ?? 0) > 0): ?>
                        <div class="stat-trend" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">
                            <i class="fas fa-exclamation-circle"></i>
                            يتطلب إجراء
                        </div>
                    <?php endif; ?>
                </div>
                <div class="stat-value"><?= $transactions_stats['pending_transactions'] ?? 0 ?></div>
                <div class="stat-label">معاملات معلقة</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <div class="stat-detail-value"><?= $transactions_stats['transactions_today'] ?? 0 ?></div>
                        <div class="stat-detail-label">اليوم</div>
                    </div>
                    <div class="stat-detail">
                        <a href="payments.php" class="btn btn-primary btn-sm" style="width: 100%;">
                            مراجعة
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <!-- Transactions Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3 class="chart-title">الإيداعات والسحوبات - آخر 7 أيام</h3>
                </div>
                <div class="chart-container">
                    <canvas id="transactionsChart"></canvas>
                </div>
            </div>

            <!-- Trades Distribution -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3 class="chart-title">توزيع الصفقات</h3>
                </div>
                <div class="chart-container">
                    <canvas id="tradesChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Data Tables -->
        <div class="data-grid">
            <!-- Pending Deposits -->
            <div class="data-card">
                <div class="data-header">
                    <h3 class="data-title">طلبات إيداع معلقة</h3>
                    <a href="payments.php" class="btn btn-primary btn-sm">عرض الكل</a>
                </div>
                <div class="data-body">
                    <?php if (empty($pending_deposits)): ?>
                        <div style="text-align: center; padding: 48px; color: var(--text-muted);">
                            <i class="fas fa-check-circle" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
                            <p>لا توجد طلبات معلقة</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pending_deposits as $deposit): ?>
                            <div class="data-item">
                                <div class="item-icon" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="item-content">
                                    <div class="item-title"><?= htmlspecialchars($deposit['username']) ?></div>
                                    <div class="item-subtitle">
                                        <?= htmlspecialchars($deposit['gateway_name'] ?? 'N/A') ?> • 
                                        <?= date('Y/m/d h:i A', strtotime($deposit['created_at'])) ?>
                                    </div>
                                </div>
                                <div class="item-value" style="color: var(--success);">
                                    $<?= number_format($deposit['amount'], 2) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Top Traders -->
            <div class="data-card">
                <div class="data-header">
                    <h3 class="data-title">أفضل المتداولين</h3>
                    <a href="users.php" class="btn btn-primary btn-sm">عرض الكل</a>
                </div>
                <div class="data-body">
                    <?php if (empty($top_traders)): ?>
                        <div style="text-align: center; padding: 48px; color: var(--text-muted);">
                            <p>لا يوجد متداولون بعد</p>
                        </div>
                    <?php else: ?>
                        <?php $rank = 1; foreach ($top_traders as $trader): ?>
                            <div class="data-item">
                                <div class="item-icon" style="background: <?= $rank === 1 ? 'linear-gradient(135deg, #F59E0B, #DC2626)' : 'rgba(139, 92, 246, 0.1)' ?>; color: white;">
                                    <?= $rank ?>
                                </div>
                                <div class="item-content">
                                    <div class="item-title"><?= htmlspecialchars($trader['username']) ?></div>
                                    <div class="item-subtitle">
                                        <?= $trader['total_trades'] ?? 0 ?> صفقة • 
                                        رصيد: $<?= number_format($trader['balance'], 2) ?>
                                    </div>
                                </div>
                                <div class="item-value" style="color: var(--success);">
                                    +$<?= number_format($trader['total_profit'], 2) ?>
                                </div>
                            </div>
                        <?php $rank++; endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="data-card full-width">
                <div class="data-header">
                    <h3 class="data-title">النشاط الأخير</h3>
                </div>
                <div class="data-body">
                    <?php if (empty($recent_activity)): ?>
                        <div style="text-align: center; padding: 48px; color: var(--text-muted);">
                            <p>لا يوجد نشاط حتى الآن</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($recent_activity as $activity): ?>
                            <div class="data-item">
                                <div class="item-icon" style="background: rgba(59, 130, 246, 0.1); color: var(--info);">
                                    <i class="fas fa-<?= 
                                        $activity['action'] === 'login' ? 'sign-in-alt' : 
                                        ($activity['action'] === 'trade' ? 'exchange-alt' : 
                                        ($activity['action'] === 'deposit' ? 'arrow-down' : 'circle'))
                                    ?>"></i>
                                </div>
                                <div class="item-content">
                                    <div class="item-title">
                                        <strong><?= htmlspecialchars($activity['username'] ?? 'System') ?></strong> • 
                                        <?= htmlspecialchars($activity['description']) ?>
                                    </div>
                                    <div class="item-subtitle">
                                        IP: <?= htmlspecialchars($activity['ip_address'] ?? 'N/A') ?>
                                    </div>
                                </div>
                                <div style="font-size: 12px; color: var(--text-muted);">
                                    <?= date('h:i A', strtotime($activity['created_at'])) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Transactions Chart
        const transactionsCtx = document.getElementById('transactionsChart').getContext('2d');
        new Chart(transactionsCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_map(fn($d) => date('m/d', strtotime($d['date'])), $chart_data)) ?>,
                datasets: [{
                    label: 'إيداعات',
                    data: <?= json_encode(array_map(fn($d) => $d['deposits'], $chart_data)) ?>,
                    borderColor: '#10B981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'سحوبات',
                    data: <?= json_encode(array_map(fn($d) => $d['withdrawals'], $chart_data)) ?>,
                    borderColor: '#EF4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#F8FAFC' } }
                },
                scales: {
                    y: { 
                        ticks: { color: '#94A3B8' },
                        grid: { color: 'rgba(148, 163, 184, 0.1)' }
                    },
                    x: { 
                        ticks: { color: '#94A3B8' },
                        grid: { color: 'rgba(148, 163, 184, 0.1)' }
                    }
                }
            }
        });

        // Trades Distribution Chart
        const tradesCtx = document.getElementById('tradesChart').getContext('2d');
        new Chart(tradesCtx, {
            type: 'doughnut',
            data: {
                labels: ['Spot Trades', 'Binary Won', 'Binary Lost'],
                datasets: [{
                    data: [
                        <?= $spot_stats['total_spot_trades'] ?? 0 ?>,
                        <?= $binary_stats['won_binary_trades'] ?? 0 ?>,
                        <?= $binary_stats['lost_binary_trades'] ?? 0 ?>
                    ],
                    backgroundColor: ['#8B5CF6', '#10B981', '#EF4444']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { 
                        labels: { color: '#F8FAFC' },
                        position: 'bottom'
                    }
                }
            }
        });

        // Auto-refresh every 30 seconds
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>
