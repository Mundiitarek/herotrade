<?php
define('APP_ACCESS', true);
require_once '../config.php';
require_once '../functions.php';
require_once 'functions.php';

require_admin_login();

$admin_id = $_SESSION['admin_id'];
$admin = get_admin_data($pdo, $admin_id);

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'close_spot_trade') {
        $trade_id = intval($_POST['trade_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM spot_trades WHERE id = ? AND status = 'open'");
            $stmt->execute([$trade_id]);
            $trade = $stmt->fetch();
            
            if (!$trade) {
                json_response(['success' => false, 'message' => 'الصفقة غير موجودة أو مغلقة'], 404);
            }
            
            // Get current price
            $current_price = get_realtime_price($pdo, $trade['symbol']);
            
            // Calculate profit/loss
            if ($trade['type'] === 'buy') {
                $profit_loss = ($current_price - $trade['entry_price']) * $trade['quantity'];
            } else {
                $profit_loss = ($trade['entry_price'] - $current_price) * $trade['quantity'];
            }
            
            $pdo->beginTransaction();
            
            // Close trade
            $stmt = $pdo->prepare("
                UPDATE spot_trades 
                SET status = 'closed', exit_price = ?, profit_loss = ?, closed_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$current_price, $profit_loss, $trade_id]);
            
            // Update user balance
            $final_amount = $trade['amount'] + $profit_loss;
            $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt->execute([$final_amount, $trade['user_id']]);
            
            log_admin_activity($pdo, $admin_id, 'trade_close', "إغلاق صفقة Spot #$trade_id");
            
            $pdo->commit();
            json_response(['success' => true]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'delete_trade') {
        $trade_id = intval($_POST['trade_id'] ?? 0);
        $trade_type = sanitize($_POST['trade_type'] ?? 'spot');
        
        try {
            if ($trade_type === 'spot') {
                $stmt = $pdo->prepare("DELETE FROM spot_trades WHERE id = ?");
            } else {
                $stmt = $pdo->prepare("DELETE FROM binary_trades WHERE id = ?");
            }
            $stmt->execute([$trade_id]);
            
            log_admin_activity($pdo, $admin_id, 'trade_delete', "حذف صفقة $trade_type #$trade_id");
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    exit;
}

// Get filters
$trade_type = sanitize($_GET['type'] ?? 'spot');
$status_filter = sanitize($_GET['status'] ?? 'all');
$user_filter = sanitize($_GET['user'] ?? '');
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Get trades based on type
if ($trade_type === 'spot') {
    // Build query for spot trades
    $where = ["1=1"];
    $params = [];
    
    if ($status_filter !== 'all') {
        $where[] = "st.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($user_filter)) {
        $where[] = "(u.username LIKE ? OR u.email LIKE ?)";
        $params[] = "%$user_filter%";
        $params[] = "%$user_filter%";
    }
    
    $where_clause = implode(' AND ', $where);
    
    try {
        // Get total count
        $count_stmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM spot_trades st
            JOIN users u ON st.user_id = u.id
            WHERE $where_clause
        ");
        $count_stmt->execute($params);
        $total_trades = $count_stmt->fetchColumn();
        $total_pages = ceil($total_trades / $per_page);
        
        // Get trades
        $stmt = $pdo->prepare("
            SELECT 
                st.*,
                u.username,
                u.email,
                tp.name_ar as pair_name,
                tp.current_price as market_price
            FROM spot_trades st
            JOIN users u ON st.user_id = u.id
            LEFT JOIN trading_pairs tp ON st.pair_id = tp.id
            WHERE $where_clause
            ORDER BY st.created_at DESC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $per_page;
        $params[] = $offset;
        $stmt->execute($params);
        $trades = $stmt->fetchAll();
        
        // Calculate current P/L for open trades
        foreach ($trades as &$trade) {
            if ($trade['status'] === 'open') {
                $current_price = $trade['market_price'];
                if ($trade['type'] === 'buy') {
                    $trade['current_profit_loss'] = ($current_price - $trade['entry_price']) * $trade['quantity'];
                } else {
                    $trade['current_profit_loss'] = ($trade['entry_price'] - $current_price) * $trade['quantity'];
                }
            }
        }
        
        // Get statistics
        $stmt = $pdo->query("
            SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'open' THEN 1 END) as open_trades,
                COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed_trades,
                SUM(CASE WHEN status = 'closed' AND profit_loss > 0 THEN profit_loss ELSE 0 END) as total_profit,
                SUM(CASE WHEN status = 'closed' AND profit_loss < 0 THEN profit_loss ELSE 0 END) as total_loss,
                SUM(amount) as total_volume
            FROM spot_trades
        ");
        $stats = $stmt->fetch();
        
    } catch (PDOException $e) {
        error_log("Get spot trades error: " . $e->getMessage());
        $trades = [];
        $stats = [];
        $total_trades = 0;
        $total_pages = 1;
    }
    
} else {
    // Binary trades
    $where = ["1=1"];
    $params = [];
    
    if ($status_filter !== 'all') {
        if ($status_filter === 'pending') {
            $where[] = "bt.status = 'pending'";
        } else {
            $where[] = "bt.result = ?";
            $params[] = $status_filter;
        }
    }
    
    if (!empty($user_filter)) {
        $where[] = "(u.username LIKE ? OR u.email LIKE ?)";
        $params[] = "%$user_filter%";
        $params[] = "%$user_filter%";
    }
    
    $where_clause = implode(' AND ', $where);
    
    try {
        // Get total count
        $count_stmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM binary_trades bt
            JOIN users u ON bt.user_id = u.id
            WHERE $where_clause
        ");
        $count_stmt->execute($params);
        $total_trades = $count_stmt->fetchColumn();
        $total_pages = ceil($total_trades / $per_page);
        
        // Get trades
        $stmt = $pdo->prepare("
            SELECT 
                bt.*,
                u.username,
                u.email,
                tp.name_ar as pair_name
            FROM binary_trades bt
            JOIN users u ON bt.user_id = u.id
            LEFT JOIN trading_pairs tp ON bt.pair_id = tp.id
            WHERE $where_clause
            ORDER BY bt.created_at DESC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $per_page;
        $params[] = $offset;
        $stmt->execute($params);
        $trades = $stmt->fetchAll();
        
        // Get statistics
        $stmt = $pdo->query("
            SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                COUNT(CASE WHEN result = 'won' THEN 1 END) as won,
                COUNT(CASE WHEN result = 'lost' THEN 1 END) as lost,
                SUM(CASE WHEN result = 'won' THEN payout ELSE 0 END) as total_payout,
                SUM(amount) as total_volume
            FROM binary_trades
        ");
        $stats = $stmt->fetch();
        
    } catch (PDOException $e) {
        error_log("Get binary trades error: " . $e->getMessage());
        $trades = [];
        $stats = [];
        $total_trades = 0;
        $total_pages = 1;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الصفقات - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --purple: #8B5CF6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Reuse sidebar styles from other admin pages */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-badge {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
            font-size: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .admin-card {
            padding: 20px;
            margin: 20px;
            background: rgba(220, 38, 38, 0.05);
            border: 1px solid rgba(220, 38, 38, 0.1);
            border-radius: 16px;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(220, 38, 38, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #DC2626, var(--accent));
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
        }

        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 900;
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            border-bottom: 2px solid var(--border);
        }

        .tab-btn {
            padding: 12px 24px;
            background: none;
            border: none;
            color: var(--text-muted);
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            font-family: 'Tajawal', sans-serif;
            text-decoration: none;
        }

        .tab-btn:hover,
        .tab-btn.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }

        /* Filters */
        .filters-section {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .filter-input,
        .filter-select {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
        }

        /* Table */
        .trades-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(220, 38, 38, 0.05);
        }

        th {
            padding: 16px 24px;
            text-align: right;
            font-weight: 700;
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        td {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
        }

        tbody tr:hover {
            background: rgba(220, 38, 38, 0.02);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-badge.open {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .status-badge.closed {
            background: rgba(139, 92, 246, 0.1);
            color: var(--purple);
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.1);
            color: var(--accent);
        }

        .status-badge.won {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-badge.lost {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .btn-danger:hover {
            background: var(--danger);
            color: white;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 24px;
            border-top: 1px solid var(--border);
        }

        .pagination-btn {
            padding: 8px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            text-decoration: none;
            font-weight: 600;
        }

        .pagination-btn:hover:not(.disabled) {
            background: linear-gradient(135deg, #DC2626, var(--accent));
            color: white;
        }

        .pagination-btn.disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            table {
                min-width: 1000px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <div class="logo-text">Admin Panel</div>
                    <div class="admin-badge">Administrator</div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div>
                    <div style="font-weight: 700;"><?= htmlspecialchars($admin['username']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted);">Super Admin</div>
                </div>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">الإدارة</div>
            <a href="index.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-credit-card"></i>
                <span>المدفوعات</span>
            </a>
            <a href="trades.php" class="nav-item active">
                <i class="fas fa-exchange-alt"></i>
                <span>الصفقات</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>الإعدادات</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-arrow-right"></i>
                <span>العودة للمنصة</span>
            </a>
            <a href="../logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">إدارة الصفقات</h1>
            <div class="breadcrumb">
                <a href="index.php">لوحة التحكم</a>
                <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                <span>الصفقات</span>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <?php if ($trade_type === 'spot'): ?>
                <div class="stat-card">
                    <div class="stat-label">إجمالي الصفقات</div>
                    <div class="stat-value" style="color: var(--purple);"><?= number_format($stats['total'] ?? 0) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">صفقات مفتوحة</div>
                    <div class="stat-value" style="color: var(--info);"><?= number_format($stats['open_trades'] ?? 0) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">إجمالي الأرباح</div>
                    <div class="stat-value" style="color: var(--success);">$<?= number_format($stats['total_profit'] ?? 0, 2) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">إجمالي الخسائر</div>
                    <div class="stat-value" style="color: var(--danger);">$<?= number_format(abs($stats['total_loss'] ?? 0), 2) ?></div>
                </div>
            <?php else: ?>
                <div class="stat-card">
                    <div class="stat-label">إجمالي الصفقات</div>
                    <div class="stat-value" style="color: var(--purple);"><?= number_format($stats['total'] ?? 0) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">صفقات معلقة</div>
                    <div class="stat-value" style="color: var(--accent);"><?= number_format($stats['pending'] ?? 0) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">صفقات رابحة</div>
                    <div class="stat-value" style="color: var(--success);"><?= number_format($stats['won'] ?? 0) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">صفقات خاسرة</div>
                    <div class="stat-value" style="color: var(--danger);"><?= number_format($stats['lost'] ?? 0) ?></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tabs -->
        <div class="tabs">
            <a href="?type=spot" class="tab-btn <?= $trade_type === 'spot' ? 'active' : '' ?>">
                <i class="fas fa-chart-line"></i> صفقات Spot
            </a>
            <a href="?type=binary" class="tab-btn <?= $trade_type === 'binary' ? 'active' : '' ?>">
                <i class="fas fa-chart-bar"></i> صفقات Binary
            </a>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <form method="GET">
                <input type="hidden" name="type" value="<?= htmlspecialchars($trade_type) ?>">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">الحالة</label>
                        <select name="status" class="filter-select" onchange="this.form.submit()">
                            <option value="all">الكل</option>
                            <?php if ($trade_type === 'spot'): ?>
                                <option value="open" <?= $status_filter === 'open' ? 'selected' : '' ?>>مفتوح</option>
                                <option value="closed" <?= $status_filter === 'closed' ? 'selected' : '' ?>>مغلق</option>
                            <?php else: ?>
                                <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>معلق</option>
                                <option value="won" <?= $status_filter === 'won' ? 'selected' : '' ?>>ربح</option>
                                <option value="lost" <?= $status_filter === 'lost' ? 'selected' : '' ?>>خسارة</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">بحث عن مستخدم</label>
                        <input type="text" name="user" class="filter-input" placeholder="اسم المستخدم أو البريد..." value="<?= htmlspecialchars($user_filter) ?>">
                    </div>

                    <div class="filter-group">
                        <label class="filter-label" style="opacity: 0;">بحث</label>
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-search"></i>
                            بحث
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Trades Table -->
        <div class="trades-card">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المستخدم</th>
                            <th>الزوج</th>
                            <?php if ($trade_type === 'spot'): ?>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>سعر الدخول</th>
                                <th>P/L</th>
                            <?php else: ?>
                                <th>الاتجاه</th>
                                <th>المبلغ</th>
                                <th>المدة</th>
                                <th>النتيجة</th>
                            <?php endif; ?>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($trades)): ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding: 48px; color: var(--text-muted);">
                                    لا توجد صفقات
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($trades as $trade): ?>
                                <tr>
                                    <td>#<?= $trade['id'] ?></td>
                                    <td>
                                        <div>
                                            <div style="font-weight: 600;"><?= htmlspecialchars($trade['username']) ?></div>
                                            <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($trade['email']) ?></div>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($trade['pair_name'] ?? $trade['symbol']) ?></td>
                                    <?php if ($trade_type === 'spot'): ?>
                                        <td>
                                            <span style="color: <?= $trade['type'] === 'buy' ? 'var(--success)' : 'var(--danger)' ?>">
                                                <?= $trade['type'] === 'buy' ? 'شراء' : 'بيع' ?>
                                            </span>
                                        </td>
                                        <td style="font-weight: 700;">$<?= number_format($trade['amount'], 2) ?></td>
                                        <td>$<?= number_format($trade['entry_price'], 2) ?></td>
                                        <td>
                                            <?php 
                                            $pl = $trade['status'] === 'open' ? $trade['current_profit_loss'] : $trade['profit_loss'];
                                            $pl_color = $pl >= 0 ? 'var(--success)' : 'var(--danger)';
                                            ?>
                                            <span style="font-weight: 700; color: <?= $pl_color ?>">
                                                <?= $pl >= 0 ? '+' : '' ?>$<?= number_format($pl, 2) ?>
                                            </span>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <span style="color: <?= $trade['direction'] === 'up' ? 'var(--success)' : 'var(--danger)' ?>">
                                                <i class="fas fa-arrow-<?= $trade['direction'] === 'up' ? 'up' : 'down' ?>"></i>
                                                <?= $trade['direction'] === 'up' ? 'صعود' : 'هبوط' ?>
                                            </span>
                                        </td>
                                        <td style="font-weight: 700;">$<?= number_format($trade['amount'], 2) ?></td>
                                        <td><?= $trade['duration'] ?>s</td>
                                        <td>
                                            <?php if ($trade['result']): ?>
                                                <span style="font-weight: 700; color: <?= $trade['result'] === 'won' ? 'var(--success)' : 'var(--danger)' ?>">
                                                    <?= $trade['result'] === 'won' ? '+$' . number_format($trade['payout'], 2) : '-$' . number_format($trade['amount'], 2) ?>
                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <span class="status-badge <?= $trade_type === 'spot' ? $trade['status'] : ($trade['status'] === 'pending' ? 'pending' : $trade['result']) ?>">
                                            <?php
                                            if ($trade_type === 'spot') {
                                                echo $trade['status'] === 'open' ? 'مفتوح' : 'مغلق';
                                            } else {
                                                if ($trade['status'] === 'pending') {
                                                    echo 'معلق';
                                                } else {
                                                    echo $trade['result'] === 'won' ? 'ربح' : 'خسارة';
                                                }
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td style="font-size: 13px; color: var(--text-muted);">
                                        <?= date('Y/m/d h:i A', strtotime($trade['created_at'])) ?>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 8px;">
                                            <?php if ($trade_type === 'spot' && $trade['status'] === 'open'): ?>
                                                <button class="btn btn-primary btn-sm" onclick="closeSpotTrade(<?= $trade['id'] ?>)">
                                                    <i class="fas fa-times-circle"></i> إغلاق
                                                </button>
                                            <?php endif; ?>
                                            <button class="btn btn-danger btn-sm" onclick="deleteTrade(<?= $trade['id'] ?>, '<?= $trade_type ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?type=<?= $trade_type ?>&status=<?= $status_filter ?>&user=<?= urlencode($user_filter) ?>&page=<?= $page - 1 ?>" class="pagination-btn">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php else: ?>
                        <span class="pagination-btn disabled">
                            <i class="fas fa-chevron-right"></i>
                        </span>
                    <?php endif; ?>

                    <span style="padding: 8px 16px; color: var(--text-muted);">
                        صفحة <?= $page ?> من <?= $total_pages ?>
                    </span>

                    <?php if ($page < $total_pages): ?>
                        <a href="?type=<?= $trade_type ?>&status=<?= $status_filter ?>&user=<?= urlencode($user_filter) ?>&page=<?= $page + 1 ?>" class="pagination-btn">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    <?php else: ?>
                        <span class="pagination-btn disabled">
                            <i class="fas fa-chevron-left"></i>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        function closeSpotTrade(tradeId) {
            if (!confirm('هل تريد إغلاق هذه الصفقة؟')) return;
            
            fetch('trades.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=close_spot_trade&trade_id=${tradeId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'حدث خطأ');
                }
            });
        }

        function deleteTrade(tradeId, tradeType) {
            if (!confirm('هل تريد حذف هذه الصفقة؟ لا يمكن التراجع عن هذا الإجراء.')) return;
            
            fetch('trades.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=delete_trade&trade_id=${tradeId}&trade_type=${tradeType}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }
    </script>
</body>
</html>
