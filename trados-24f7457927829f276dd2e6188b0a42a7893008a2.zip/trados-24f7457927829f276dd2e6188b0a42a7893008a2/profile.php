<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Update Profile Info
    if (isset($_POST['update_profile'])) {
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $full_name = sanitize($_POST['full_name'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        
        if (empty($username) || empty($email)) {
            $error_message = 'اسم المستخدم والبريد الإلكتروني مطلوبان';
        } else {
            // Check if username/email already exists for other users
            $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $user_id]);
            
            if ($stmt->fetch()) {
                $error_message = 'اسم المستخدم أو البريد الإلكتروني موجود بالفعل';
            } else {
                try {
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET username = ?, email = ?, full_name = ?, phone = ?, updated_at = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([$username, $email, $full_name, $phone, $user_id]);
                    
                    $success_message = 'تم تحديث البيانات بنجاح';
                    $user = get_user_data($pdo, $user_id); // Refresh user data
                    
                    // Log activity
                    log_activity($pdo, $user_id, 'profile_update', 'تحديث معلومات الملف الشخصي');
                    
                } catch (PDOException $e) {
                    $error_message = 'حدث خطأ أثناء التحديث';
                    error_log("Profile update error: " . $e->getMessage());
                }
            }
        }
    }
    
    // Change Password
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error_message = 'جميع حقول كلمة المرور مطلوبة';
        } elseif ($new_password !== $confirm_password) {
            $error_message = 'كلمة المرور الجديدة وتأكيدها غير متطابقين';
        } elseif (strlen($new_password) < 8) {
            $error_message = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل';
        } elseif (!password_verify($current_password, $user['password'])) {
            $error_message = 'كلمة المرور الحالية غير صحيحة';
        } else {
            try {
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                
                $success_message = 'تم تغيير كلمة المرور بنجاح';
                
                // Log activity
                log_activity($pdo, $user_id, 'password_change', 'تغيير كلمة المرور');
                
            } catch (PDOException $e) {
                $error_message = 'حدث خطأ أثناء تغيير كلمة المرور';
                error_log("Password change error: " . $e->getMessage());
            }
        }
    }
    
    // Update Preferences
    if (isset($_POST['update_preferences'])) {
        $language = sanitize($_POST['language'] ?? 'ar');
        $timezone = sanitize($_POST['timezone'] ?? 'UTC');
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        $trade_notifications = isset($_POST['trade_notifications']) ? 1 : 0;
        
        try {
            $preferences = json_encode([
                'language' => $language,
                'timezone' => $timezone,
                'email_notifications' => $email_notifications,
                'trade_notifications' => $trade_notifications
            ]);
            
            $stmt = $pdo->prepare("UPDATE users SET preferences = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$preferences, $user_id]);
            
            $_SESSION['language'] = $language;
            
            $success_message = 'تم تحديث الإعدادات بنجاح';
            $user = get_user_data($pdo, $user_id);
            
            // Log activity
            log_activity($pdo, $user_id, 'preferences_update', 'تحديث الإعدادات');
            
        } catch (PDOException $e) {
            $error_message = 'حدث خطأ أثناء تحديث الإعدادات';
            error_log("Preferences update error: " . $e->getMessage());
        }
    }
}

// Get user preferences
$preferences = json_decode($user['preferences'] ?? '{}', true);
$language = $preferences['language'] ?? 'ar';
$timezone = $preferences['timezone'] ?? 'UTC';
$email_notifications = $preferences['email_notifications'] ?? 1;
$trade_notifications = $preferences['trade_notifications'] ?? 1;

// Get recent activity logs
try {
    $stmt = $pdo->prepare("
        SELECT * FROM activity_logs 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute([$user_id]);
    $activity_logs = $stmt->fetchAll();
} catch (PDOException $e) {
    $activity_logs = [];
    error_log("Get activity logs error: " . $e->getMessage());
}

$notifications = get_user_notifications($pdo, $user_id, false, 5);
$unread_count = count(get_user_notifications($pdo, $user_id, true));
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - Trading Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar - Same as other pages */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-card {
            padding: 20px;
            margin: 20px;
            background: rgba(249, 158, 11, 0.05);
            border: 1px solid rgba(249, 158, 11, 0.1);
            border-radius: 16px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .user-name {
            font-weight: 700;
            font-size: 16px;
        }

        .user-balance {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 12px;
            color: var(--text-muted);
        }

        .balance-value {
            font-size: 20px;
            font-weight: 900;
            color: var(--success);
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(249, 158, 11, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent);
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main Content */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
            transition: color 0.3s;
        }

        .breadcrumb a:hover {
            color: var(--accent);
        }

        /* Alert Messages */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--success);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: var(--danger);
        }

        /* Profile Grid */
        .profile-grid {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 24px;
            margin-bottom: 32px;
        }

        /* Profile Card */
        .profile-card {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            text-align: center;
            height: fit-content;
        }

        .profile-avatar-large {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            font-weight: 900;
            color: white;
            margin: 0 auto 24px;
            box-shadow: 0 8px 24px rgba(249, 158, 11, 0.3);
        }

        .profile-name {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .profile-email {
            color: var(--text-muted);
            margin-bottom: 24px;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
        }

        .profile-stat {
            text-align: center;
        }

        .profile-stat-value {
            font-size: 24px;
            font-weight: 900;
            color: var(--accent);
        }

        .profile-stat-label {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            border-bottom: 2px solid var(--border);
        }

        .tab-btn {
            padding: 12px 24px;
            background: none;
            border: none;
            color: var(--text-muted);
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            font-family: 'Tajawal', sans-serif;
        }

        .tab-btn:hover {
            color: var(--text);
        }

        .tab-btn.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Form Sections */
        .form-section {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .form-section-title {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .form-section-title i {
            color: var(--accent);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .form-input,
        .form-select {
            padding: 12px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-family: 'Tajawal', sans-serif;
            transition: all 0.3s;
        }

        .form-input:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(249, 158, 11, 0.1);
        }

        .form-checkbox {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .form-checkbox:hover {
            border-color: var(--accent);
        }

        .form-checkbox input {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #DC2626);
            color: white;
            box-shadow: 0 8px 24px rgba(249, 158, 11, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(249, 158, 11, 0.4);
        }

        .btn-secondary {
            background: var(--secondary);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #2D3748;
        }

        /* Activity Table */
        .activity-table {
            width: 100%;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px;
            border-bottom: 1px solid var(--border);
            transition: background 0.2s;
        }

        .activity-item:hover {
            background: rgba(249, 158, 11, 0.02);
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(249, 158, 11, 0.1);
            color: var(--accent);
        }

        .activity-content {
            flex: 1;
        }

        .activity-action {
            font-weight: 600;
        }

        .activity-description {
            font-size: 13px;
            color: var(--text-muted);
        }

        .activity-time {
            font-size: 12px;
            color: var(--text-muted);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .page-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">₿</div>
                <div class="logo-text">Trading Pro</div>
            </div>
        </div>

        <div class="user-card">
            <div class="user-info">
                <div class="user-avatar"><?= strtoupper(substr($user['username'], 0, 2)) ?></div>
                <div>
                    <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                    <div class="user-email" style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($user['email']) ?></div>
                </div>
            </div>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح</span>
                <span class="balance-value">$<?= number_format($user['balance'], 2) ?></span>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">القائمة الرئيسية</div>
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="spot-trading.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>تداول فوري</span>
            </a>
            <a href="binary-trading.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                <span>خيارات ثنائية</span>
            </a>
            <a href="p2p-deposit.php" class="nav-item">
                <i class="fas fa-wallet"></i>
                <span>إضافة رصيد P2P</span>
            </a>
            
            <div class="nav-section-title">الحساب</div>
            <a href="transactions.php" class="nav-item">
                <i class="fas fa-receipt"></i>
                <span>المعاملات</span>
            </a>
            <a href="profile.php" class="nav-item active">
                <i class="fas fa-user"></i>
                <span>الملف الشخصي</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main">
        <div class="header">
            <h1 class="page-title">الملف الشخصي</h1>
            <div class="breadcrumb">
                <a href="dashboard.php">الرئيسية</a>
                <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                <span>الملف الشخصي</span>
            </div>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success_message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php endif; ?>

        <div class="profile-grid">
            <!-- Left - Profile Card -->
            <div class="profile-card">
                <div class="profile-avatar-large">
                    <?= strtoupper(substr($user['username'], 0, 2)) ?>
                </div>
                <h2 class="profile-name"><?= htmlspecialchars($user['username']) ?></h2>
                <p class="profile-email"><?= htmlspecialchars($user['email']) ?></p>
                
                <div class="profile-stats">
                    <div class="profile-stat">
                        <div class="profile-stat-value">$<?= number_format($user['balance'], 2) ?></div>
                        <div class="profile-stat-label">الرصيد</div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat-value"><?= date('Y/m/d', strtotime($user['created_at'])) ?></div>
                        <div class="profile-stat-label">تاريخ التسجيل</div>
                    </div>
                </div>
            </div>

            <!-- Right - Settings Tabs -->
            <div>
                <div class="tabs">
                    <button class="tab-btn active" onclick="switchTab('profile')">
                        <i class="fas fa-user"></i> معلومات الحساب
                    </button>
                    <button class="tab-btn" onclick="switchTab('security')">
                        <i class="fas fa-lock"></i> الأمان
                    </button>
                    <button class="tab-btn" onclick="switchTab('preferences')">
                        <i class="fas fa-cog"></i> الإعدادات
                    </button>
                    <button class="tab-btn" onclick="switchTab('activity')">
                        <i class="fas fa-history"></i> النشاط
                    </button>
                </div>

                <!-- Profile Tab -->
                <div id="tab-profile" class="tab-content active">
                    <form method="POST" class="form-section">
                        <h3 class="form-section-title">
                            <i class="fas fa-user-edit"></i>
                            تحديث معلومات الحساب
                        </h3>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">اسم المستخدم *</label>
                                <input type="text" name="username" class="form-input" value="<?= htmlspecialchars($user['username']) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">البريد الإلكتروني *</label>
                                <input type="email" name="email" class="form-input" value="<?= htmlspecialchars($user['email']) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">الاسم الكامل</label>
                                <input type="text" name="full_name" class="form-input" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="tel" name="phone" class="form-input" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                            </div>
                        </div>
                        
                        <div style="margin-top: 24px;">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                حفظ التغييرات
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Security Tab -->
                <div id="tab-security" class="tab-content">
                    <form method="POST" class="form-section">
                        <h3 class="form-section-title">
                            <i class="fas fa-key"></i>
                            تغيير كلمة المرور
                        </h3>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">كلمة المرور الحالية *</label>
                                <input type="password" name="current_password" class="form-input" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">كلمة المرور الجديدة *</label>
                                <input type="password" name="new_password" class="form-input" minlength="8" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">تأكيد كلمة المرور الجديدة *</label>
                                <input type="password" name="confirm_password" class="form-input" minlength="8" required>
                            </div>
                        </div>
                        
                        <div style="margin-top: 24px;">
                            <button type="submit" name="change_password" class="btn btn-primary">
                                <i class="fas fa-shield-alt"></i>
                                تغيير كلمة المرور
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Preferences Tab -->
                <div id="tab-preferences" class="tab-content">
                    <form method="POST" class="form-section">
                        <h3 class="form-section-title">
                            <i class="fas fa-sliders-h"></i>
                            الإعدادات والتفضيلات
                        </h3>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">اللغة</label>
                                <select name="language" class="form-select">
                                    <option value="ar" <?= $language === 'ar' ? 'selected' : '' ?>>العربية</option>
                                    <option value="en" <?= $language === 'en' ? 'selected' : '' ?>>English</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">المنطقة الزمنية</label>
                                <select name="timezone" class="form-select">
                                    <option value="UTC" <?= $timezone === 'UTC' ? 'selected' : '' ?>>UTC</option>
                                    <option value="Africa/Cairo" <?= $timezone === 'Africa/Cairo' ? 'selected' : '' ?>>القاهرة</option>
                                    <option value="Asia/Riyadh" <?= $timezone === 'Asia/Riyadh' ? 'selected' : '' ?>>الرياض</option>
                                    <option value="Asia/Dubai" <?= $timezone === 'Asia/Dubai' ? 'selected' : '' ?>>دبي</option>
                                </select>
                            </div>
                        </div>
                        
                        <div style="margin-top: 20px;">
                            <h4 style="font-size: 16px; margin-bottom: 16px;">الإشعارات</h4>
                            
                            <label class="form-checkbox">
                                <input type="checkbox" name="email_notifications" <?= $email_notifications ? 'checked' : '' ?>>
                                <span>إشعارات البريد الإلكتروني</span>
                            </label>
                            
                            <label class="form-checkbox" style="margin-top: 12px;">
                                <input type="checkbox" name="trade_notifications" <?= $trade_notifications ? 'checked' : '' ?>>
                                <span>إشعارات الصفقات</span>
                            </label>
                        </div>
                        
                        <div style="margin-top: 24px;">
                            <button type="submit" name="update_preferences" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                حفظ الإعدادات
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Activity Tab -->
                <div id="tab-activity" class="tab-content">
                    <div class="form-section">
                        <h3 class="form-section-title">
                            <i class="fas fa-list"></i>
                            سجل النشاط الأخير
                        </h3>
                        
                        <div class="activity-table">
                            <?php if (empty($activity_logs)): ?>
                                <div style="text-align: center; padding: 48px; color: var(--text-muted);">
                                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
                                    <p>لا يوجد نشاط حتى الآن</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($activity_logs as $log): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-<?= 
                                                $log['action'] === 'login' ? 'sign-in-alt' : 
                                                ($log['action'] === 'logout' ? 'sign-out-alt' : 
                                                ($log['action'] === 'profile_update' ? 'user-edit' : 
                                                ($log['action'] === 'password_change' ? 'key' : 'circle')))
                                            ?>"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-action"><?= htmlspecialchars($log['description']) ?></div>
                                            <div class="activity-description">
                                                IP: <?= htmlspecialchars($log['ip_address'] ?? 'Unknown') ?>
                                            </div>
                                        </div>
                                        <div class="activity-time">
                                            <?= date('Y/m/d h:i A', strtotime($log['created_at'])) ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        function switchTab(tabName) {
            // Remove active class from all tabs
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Add active class to selected tab
            event.target.classList.add('active');
            document.getElementById('tab-' + tabName).classList.add('active');
        }
        
        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>
