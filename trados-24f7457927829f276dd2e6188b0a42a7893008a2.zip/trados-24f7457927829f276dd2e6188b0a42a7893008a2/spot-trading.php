<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

// Require login
require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'open_trade') {
        $pair_id = intval($_POST['pair_id'] ?? 0);
        $symbol = sanitize($_POST['symbol'] ?? '');
        $type = sanitize($_POST['type'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $leverage = floatval($_POST['leverage'] ?? 1);
        
        // Validation
        if (empty($pair_id) || empty($symbol) || !in_array($type, ['buy', 'sell'])) {
            json_response(['success' => false, 'message' => 'بيانات غير صحيحة'], 400);
        }
        
        if ($amount < MIN_TRADE_AMOUNT) {
            json_response(['success' => false, 'message' => 'الحد الأدنى للتداول هو $' . MIN_TRADE_AMOUNT], 400);
        }
        
        if ($amount > $user['balance']) {
            json_response(['success' => false, 'message' => 'الرصيد غير كافٍ'], 400);
        }
        
        // Open trade
        $result = open_spot_trade($pdo, $user_id, $pair_id, $symbol, $type, $amount, $leverage);
        json_response($result);
        
    } elseif ($_POST['action'] === 'close_trade') {
        $trade_id = intval($_POST['trade_id'] ?? 0);
        
        if (empty($trade_id)) {
            json_response(['success' => false, 'message' => 'معرف الصفقة مطلوب'], 400);
        }
        
        $result = close_spot_trade($pdo, $trade_id, $user_id);
        json_response($result);
        
    } elseif ($_POST['action'] === 'get_price') {
        $symbol = sanitize($_POST['symbol'] ?? '');
        
        if (empty($symbol)) {
            json_response(['success' => false, 'message' => 'رمز العملة مطلوب'], 400);
        }
        
        $price = get_realtime_price($pdo, $symbol);
        
        if ($price === false) {
            json_response(['success' => false, 'message' => 'فشل الحصول على السعر'], 500);
        }
        
        json_response(['success' => true, 'price' => $price]);
    }
    
    exit;
}

// Get selected pair (default BTC)
$selected_symbol = sanitize($_GET['symbol'] ?? 'BTCUSDT');

// Get trading pairs
$stmt = $pdo->prepare("SELECT * FROM trading_pairs WHERE symbol = ? AND is_active = 1 AND spot_enabled = 1");
$stmt->execute([$selected_symbol]);
$selected_pair = $stmt->fetch();

if (!$selected_pair) {
    // Fallback to BTC
    $stmt = $pdo->prepare("SELECT * FROM trading_pairs WHERE symbol = 'BTCUSDT' AND is_active = 1");
    $stmt->execute();
    $selected_pair = $stmt->fetch();
    $selected_symbol = 'BTCUSDT';
}

// Get all pairs
$stmt = $pdo->query("SELECT * FROM trading_pairs WHERE is_active = 1 AND spot_enabled = 1 ORDER BY volume_24h DESC");
$all_pairs = $stmt->fetchAll();

// Get user's open trades
$stmt = $pdo->prepare("
    SELECT st.*, tp.name_ar, tp.name_en 
    FROM spot_trades st
    JOIN trading_pairs tp ON st.pair_id = tp.id
    WHERE st.user_id = ? AND st.status = 'open'
    ORDER BY st.created_at DESC
");
$stmt->execute([$user_id]);
$open_trades = $stmt->fetchAll();

// Get user's closed trades
$stmt = $pdo->prepare("
    SELECT st.*, tp.name_ar, tp.name_en 
    FROM spot_trades st
    JOIN trading_pairs tp ON st.pair_id = tp.id
    WHERE st.user_id = ? AND st.status = 'closed'
    ORDER BY st.closed_at DESC
    LIMIT 20
");
$stmt->execute([$user_id]);
$closed_trades = $stmt->fetchAll();

$current_language = $_SESSION['language'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_language; ?>" dir="<?php echo $current_language === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التداول الفوري - Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- TradingView Widget -->
    <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.95);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-red: #e74c3c;
            --accent-blue: #3498db;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(244, 162, 97, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(46, 204, 113, 0.03) 0%, transparent 50%);
            z-index: 0;
            pointer-events: none;
        }

        /* Top Bar */
        .top-bar {
            background: var(--secondary-bg);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
        }

        .top-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .back-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--accent-gold);
        }

        .user-balance {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .balance-value {
            font-size: 18px;
            font-weight: 900;
            color: var(--accent-green);
        }

        /* Main Container */
        .trading-container {
            display: grid;
            grid-template-columns: 280px 1fr 380px;
            height: calc(100vh - 70px);
            position: relative;
            z-index: 1;
        }

        /* Left Sidebar - Pairs List */
        .pairs-sidebar {
            background: var(--secondary-bg);
            border-left: 1px solid var(--border-color);
            overflow-y: auto;
            padding: 20px;
        }

        .pairs-sidebar::-webkit-scrollbar {
            width: 6px;
        }

        .pairs-sidebar::-webkit-scrollbar-thumb {
            background: var(--accent-gold);
            border-radius: 3px;
        }

        .pairs-header {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .pair-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .pair-item:hover,
        .pair-item.active {
            background: rgba(244, 162, 97, 0.1);
            border-color: var(--accent-gold);
        }

        .pair-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .pair-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        .pair-name {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 2px;
        }

        .pair-symbol {
            font-size: 11px;
            color: var(--text-secondary);
        }

        .pair-price-info {
            text-align: left;
        }

        .pair-price {
            font-weight: 700;
            font-size: 13px;
            margin-bottom: 2px;
        }

        .pair-change {
            font-size: 11px;
            font-weight: 600;
        }

        .pair-change.positive {
            color: var(--accent-green);
        }

        .pair-change.negative {
            color: var(--accent-red);
        }

        /* Center - Chart */
        .chart-section {
            display: flex;
            flex-direction: column;
            background: var(--primary-bg);
            overflow: hidden;
        }

        .chart-header {
            padding: 20px 24px;
            background: var(--secondary-bg);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .selected-pair-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .selected-pair-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .selected-pair-details h2 {
            font-size: 20px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .selected-pair-symbol {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .current-price {
            text-align: left;
        }

        .price-big {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .price-change-big {
            font-size: 14px;
            font-weight: 700;
        }

        .chart-container {
            flex: 1;
            background: #1a1e2e;
            position: relative;
        }

        #tradingview_chart {
            width: 100%;
            height: 100%;
        }

        /* Right Sidebar - Trading Panel */
        .trading-panel {
            background: var(--secondary-bg);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .trading-panel::-webkit-scrollbar {
            width: 6px;
        }

        .trading-panel::-webkit-scrollbar-thumb {
            background: var(--accent-gold);
            border-radius: 3px;
        }

        .panel-section {
            padding: 24px;
            border-bottom: 1px solid var(--border-color);
        }

        .panel-title {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Trade Form */
        .trade-type-tabs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }

        .tab-btn {
            padding: 12px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-secondary);
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .tab-btn.active.buy {
            background: var(--accent-green);
            border-color: var(--accent-green);
            color: white;
        }

        .tab-btn.active.sell {
            background: var(--accent-red);
            border-color: var(--accent-red);
            color: white;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            padding: 14px 16px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-primary);
            font-size: 15px;
            font-weight: 600;
            font-family: inherit;
            transition: all 0.3s;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent-gold);
            background: rgba(255, 255, 255, 0.05);
        }

        .input-group {
            position: relative;
        }

        .input-suffix {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 600;
        }

        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-top: 10px;
        }

        .quick-amount-btn {
            padding: 8px;
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-secondary);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .quick-amount-btn:hover {
            border-color: var(--accent-gold);
            color: var(--accent-gold);
        }

        .leverage-slider {
            width: 100%;
            -webkit-appearance: none;
            height: 6px;
            border-radius: 3px;
            background: var(--glass-bg);
            outline: none;
        }

        .leverage-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--accent-gold);
            cursor: pointer;
        }

        .leverage-value {
            text-align: center;
            margin-top: 10px;
            font-size: 18px;
            font-weight: 900;
            color: var(--accent-gold);
        }

        .trade-summary {
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 20px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 13px;
        }

        .summary-label {
            color: var(--text-secondary);
        }

        .summary-value {
            font-weight: 700;
        }

        .btn-trade {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-trade.buy {
            background: linear-gradient(135deg, var(--accent-green), #27ae60);
            box-shadow: 0 8px 25px rgba(46, 204, 113, 0.3);
        }

        .btn-trade.buy:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(46, 204, 113, 0.4);
        }

        .btn-trade.sell {
            background: linear-gradient(135deg, var(--accent-red), #c0392b);
            box-shadow: 0 8px 25px rgba(231, 76, 60, 0.3);
        }

        .btn-trade.sell:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(231, 76, 60, 0.4);
        }

        .btn-trade:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Open Trades */
        .trade-card {
            background: var(--glass-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 12px;
        }

        .trade-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .trade-card-symbol {
            font-weight: 700;
            font-size: 15px;
        }

        .trade-card-type {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .trade-card-type.buy {
            background: rgba(46, 204, 113, 0.15);
            color: var(--accent-green);
        }

        .trade-card-type.sell {
            background: rgba(231, 76, 60, 0.15);
            color: var(--accent-red);
        }

        .trade-card-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 12px;
        }

        .trade-info-item {
            font-size: 12px;
        }

        .trade-info-label {
            color: var(--text-secondary);
            margin-bottom: 4px;
        }

        .trade-info-value {
            font-weight: 700;
            font-size: 13px;
        }

        .trade-card-pnl {
            padding: 10px;
            background: var(--glass-bg);
            border-radius: 8px;
            margin-bottom: 12px;
            text-align: center;
        }

        .pnl-label {
            font-size: 11px;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }

        .pnl-value {
            font-size: 20px;
            font-weight: 900;
        }

        .pnl-value.profit {
            color: var(--accent-green);
        }

        .pnl-value.loss {
            color: var(--accent-red);
        }

        .btn-close-trade {
            width: 100%;
            padding: 10px;
            background: var(--accent-red);
            border: none;
            border-radius: 8px;
            color: white;
            font-weight: 700;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-close-trade:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 13px;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border: 1px solid rgba(46, 204, 113, 0.3);
            color: var(--accent-green);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: var(--accent-red);
        }

        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }

        .tab {
            padding: 12px 20px;
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            position: relative;
            transition: all 0.3s;
        }

        .tab.active {
            color: var(--accent-gold);
        }

        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--accent-gold);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Responsive */
        @media (max-width: 1400px) {
            .trading-container {
                grid-template-columns: 240px 1fr 340px;
            }
        }

        @media (max-width: 1024px) {
            .trading-container {
                grid-template-columns: 1fr;
                height: auto;
            }

            .pairs-sidebar,
            .trading-panel {
                position: fixed;
                top: 70px;
                height: calc(100vh - 70px);
                z-index: 200;
                transform: translateX(100%);
                transition: transform 0.3s;
            }

            .pairs-sidebar.active,
            .trading-panel.active {
                transform: translateX(0);
            }

            .pairs-sidebar {
                right: 0;
                width: 300px;
            }

            .trading-panel {
                left: 0;
                width: 100%;
                max-width: 400px;
            }

            .chart-section {
                height: 500px;
            }
        }
    </style>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="top-left">
            <a href="dashboard.php" class="back-btn">
                ← العودة للوحة التحكم
            </a>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح:</span>
                <span class="balance-value" id="userBalance">$<?php echo number_format($user['balance'], 2); ?></span>
            </div>
        </div>
    </div>

    <!-- Main Trading Container -->
    <div class="trading-container">
        <!-- Left Sidebar - Pairs List -->
        <div class="pairs-sidebar" id="pairsSidebar">
            <div class="pairs-header">🪙 العملات المتاحة</div>
            <?php foreach ($all_pairs as $pair): ?>
                <div class="pair-item <?php echo $pair['symbol'] === $selected_symbol ? 'active' : ''; ?>" 
                     onclick="window.location.href='?symbol=<?php echo $pair['symbol']; ?>'">
                    <div class="pair-info">
                        <div class="pair-icon">₿</div>
                        <div>
                            <div class="pair-name"><?php echo $pair['name_ar']; ?></div>
                            <div class="pair-symbol"><?php echo $pair['symbol']; ?></div>
                        </div>
                    </div>
                    <div class="pair-price-info">
                        <div class="pair-price">$<?php echo number_format($pair['current_price'], 2); ?></div>
                        <div class="pair-change <?php echo $pair['price_change_24h'] >= 0 ? 'positive' : 'negative'; ?>">
                            <?php echo $pair['price_change_24h'] >= 0 ? '↑' : '↓'; ?>
                            <?php echo abs($pair['price_change_24h']); ?>%
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Center - Chart -->
        <div class="chart-section">
            <div class="chart-header">
                <div class="selected-pair-info">
                    <div class="selected-pair-icon">₿</div>
                    <div class="selected-pair-details">
                        <h2><?php echo $selected_pair['name_ar']; ?></h2>
                        <div class="selected-pair-symbol"><?php echo $selected_pair['symbol']; ?></div>
                    </div>
                </div>
                <div class="current-price">
                    <div class="price-big" id="currentPrice">$<?php echo number_format($selected_pair['current_price'], 2); ?></div>
                    <div class="price-change-big <?php echo $selected_pair['price_change_24h'] >= 0 ? 'positive' : 'negative'; ?>" id="priceChange">
                        <?php echo $selected_pair['price_change_24h'] >= 0 ? '↑' : '↓'; ?>
                        <?php echo abs($selected_pair['price_change_24h']); ?>%
                    </div>
                </div>
            </div>
            <div class="chart-container">
                <div id="tradingview_chart"></div>
            </div>
        </div>

        <!-- Right Sidebar - Trading Panel -->
        <div class="trading-panel" id="tradingPanel">
            <!-- Trade Form -->
            <div class="panel-section">
                <div class="panel-title">📊 فتح صفقة جديدة</div>

                <div id="tradeAlert"></div>

                <form id="tradeForm">
                    <input type="hidden" name="action" value="open_trade">
                    <input type="hidden" name="pair_id" value="<?php echo $selected_pair['id']; ?>">
                    <input type="hidden" name="symbol" value="<?php echo $selected_pair['symbol']; ?>">

                    <div class="trade-type-tabs">
                        <button type="button" class="tab-btn buy active" data-type="buy" id="buyTab">
                            شراء 📈
                        </button>
                        <button type="button" class="tab-btn sell" data-type="sell" id="sellTab">
                            بيع 📉
                        </button>
                    </div>

                    <input type="hidden" name="type" id="tradeType" value="buy">

                    <div class="form-group">
                        <label class="form-label">المبلغ (USD)</label>
                        <div class="input-group">
                            <input type="number" name="amount" id="tradeAmount" class="form-input" 
                                   placeholder="أدخل المبلغ" min="<?php echo MIN_TRADE_AMOUNT; ?>" 
                                   max="<?php echo $user['balance']; ?>" step="0.01" required>
                            <span class="input-suffix">$</span>
                        </div>
                        <div class="quick-amounts">
                            <button type="button" class="quick-amount-btn" data-amount="10">$10</button>
                            <button type="button" class="quick-amount-btn" data-amount="50">$50</button>
                            <button type="button" class="quick-amount-btn" data-amount="100">$100</button>
                            <button type="button" class="quick-amount-btn" data-amount="<?php echo floor($user['balance']); ?>">الكل</button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الرافعة المالية (1x - 10x)</label>
                        <input type="range" name="leverage" id="leverageSlider" class="leverage-slider" 
                               min="1" max="10" value="1" step="0.5">
                        <div class="leverage-value" id="leverageValue">1.0x</div>
                    </div>

                    <div class="trade-summary">
                        <div class="summary-row">
                            <span class="summary-label">السعر الحالي:</span>
                            <span class="summary-value" id="summaryPrice">$<?php echo number_format($selected_pair['current_price'], 2); ?></span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">الكمية المتوقعة:</span>
                            <span class="summary-value" id="summaryQuantity">0.00</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">الرسوم (0.1%):</span>
                            <span class="summary-value" id="summaryFee">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">الإجمالي:</span>
                            <span class="summary-value" id="summaryTotal">$0.00</span>
                        </div>
                    </div>

                    <button type="submit" class="btn-trade buy" id="tradeButton">
                        <span id="tradeButtonText">شراء الآن 🚀</span>
                        <span id="tradeButtonLoading" style="display: none;" class="loading"></span>
                    </button>
                </form>
            </div>

            <!-- Open Trades -->
            <div class="panel-section">
                <div class="tabs">
                    <button class="tab active" data-tab="open">صفقات مفتوحة (<?php echo count($open_trades); ?>)</button>
                    <button class="tab" data-tab="closed">صفقات مغلقة</button>
                </div>

                <div class="tab-content active" id="openTradesContent">
                    <?php if (empty($open_trades)): ?>
                        <div style="text-align: center; padding: 40px 20px; color: var(--text-secondary);">
                            <div style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;">📭</div>
                            <div>لا توجد صفقات مفتوحة</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($open_trades as $trade): 
                            // Calculate current P/L
                            $current_price = $selected_pair['current_price'];
                            if ($trade['type'] === 'buy') {
                                $pnl = ($current_price - $trade['entry_price']) * $trade['quantity'];
                            } else {
                                $pnl = ($trade['entry_price'] - $current_price) * $trade['quantity'];
                            }
                            $pnl_percentage = ($pnl / $trade['amount']) * 100;
                        ?>
                            <div class="trade-card">
                                <div class="trade-card-header">
                                    <span class="trade-card-symbol"><?php echo $trade['symbol']; ?></span>
                                    <span class="trade-card-type <?php echo $trade['type']; ?>">
                                        <?php echo $trade['type'] === 'buy' ? 'شراء' : 'بيع'; ?>
                                    </span>
                                </div>
                                <div class="trade-card-info">
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">المبلغ</div>
                                        <div class="trade-info-value">$<?php echo number_format($trade['amount'], 2); ?></div>
                                    </div>
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">سعر الدخول</div>
                                        <div class="trade-info-value">$<?php echo number_format($trade['entry_price'], 2); ?></div>
                                    </div>
                                </div>
                                <div class="trade-card-pnl">
                                    <div class="pnl-label">الربح / الخسارة</div>
                                    <div class="pnl-value <?php echo $pnl >= 0 ? 'profit' : 'loss'; ?>">
                                        <?php echo $pnl >= 0 ? '+' : ''; ?>$<?php echo number_format($pnl, 2); ?>
                                        (<?php echo number_format($pnl_percentage, 2); ?>%)
                                    </div>
                                </div>
                                <button class="btn-close-trade" onclick="closeTrade(<?php echo $trade['id']; ?>)">
                                    إغلاق الصفقة
                                </button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="tab-content" id="closedTradesContent">
                    <?php if (empty($closed_trades)): ?>
                        <div style="text-align: center; padding: 40px 20px; color: var(--text-secondary);">
                            <div style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;">📭</div>
                            <div>لا توجد صفقات مغلقة</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($closed_trades as $trade): ?>
                            <div class="trade-card">
                                <div class="trade-card-header">
                                    <span class="trade-card-symbol"><?php echo $trade['symbol']; ?></span>
                                    <span class="trade-card-type <?php echo $trade['type']; ?>">
                                        <?php echo $trade['type'] === 'buy' ? 'شراء' : 'بيع'; ?>
                                    </span>
                                </div>
                                <div class="trade-card-info">
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">المبلغ</div>
                                        <div class="trade-info-value">$<?php echo number_format($trade['amount'], 2); ?></div>
                                    </div>
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">سعر الدخول</div>
                                        <div class="trade-info-value">$<?php echo number_format($trade['entry_price'], 2); ?></div>
                                    </div>
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">سعر الخروج</div>
                                        <div class="trade-info-value">$<?php echo number_format($trade['exit_price'], 2); ?></div>
                                    </div>
                                    <div class="trade-info-item">
                                        <div class="trade-info-label">الربح/الخسارة</div>
                                        <div class="trade-info-value" style="color: <?php echo $trade['profit_loss'] >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'; ?>">
                                            $<?php echo number_format($trade['profit_loss'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // TradingView Chart
        new TradingView.widget({
            "container_id": "tradingview_chart",
            "autosize": true,
            "symbol": "BINANCE:<?php echo str_replace('USDT', '', $selected_pair['symbol']); ?>USDT",
            "interval": "15",
            "timezone": "Africa/Cairo",
            "theme": "dark",
            "style": "1",
            "locale": "ar_AE",
            "toolbar_bg": "#0a0e1a",
            "enable_publishing": false,
            "hide_side_toolbar": false,
            "allow_symbol_change": false,
            "save_image": false,
            "backgroundColor": "#0a0e1a",
            "gridColor": "rgba(255, 255, 255, 0.06)",
            "hide_top_toolbar": false,
            "hide_legend": false,
            "studies": [
                "MASimple@tv-basicstudies",
                "RSI@tv-basicstudies"
            ]
        });

        // Trade Type Tabs
        const buyTab = document.getElementById('buyTab');
        const sellTab = document.getElementById('sellTab');
        const tradeType = document.getElementById('tradeType');
        const tradeButton = document.getElementById('tradeButton');
        const tradeButtonText = document.getElementById('tradeButtonText');

        buyTab.addEventListener('click', () => {
            buyTab.classList.add('active');
            sellTab.classList.remove('active');
            tradeType.value = 'buy';
            tradeButton.className = 'btn-trade buy';
            tradeButtonText.textContent = 'شراء الآن 🚀';
        });

        sellTab.addEventListener('click', () => {
            sellTab.classList.add('active');
            buyTab.classList.remove('active');
            tradeType.value = 'sell';
            tradeButton.className = 'btn-trade sell';
            tradeButtonText.textContent = 'بيع الآن 📉';
        });

        // Quick Amount Buttons
        document.querySelectorAll('.quick-amount-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('tradeAmount').value = btn.dataset.amount;
                updateTradeSummary();
            });
        });

        // Leverage Slider
        const leverageSlider = document.getElementById('leverageSlider');
        const leverageValue = document.getElementById('leverageValue');

        leverageSlider.addEventListener('input', () => {
            leverageValue.textContent = parseFloat(leverageSlider.value).toFixed(1) + 'x';
        });

        // Update Trade Summary
        const tradeAmount = document.getElementById('tradeAmount');
        const currentPrice = <?php echo $selected_pair['current_price']; ?>;

        tradeAmount.addEventListener('input', updateTradeSummary);

        function updateTradeSummary() {
            const amount = parseFloat(tradeAmount.value) || 0;
            const quantity = amount / currentPrice;
            const fee = amount * 0.001;
            const total = amount + fee;

            document.getElementById('summaryQuantity').textContent = quantity.toFixed(8);
            document.getElementById('summaryFee').textContent = '$' + fee.toFixed(2);
            document.getElementById('summaryTotal').textContent = '$' + total.toFixed(2);
        }

        // Trade Form Submission
        const tradeForm = document.getElementById('tradeForm');
        const tradeAlert = document.getElementById('tradeAlert');
        const tradeButtonLoading = document.getElementById('tradeButtonLoading');

        tradeForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            tradeButton.disabled = true;
            tradeButtonText.style.display = 'none';
            tradeButtonLoading.style.display = 'inline-block';
            tradeAlert.innerHTML = '';

            const formData = new FormData(tradeForm);

            try {
                const response = await fetch('spot-trading.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    tradeAlert.innerHTML = `<div class="alert alert-success">${result.message}</div>`;
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    tradeAlert.innerHTML = `<div class="alert alert-error">${result.message}</div>`;
                    tradeButton.disabled = false;
                    tradeButtonText.style.display = 'inline';
                    tradeButtonLoading.style.display = 'none';
                }
            } catch (error) {
                tradeAlert.innerHTML = '<div class="alert alert-error">حدث خطأ في الاتصال</div>';
                tradeButton.disabled = false;
                tradeButtonText.style.display = 'inline';
                tradeButtonLoading.style.display = 'none';
            }
        });

        // Close Trade
        async function closeTrade(tradeId) {
            if (!confirm('هل أنت متأكد من إغلاق هذه الصفقة؟')) {
                return;
            }

            const formData = new FormData();
            formData.append('action', 'close_trade');
            formData.append('trade_id', tradeId);

            try {
                const response = await fetch('spot-trading.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    alert(result.message);
                    window.location.reload();
                } else {
                    alert(result.message);
                }
            } catch (error) {
                alert('حدث خطأ في الاتصال');
            }
        }

        // Tabs
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;

                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

                tab.classList.add('active');
                document.getElementById(tabName + 'TradesContent').classList.add('active');
            });
        });

        // Update prices every 30 seconds
        setInterval(() => {
            fetch('spot-trading.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=get_price&symbol=<?php echo $selected_pair['symbol']; ?>'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('currentPrice').textContent = '$' + parseFloat(data.price).toFixed(2);
                    document.getElementById('summaryPrice').textContent = '$' + parseFloat(data.price).toFixed(2);
                }
            })
            .catch(err => console.error('Price update failed:', err));
        }, 30000);
    </script>
</body>
</html>
