<?php
define('APP_ACCESS', true);
require_once 'config.php';

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

// Handle login request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);
        
        if (empty($email) || empty($password)) {
            json_response(['success' => false, 'message' => 'Please fill all fields'], 400);
        }
        
        // Get user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $email]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($password, $user['password'])) {
            log_activity($pdo, 'failed_login', "Failed login attempt for: $email");
            json_response(['success' => false, 'message' => 'Invalid credentials'], 401);
        }
        
        if (!$user['is_active']) {
            json_response(['success' => false, 'message' => 'Account is disabled'], 403);
        }
        
        // Create session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['language'] = $user['language'];
        
        // Update last login
        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW(), ip_address = ? WHERE id = ?");
        $stmt->execute([get_client_ip(), $user['id']]);
        
        log_activity($pdo, 'login', 'User logged in successfully', $user['id']);
        
        json_response([
            'success' => true,
            'message' => 'Login successful',
            'redirect' => 'dashboard.php'
        ]);
        
    } catch (Exception $e) {
        json_response(['success' => false, 'message' => 'An error occurred'], 500);
    }
}

$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-bg: #0a0e1a;
            --secondary-bg: #141927;
            --card-bg: rgba(20, 25, 39, 0.8);
            --accent-gold: #f4a261;
            --accent-green: #2ecc71;
            --accent-red: #e74c3c;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: rgba(244, 162, 97, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.03);
            --shadow-glow: rgba(244, 162, 97, 0.15);
        }

        body {
            font-family: 'Tajawal', 'Poppins', sans-serif;
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        /* Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(244, 162, 97, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(46, 204, 113, 0.03) 0%, transparent 50%),
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.02) 0%, transparent 70%);
            animation: gradientShift 20s ease infinite;
            z-index: 0;
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        /* Floating particles */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: var(--accent-gold);
            border-radius: 50%;
            opacity: 0.3;
            animation: float linear infinite;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.3;
            }
            90% {
                opacity: 0.3;
            }
            100% {
                transform: translateY(-100px) translateX(100px);
                opacity: 0;
            }
        }

        .login-container {
            width: 100%;
            max-width: 480px;
            padding: 20px;
            position: relative;
            z-index: 2;
            animation: slideInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 24px;
            padding: 48px 40px;
            box-shadow: 
                0 20px 60px rgba(0, 0, 0, 0.4),
                0 0 40px var(--shadow-glow),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
            position: relative;
            overflow: hidden;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-gold), var(--accent-green));
        }

        .logo-container {
            text-align: center;
            margin-bottom: 40px;
        }

        .logo {
            width: 60px;
            height: 60px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 900;
            color: white;
            box-shadow: 0 10px 30px rgba(244, 162, 97, 0.3);
            animation: logoFloat 3s ease-in-out infinite;
        }

        @keyframes logoFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--text-primary), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .subtitle {
            color: var(--text-secondary);
            font-size: 15px;
            font-weight: 400;
        }

        .form-group {
            margin-bottom: 24px;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-secondary);
            transition: color 0.3s;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: var(--text-secondary);
            transition: color 0.3s;
            z-index: 1;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 16px 20px 16px 52px;
            background: var(--glass-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            outline: none;
        }

        input:focus {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(244, 162, 97, 0.1);
        }

        input:focus + .input-icon {
            color: var(--accent-gold);
        }

        input:focus ~ label {
            color: var(--accent-gold);
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            font-size: 14px;
        }

        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--accent-gold);
            cursor: pointer;
        }

        .forgot-link {
            color: var(--accent-gold);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .forgot-link::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 1px;
            background: var(--accent-gold);
            transition: width 0.3s;
        }

        .forgot-link:hover::after {
            width: 100%;
        }

        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--accent-gold), #e76f51);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(244, 162, 97, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn-login:hover::before {
            left: 100%;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(244, 162, 97, 0.4);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .divider {
            display: flex;
            align-items: center;
            gap: 16px;
            margin: 32px 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }

        .divider span {
            color: var(--text-secondary);
            font-size: 13px;
        }

        .register-link {
            text-align: center;
            font-size: 14px;
            color: var(--text-secondary);
        }

        .register-link a {
            color: var(--accent-gold);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .register-link a:hover {
            color: #e76f51;
        }

        .language-switcher {
            position: absolute;
            top: 20px;
            left: 20px;
            display: flex;
            gap: 8px;
            background: var(--glass-bg);
            padding: 8px 12px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 10;
        }

        .lang-btn {
            padding: 6px 12px;
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            border-radius: 6px;
            transition: all 0.3s;
        }

        .lang-btn.active {
            background: var(--accent-gold);
            color: white;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            display: none;
            animation: slideInDown 0.3s;
        }

        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border: 1px solid rgba(46, 204, 113, 0.3);
            color: var(--accent-green);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: var(--accent-red);
        }

        .loading-spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive */
        @media (max-width: 600px) {
            .login-container {
                padding: 15px;
            }

            .login-card {
                padding: 36px 24px;
            }

            h1 {
                font-size: 26px;
            }

            .language-switcher {
                top: 10px;
                left: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="particles">
        <script>
            for(let i = 0; i < 30; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particle.style.animationDelay = Math.random() * 5 + 's';
                document.querySelector('.particles').appendChild(particle);
            }
        </script>
    </div>

    <div class="language-switcher">
        <button class="lang-btn active" data-lang="ar">عربي</button>
        <button class="lang-btn" data-lang="en">English</button>
    </div>

    <div class="login-container">
        <div class="login-card">
            <div class="logo-container">
                <div class="logo">₿</div>
                <h1>تسجيل الدخول</h1>
                <p class="subtitle">مرحباً بعودتك إلى منصة التداول</p>
            </div>

            <div id="alert" class="alert"></div>

            <form id="loginForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="form-group">
                    <label for="email">البريد الإلكتروني أو اسم المستخدم</label>
                    <div class="input-wrapper">
                        <input type="text" id="email" name="email" required autocomplete="username">
                        <span class="input-icon">👤</span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">كلمة المرور</label>
                    <div class="input-wrapper">
                        <input type="password" id="password" name="password" required autocomplete="current-password">
                        <span class="input-icon">🔒</span>
                    </div>
                </div>

                <div class="remember-forgot">
                    <div class="checkbox-wrapper">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember" style="margin: 0;">تذكرني</label>
                    </div>
                    <a href="#" class="forgot-link">نسيت كلمة المرور؟</a>
                </div>

                <button type="submit" class="btn-login" id="loginBtn">
                    <span id="btnText">تسجيل الدخول</span>
                    <div class="loading-spinner" id="spinner"></div>
                </button>
            </form>

            <div class="divider">
                <span>أو</span>
            </div>

            <div class="register-link">
                لا تملك حساب؟ <a href="register.php">سجل الآن</a>
            </div>
        </div>
    </div>

    <script>
        // Language Switcher
        const langBtns = document.querySelectorAll('.lang-btn');
        const translations = {
            ar: {
                title: 'تسجيل الدخول',
                subtitle: 'مرحباً بعودتك إلى منصة التداول',
                emailLabel: 'البريد الإلكتروني أو اسم المستخدم',
                passwordLabel: 'كلمة المرور',
                remember: 'تذكرني',
                forgot: 'نسيت كلمة المرور؟',
                loginBtn: 'تسجيل الدخول',
                divider: 'أو',
                noAccount: 'لا تملك حساب؟',
                register: 'سجل الآن'
            },
            en: {
                title: 'Login',
                subtitle: 'Welcome back to Trading Platform',
                emailLabel: 'Email or Username',
                passwordLabel: 'Password',
                remember: 'Remember me',
                forgot: 'Forgot password?',
                loginBtn: 'Login',
                divider: 'or',
                noAccount: "Don't have an account?",
                register: 'Register now'
            }
        };

        langBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.dataset.lang;
                langBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                document.documentElement.lang = lang;
                document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
                
                // Update text
                const t = translations[lang];
                document.querySelector('h1').textContent = t.title;
                document.querySelector('.subtitle').textContent = t.subtitle;
                document.querySelector('label[for="email"]').textContent = t.emailLabel;
                document.querySelector('label[for="password"]').textContent = t.passwordLabel;
                document.querySelector('label[for="remember"]').textContent = t.remember;
                document.querySelector('.forgot-link').textContent = t.forgot;
                document.querySelector('#btnText').textContent = t.loginBtn;
                document.querySelector('.divider span').textContent = t.divider;
                document.querySelector('.register-link').innerHTML = `${t.noAccount} <a href="register.php">${t.register}</a>`;
            });
        });

        // Login Form Handler
        const loginForm = document.getElementById('loginForm');
        const loginBtn = document.getElementById('loginBtn');
        const btnText = document.getElementById('btnText');
        const spinner = document.getElementById('spinner');
        const alert = document.getElementById('alert');

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            loginBtn.disabled = true;
            btnText.style.display = 'none';
            spinner.style.display = 'block';
            alert.style.display = 'none';

            const formData = new FormData(loginForm);

            try {
                const response = await fetch('login.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    alert.textContent = result.message;
                    alert.className = 'alert alert-success';
                    alert.style.display = 'block';
                    
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1000);
                } else {
                    alert.textContent = result.message;
                    alert.className = 'alert alert-error';
                    alert.style.display = 'block';
                    
                    loginBtn.disabled = false;
                    btnText.style.display = 'inline';
                    spinner.style.display = 'none';
                }
            } catch (error) {
                alert.textContent = 'حدث خطأ في الاتصال. حاول مرة أخرى.';
                alert.className = 'alert alert-error';
                alert.style.display = 'block';
                
                loginBtn.disabled = false;
                btnText.style.display = 'inline';
                spinner.style.display = 'none';
            }
        });

        // Input animations
        const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.parentElement.querySelector('label').style.color = 'var(--accent-gold)';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.parentElement.querySelector('label').style.color = 'var(--text-secondary)';
                }
            });
        });
    </script>
</body>
</html>
