<?php
define('APP_ACCESS', true);
require_once 'config.php';
require_once 'functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$user = get_user_data($pdo, $user_id);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'mark_read') {
        $notification_id = intval($_POST['notification_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE id = ? AND user_id = ?
            ");
            $stmt->execute([$notification_id, $user_id]);
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'mark_all_read') {
        try {
            $stmt = $pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE user_id = ? AND is_read = 0
            ");
            $stmt->execute([$user_id]);
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'delete') {
        $notification_id = intval($_POST['notification_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
            $stmt->execute([$notification_id, $user_id]);
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    if ($_POST['action'] === 'delete_all') {
        try {
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            json_response(['success' => true]);
        } catch (PDOException $e) {
            json_response(['success' => false, 'message' => 'حدث خطأ'], 500);
        }
    }
    
    exit;
}

// Get filter
$filter = sanitize($_GET['filter'] ?? 'all');

// Get notifications
$where = "user_id = ?";
$params = [$user_id];

if ($filter === 'unread') {
    $where .= " AND is_read = 0";
}

try {
    $stmt = $pdo->prepare("
        SELECT * FROM notifications 
        WHERE $where
        ORDER BY created_at DESC
        LIMIT 100
    ");
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Get notifications error: " . $e->getMessage());
    $notifications = [];
}

// Get counts
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN is_read = 0 THEN 1 END) as unread
        FROM notifications 
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $counts = $stmt->fetch();
} catch (PDOException $e) {
    $counts = ['total' => 0, 'unread' => 0];
}

$unread_count = $counts['unread'] ?? 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإشعارات - Trading Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #0F172A;
            --secondary: #1E293B;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --info: #3B82F6;
            --text: #F8FAFC;
            --text-muted: #94A3B8;
            --border: rgba(148, 163, 184, 0.1);
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--primary);
            color: var(--text);
            line-height: 1.6;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            border-left: 1px solid var(--border);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 2px; }

        .logo {
            padding: 30px;
            border-bottom: 1px solid var(--border);
        }

        .logo-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .logo-text {
            font-size: 22px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-card {
            padding: 20px;
            margin: 20px;
            background: rgba(249, 158, 11, 0.05);
            border: 1px solid rgba(249, 158, 11, 0.1);
            border-radius: 16px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #DC2626);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
        }

        .user-name {
            font-weight: 700;
            font-size: 16px;
        }

        .user-balance {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
        }

        .balance-label {
            font-size: 12px;
            color: var(--text-muted);
        }

        .balance-value {
            font-size: 20px;
            font-weight: 900;
            color: var(--success);
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-section-title {
            padding: 0 20px 10px;
            font-size: 11px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .nav-item:hover,
        .nav-item.active {
            color: var(--text);
            background: rgba(249, 158, 11, 0.05);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent);
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main */
        .main {
            margin-right: 280px;
            padding: 30px;
            min-height: 100vh;
        }

        .header {
            margin-bottom: 32px;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
        }

        .breadcrumb a:hover {
            color: var(--accent);
        }

        /* Actions Bar */
        .actions-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 24px;
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            margin-bottom: 24px;
        }

        .filter-tabs {
            display: flex;
            gap: 8px;
        }

        .filter-btn {
            padding: 8px 16px;
            background: var(--primary);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .filter-btn:hover,
        .filter-btn.active {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-family: 'Tajawal', sans-serif;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #DC2626);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(249, 158, 11, 0.3);
        }

        .btn-secondary {
            background: var(--primary);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #2D3748;
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .btn-danger:hover {
            background: var(--danger);
            color: white;
        }

        /* Notifications List */
        .notifications-container {
            background: var(--secondary);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
        }

        .notification-item {
            display: flex;
            align-items: flex-start;
            gap: 16px;
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            transition: all 0.3s;
            cursor: pointer;
        }

        .notification-item:hover {
            background: rgba(249, 158, 11, 0.02);
        }

        .notification-item.unread {
            background: rgba(249, 158, 11, 0.05);
        }

        .notification-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }

        .notification-icon.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .notification-icon.info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .notification-icon.warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--accent);
        }

        .notification-icon.danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .notification-content {
            flex: 1;
        }

        .notification-title {
            font-weight: 700;
            font-size: 15px;
            margin-bottom: 4px;
        }

        .notification-message {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 8px;
        }

        .notification-time {
            font-size: 12px;
            color: var(--text-muted);
        }

        .notification-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .notification-action-btn {
            padding: 6px 12px;
            background: none;
            border: 1px solid var(--border);
            border-radius: 6px;
            color: var(--text-muted);
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Tajawal', sans-serif;
        }

        .notification-action-btn:hover {
            background: var(--primary);
            color: var(--text);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 24px;
        }

        .empty-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 24px;
            background: rgba(249, 158, 11, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: var(--accent);
        }

        .empty-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .empty-text {
            color: var(--text-muted);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main {
                margin-right: 0;
                padding: 20px;
            }

            .actions-bar {
                flex-direction: column;
                gap: 16px;
                align-items: stretch;
            }

            .notification-item {
                flex-direction: column;
            }

            .page-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-content">
                <div class="logo-icon">₿</div>
                <div class="logo-text">Trading Pro</div>
            </div>
        </div>

        <div class="user-card">
            <div class="user-info">
                <div class="user-avatar"><?= strtoupper(substr($user['username'], 0, 2)) ?></div>
                <div>
                    <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                    <div class="user-email" style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($user['email']) ?></div>
                </div>
            </div>
            <div class="user-balance">
                <span class="balance-label">الرصيد المتاح</span>
                <span class="balance-value">$<?= number_format($user['balance'], 2) ?></span>
            </div>
        </div>

        <nav class="nav-menu">
            <div class="nav-section-title">القائمة الرئيسية</div>
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="spot-trading.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>تداول فوري</span>
            </a>
            <a href="binary-trading.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                <span>خيارات ثنائية</span>
            </a>
            <a href="p2p-deposit.php" class="nav-item">
                <i class="fas fa-wallet"></i>
                <span>إضافة رصيد P2P</span>
            </a>
            
            <div class="nav-section-title">الحساب</div>
            <a href="transactions.php" class="nav-item">
                <i class="fas fa-receipt"></i>
                <span>المعاملات</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="fas fa-user"></i>
                <span>الملف الشخصي</span>
            </a>
            
            <div class="nav-section-title">أخرى</div>
            <a href="logout.php" class="nav-item" style="color: var(--danger);">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="main">
        <div class="header">
            <div class="header-top">
                <div>
                    <h1 class="page-title">الإشعارات</h1>
                    <div class="breadcrumb">
                        <a href="dashboard.php">الرئيسية</a>
                        <i class="fas fa-chevron-left" style="font-size: 10px;"></i>
                        <span>الإشعارات</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions Bar -->
        <div class="actions-bar">
            <div class="filter-tabs">
                <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">
                    الكل (<?= $counts['total'] ?>)
                </a>
                <a href="?filter=unread" class="filter-btn <?= $filter === 'unread' ? 'active' : '' ?>">
                    غير مقروءة (<?= $counts['unread'] ?>)
                </a>
            </div>

            <div class="action-buttons">
                <?php if ($counts['unread'] > 0): ?>
                    <button class="btn btn-primary" onclick="markAllRead()">
                        <i class="fas fa-check-double"></i>
                        تعليم الكل كمقروء
                    </button>
                <?php endif; ?>
                
                <?php if ($counts['total'] > 0): ?>
                    <button class="btn btn-danger" onclick="deleteAll()">
                        <i class="fas fa-trash"></i>
                        حذف الكل
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Notifications List -->
        <div class="notifications-container">
            <?php if (empty($notifications)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-bell-slash"></i>
                    </div>
                    <h3 class="empty-title">لا توجد إشعارات</h3>
                    <p class="empty-text">
                        <?= $filter === 'unread' ? 'جميع الإشعارات مقروءة' : 'لم تتلق أي إشعارات بعد' ?>
                    </p>
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification-item <?= $notification['is_read'] ? '' : 'unread' ?>" 
                         onclick="markAsRead(<?= $notification['id'] ?>)">
                        <div class="notification-icon <?= htmlspecialchars($notification['type']) ?>">
                            <i class="fas fa-<?php
                                echo match($notification['type']) {
                                    'success' => 'check-circle',
                                    'info' => 'info-circle',
                                    'warning' => 'exclamation-triangle',
                                    'danger' => 'times-circle',
                                    default => 'bell'
                                };
                            ?>"></i>
                        </div>
                        
                        <div class="notification-content">
                            <div class="notification-title"><?= htmlspecialchars($notification['title']) ?></div>
                            <div class="notification-message"><?= htmlspecialchars($notification['message']) ?></div>
                            <div class="notification-time">
                                <i class="fas fa-clock"></i>
                                <?= time_elapsed($notification['created_at']) ?>
                            </div>
                        </div>
                        
                        <div class="notification-actions">
                            <?php if (!$notification['is_read']): ?>
                                <button class="notification-action-btn" onclick="event.stopPropagation(); markAsRead(<?= $notification['id'] ?>)">
                                    <i class="fas fa-check"></i>
                                </button>
                            <?php endif; ?>
                            <button class="notification-action-btn" onclick="event.stopPropagation(); deleteNotification(<?= $notification['id'] ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <script>
        function markAsRead(id) {
            fetch('notifications.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=mark_read&notification_id=' + id
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function markAllRead() {
            if (!confirm('هل تريد تعليم جميع الإشعارات كمقروءة؟')) return;
            
            fetch('notifications.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=mark_all_read'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function deleteNotification(id) {
            if (!confirm('هل تريد حذف هذا الإشعار؟')) return;
            
            fetch('notifications.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=delete&notification_id=' + id
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function deleteAll() {
            if (!confirm('هل تريد حذف جميع الإشعارات؟ لا يمكن التراجع عن هذا الإجراء.')) return;
            
            fetch('notifications.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=delete_all'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        <?php
        // Helper function for time elapsed
        function time_elapsed($datetime) {
            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);

            if ($diff->y > 0) return $diff->y . ' سنة';
            if ($diff->m > 0) return $diff->m . ' شهر';
            if ($diff->d > 0) return $diff->d . ' يوم';
            if ($diff->h > 0) return $diff->h . ' ساعة';
            if ($diff->i > 0) return $diff->i . ' دقيقة';
            return 'الآن';
        }
        ?>
    </script>
</body>
</html>
